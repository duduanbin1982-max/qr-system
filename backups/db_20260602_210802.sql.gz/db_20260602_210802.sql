PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            name TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'worker',
            employee_no TEXT DEFAULT '',
            phone TEXT DEFAULT '',
            process_ids TEXT DEFAULT '',
            status TEXT DEFAULT 'active',
            token TEXT DEFAULT '',
            created_at TEXT DEFAULT (datetime('now','localtime'))
        , last_active TEXT DEFAULT "", email TEXT DEFAULT "", nickname TEXT DEFAULT "", group_name TEXT DEFAULT "超级管理组", position_id INTEGER DEFAULT NULL);
INSERT INTO users VALUES(1,'admin','8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92','系统管理员','admin','','','','active','361e994b8663ccc8465b3eb0d04b9b165e95ca90f224bbda57b1417c2cb085d2','2026-04-04 11:12:58','2026-06-02 21:00:49','admin@hanyun.com','系统管理员','系统管理组',NULL);
INSERT INTO users VALUES(2,'worker1','8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92','张三','worker','0001','','322','active','ad9de28847f0a8d9a4880f74b9ac34fee9949df47ecc71616455593befce28d5','2026-04-04 11:12:58','2026-05-30 14:03:04','','','超级管理组',1);
INSERT INTO users VALUES(3,'worker2','8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92','李四','worker','0002','','328','active','','2026-04-04 11:12:58','','','','超级管理组',2);
INSERT INTO users VALUES(4,'worker3','8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92','王五','worker','0003','','195','active','','2026-04-04 11:12:58','','','','超级管理组',3);
INSERT INTO users VALUES(5,'worker4','8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92','赵六','worker','0005','','329','active','','2026-04-04 11:12:58','','','','超级管理组',4);
INSERT INTO users VALUES(271,'worker5','e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855','朱一','worker','0004','','324','active','','2026-05-11 09:22:06','','','','超级管理组',5);
INSERT INTO users VALUES(1227,'18625588632','8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92','时文芳','admin','','18625588632','','active','777f8845dd8ef67e81675d232e931370fece3dcaacaeffe9f24c59181c925049','2026-05-26 06:01:50','2026-05-30 17:16:05','','','普通管理组',NULL);
INSERT INTO users VALUES(1228,'18239937915','8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92','杨冰','admin','','18239937915','','active','','2026-05-26 06:49:53','','','','普通管理组',NULL);
INSERT INTO users VALUES(1730,'13276902993','8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92','杜斌','admin','','13276902993','','active','','2026-05-27 12:36:21','','duduanbin1982@gmail.com','','超级管理员',NULL);
INSERT INTO users VALUES(1791,'worker6','8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92','阿达','worker','0007','','','active','','2026-05-28 06:21:30','','','','超级管理组',6);
CREATE TABLE processes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT DEFAULT '',
            seq_order INTEGER DEFAULT 0,
            status TEXT DEFAULT 'active',
            created_at TEXT DEFAULT (datetime('now','localtime'))
        , category TEXT DEFAULT "结构件");
INSERT INTO processes VALUES(195,'焊接','焊接工件',3,'active','2026-05-07 15:11:44','结构件');
INSERT INTO processes VALUES(207,'入库','成品入库',9,'active','2026-05-09 02:42:12','结构件');
INSERT INTO processes VALUES(218,'质检','质量检验',8,'active','2026-05-09 13:55:03','结构件');
INSERT INTO processes VALUES(223,'喷漆','喷涂防锈漆',6,'active','2026-05-09 13:55:37','结构件');
INSERT INTO processes VALUES(322,'下料','原材料切割',1,'active','2026-05-11 04:44:54','结构件');
INSERT INTO processes VALUES(324,'打磨','清除工件表面焊接飞溅，焊疤',5,'active','2026-05-11 04:44:54','结构件');
INSERT INTO processes VALUES(328,'铆接','工件组装',3,'active','2026-05-11 08:26:24','结构件');
INSERT INTO processes VALUES(329,'抛丸','工件除锈',4,'active','2026-05-11 08:27:00','结构件');
INSERT INTO processes VALUES(330,'镗孔','工件机加工',7,'active','2026-05-11 08:27:26','结构件');
INSERT INTO processes VALUES(423,'静音外壳钻孔','加工折弯静音型外壳圆销孔，氮气室压板螺栓孔',12,'active','2026-05-11 13:28:04','结构件');
INSERT INTO processes VALUES(983,'加工分体下端面','使用卧式镗床加工分体型外壳两片外壳的端面',14,'active','2026-05-19 06:21:12','结构件');
INSERT INTO processes VALUES(984,'加工分体上端面','使用加工中心将分体型外壳连接架的底面加工平整',15,'active','2026-05-19 06:22:39','结构件');
INSERT INTO processes VALUES(985,'加工静音下端面','使用卧式镗床加工壳体端面',16,'active','2026-05-19 06:39:06','结构件');
INSERT INTO processes VALUES(986,'加工分体吊装孔','使用摇臂钻加工分体型外壳上的吊装螺栓孔',17,'active','2026-05-19 06:42:41','结构件');
INSERT INTO processes VALUES(990,'火工矫正','使用火焰矫正焊接变形',21,'active','2026-05-19 14:35:28','结构件');
INSERT INTO processes VALUES(1057,'加工内衬条','',22,'active','2026-05-20 13:39:42','机加工');
INSERT INTO processes VALUES(1058,'加工内衬板','',23,'active','2026-05-20 13:40:00','机加工');
INSERT INTO processes VALUES(1059,'加工边套','',24,'active','2026-05-20 13:40:19','机加工');
CREATE TABLE audit_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            action TEXT NOT NULL,
            target_type TEXT DEFAULT '',
            target_id INTEGER DEFAULT 0,
            detail TEXT DEFAULT '',
            created_at TEXT DEFAULT (datetime('now','localtime'))
        );
INSERT INTO audit_logs VALUES(1,1,'create_order','order',1,'ORD-001','2026-04-04 11:13:13');
INSERT INTO audit_logs VALUES(2,1,'delete_process','process',7,'','2026-04-04 12:56:27');
INSERT INTO audit_logs VALUES(3,1,'delete_process','process',8,'','2026-04-04 12:56:31');
INSERT INTO audit_logs VALUES(4,1,'delete_process','process',9,'','2026-04-04 12:56:34');
INSERT INTO audit_logs VALUES(5,1,'delete_process','process',10,'','2026-04-04 12:56:38');
INSERT INTO audit_logs VALUES(6,1,'delete_process','process',11,'','2026-04-04 12:56:42');
INSERT INTO audit_logs VALUES(7,1,'delete_process','process',12,'','2026-04-04 12:56:50');
INSERT INTO audit_logs VALUES(8,1,'delete_process','process',13,'','2026-04-15 10:58:56');
INSERT INTO audit_logs VALUES(9,1,'delete_process','process',19,'','2026-04-15 10:59:00');
INSERT INTO audit_logs VALUES(10,1,'delete_process','process',25,'','2026-04-15 10:59:03');
INSERT INTO audit_logs VALUES(11,1,'delete_process','process',31,'','2026-04-15 10:59:05');
INSERT INTO audit_logs VALUES(12,1,'delete_process','process',37,'','2026-04-15 10:59:07');
INSERT INTO audit_logs VALUES(13,1,'delete_process','process',43,'','2026-04-15 10:59:11');
INSERT INTO audit_logs VALUES(14,1,'delete_process','process',14,'','2026-04-15 10:59:23');
INSERT INTO audit_logs VALUES(15,1,'delete_process','process',20,'','2026-04-15 10:59:25');
INSERT INTO audit_logs VALUES(16,1,'delete_process','process',32,'','2026-04-15 10:59:27');
INSERT INTO audit_logs VALUES(17,1,'delete_process','process',38,'','2026-04-15 10:59:29');
INSERT INTO audit_logs VALUES(18,1,'delete_process','process',26,'','2026-04-15 10:59:31');
INSERT INTO audit_logs VALUES(19,1,'delete_process','process',44,'','2026-04-15 10:59:33');
INSERT INTO audit_logs VALUES(20,1,'delete_process','process',15,'','2026-04-15 10:59:46');
INSERT INTO audit_logs VALUES(21,1,'delete_process','process',21,'','2026-04-15 10:59:48');
INSERT INTO audit_logs VALUES(22,1,'delete_process','process',27,'','2026-04-15 10:59:50');
INSERT INTO audit_logs VALUES(23,1,'delete_process','process',33,'','2026-04-15 10:59:52');
INSERT INTO audit_logs VALUES(24,1,'delete_process','process',39,'','2026-04-15 10:59:59');
INSERT INTO audit_logs VALUES(25,1,'delete_process','process',45,'','2026-04-15 11:00:02');
INSERT INTO audit_logs VALUES(26,1,'delete_process','process',16,'','2026-04-15 11:00:08');
INSERT INTO audit_logs VALUES(27,1,'delete_process','process',22,'','2026-04-15 11:00:11');
INSERT INTO audit_logs VALUES(28,1,'delete_process','process',28,'','2026-04-15 11:00:12');
INSERT INTO audit_logs VALUES(29,1,'delete_process','process',34,'','2026-04-15 11:00:14');
INSERT INTO audit_logs VALUES(30,1,'delete_process','process',40,'','2026-04-15 11:00:19');
INSERT INTO audit_logs VALUES(31,1,'delete_process','process',46,'','2026-04-15 11:00:23');
INSERT INTO audit_logs VALUES(32,1,'delete_process','process',17,'','2026-04-15 11:00:27');
INSERT INTO audit_logs VALUES(33,1,'delete_process','process',23,'','2026-04-15 11:00:29');
INSERT INTO audit_logs VALUES(34,1,'delete_process','process',29,'','2026-04-15 11:00:31');
INSERT INTO audit_logs VALUES(35,1,'delete_process','process',35,'','2026-04-15 11:00:34');
INSERT INTO audit_logs VALUES(36,1,'delete_process','process',41,'','2026-04-15 11:00:36');
INSERT INTO audit_logs VALUES(37,1,'delete_process','process',47,'','2026-04-15 11:00:39');
INSERT INTO audit_logs VALUES(38,1,'delete_process','process',24,'','2026-04-15 11:00:44');
INSERT INTO audit_logs VALUES(39,1,'delete_process','process',18,'','2026-04-15 11:00:47');
INSERT INTO audit_logs VALUES(40,1,'delete_process','process',30,'','2026-04-15 11:00:51');
INSERT INTO audit_logs VALUES(41,1,'delete_process','process',36,'','2026-04-15 11:00:53');
INSERT INTO audit_logs VALUES(42,1,'delete_process','process',42,'','2026-04-15 11:00:57');
INSERT INTO audit_logs VALUES(43,1,'delete_process','process',48,'','2026-04-15 11:00:59');
INSERT INTO audit_logs VALUES(44,1,'update_process','process',1,'{''name'': ''下料'', ''description'': ''原材料切割'', ''seq_order'': 1}','2026-04-15 11:05:06');
INSERT INTO audit_logs VALUES(45,1,'create_process','process',49,'铆接','2026-04-15 11:05:45');
INSERT INTO audit_logs VALUES(46,1,'delete_process','process',49,'','2026-04-15 11:05:58');
INSERT INTO audit_logs VALUES(47,1,'create_customer','customer',1,'正坤机械','2026-04-15 12:23:23');
INSERT INTO audit_logs VALUES(48,1,'create_customer','customer',2,'韩运机械','2026-04-15 12:23:54');
INSERT INTO audit_logs VALUES(49,1,'create_order','order',2,'ZK260415-100','2026-04-15 12:25:18');
INSERT INTO audit_logs VALUES(50,1,'create_order','order',3,'WK2604180001','2026-04-18 12:10:53');
INSERT INTO audit_logs VALUES(51,1,'create_product','product',1,'测试产品A','2026-04-18 12:47:12');
INSERT INTO audit_logs VALUES(52,1,'create_product','product',2,'V型导轨','2026-04-18 12:49:48');
INSERT INTO audit_logs VALUES(53,1,'update_product','product',2,'{''weight'': 4.0, ''plate_thickness'': ''14mm''}','2026-04-18 12:49:48');
INSERT INTO audit_logs VALUES(54,1,'delete_product','product',2,'','2026-04-18 12:49:49');
INSERT INTO audit_logs VALUES(55,1,'create_product','product',3,'破碎锤外壳','2026-04-19 11:16:55');
INSERT INTO audit_logs VALUES(56,1,'update_product','product',3,'{''created_at'': ''2026-04-19 11:16:55'', ''description'': ''常备'', ''id'': 3, ''model'': ''SB81'', ''plate_thickness'': ''18'', ''product_name'': ''破碎锤外壳'', ''spec'': ''三角型'', ''updated_at'': ''2026-04-19 11:16:55'', ''upper_opening'': ''360'', ''weight'': 480}','2026-04-19 11:17:28');
INSERT INTO audit_logs VALUES(57,1,'create_product','product',4,'破碎锤外壳','2026-04-19 11:18:26');
INSERT INTO audit_logs VALUES(58,1,'create_product','product',5,'破碎锤外壳','2026-04-19 11:18:58');
INSERT INTO audit_logs VALUES(59,1,'create_product','product',6,'破碎锤外壳','2026-04-19 11:21:36');
INSERT INTO audit_logs VALUES(60,1,'create_product','product',7,'破碎锤外壳','2026-04-19 11:22:13');
INSERT INTO audit_logs VALUES(61,1,'create_product','product',8,'破碎锤外壳','2026-04-19 11:24:43');
INSERT INTO audit_logs VALUES(62,1,'create_product','product',9,'破碎锤外壳','2026-04-19 11:25:32');
INSERT INTO audit_logs VALUES(63,1,'create_order','order',4,'WK2605060001','2026-05-06 13:22:59');
INSERT INTO audit_logs VALUES(64,1,'update_process','process',118,'{''name'': ''打磨'', ''description'': ''表面打磨'', ''seq_order'': 3}','2026-05-07 15:16:14');
INSERT INTO audit_logs VALUES(65,1,'update_process','process',124,'{''name'': ''打磨'', ''description'': ''表面打磨'', ''seq_order'': 3}','2026-05-07 15:16:14');
INSERT INTO audit_logs VALUES(66,1,'update_process','process',124,'{''name'': ''打磨'', ''description'': ''表面打磨'', ''seq_order'': 3}','2026-05-07 15:16:15');
INSERT INTO audit_logs VALUES(67,1,'update_process','process',118,'{''name'': ''打磨'', ''description'': ''表面打磨'', ''seq_order'': 3}','2026-05-07 15:16:15');
INSERT INTO audit_logs VALUES(68,1,'update_process','process',124,'{''name'': ''打磨'', ''description'': ''表面打磨'', ''seq_order'': 3}','2026-05-07 15:16:15');
INSERT INTO audit_logs VALUES(69,1,'update_process','process',118,'{''name'': ''打磨'', ''description'': ''表面打磨'', ''seq_order'': 3}','2026-05-07 15:16:15');
INSERT INTO audit_logs VALUES(70,1,'update_process','process',124,'{''name'': ''打磨'', ''description'': ''表面打磨'', ''seq_order'': 3}','2026-05-07 15:16:16');
INSERT INTO audit_logs VALUES(71,1,'update_process','process',118,'{''name'': ''打磨'', ''description'': ''表面打磨'', ''seq_order'': 3}','2026-05-07 15:16:16');
INSERT INTO audit_logs VALUES(72,1,'delete_process','process',194,'','2026-05-07 15:27:06');
INSERT INTO audit_logs VALUES(73,1,'create_process','process',200,'铆接','2026-05-07 15:34:49');
INSERT INTO audit_logs VALUES(74,1,'update_process','process',200,'{''name'': ''铆接'', ''description'': ''工件的组装'', ''seq_order'': 6}','2026-05-07 15:34:52');
INSERT INTO audit_logs VALUES(75,1,'update_process','process',199,'{''name'': ''入库'', ''description'': ''成品入库'', ''seq_order'': 7}','2026-05-07 15:34:52');
INSERT INTO audit_logs VALUES(76,1,'update_process','process',200,'{''name'': ''铆接'', ''description'': ''工件的组装'', ''seq_order'': 5}','2026-05-07 15:34:54');
INSERT INTO audit_logs VALUES(77,1,'update_process','process',198,'{''name'': ''质检'', ''description'': ''质量检验'', ''seq_order'': 6}','2026-05-07 15:34:54');
INSERT INTO audit_logs VALUES(78,1,'update_process','process',200,'{''name'': ''铆接'', ''description'': ''工件的组装'', ''seq_order'': 4}','2026-05-07 15:34:56');
INSERT INTO audit_logs VALUES(79,1,'update_process','process',197,'{''name'': ''喷漆'', ''description'': ''喷涂上色'', ''seq_order'': 5}','2026-05-07 15:34:56');
INSERT INTO audit_logs VALUES(80,1,'update_process','process',200,'{''name'': ''铆接'', ''description'': ''工件的组装'', ''seq_order'': 3}','2026-05-07 15:34:57');
INSERT INTO audit_logs VALUES(81,1,'update_process','process',196,'{''name'': ''打磨'', ''description'': ''表面打磨'', ''seq_order'': 4}','2026-05-07 15:34:57');
INSERT INTO audit_logs VALUES(82,1,'update_process','process',195,'{''name'': ''焊接'', ''description'': ''焊接组装'', ''seq_order'': 3}','2026-05-07 15:34:59');
INSERT INTO audit_logs VALUES(83,1,'update_process','process',200,'{''name'': ''铆接'', ''description'': ''工件的组装'', ''seq_order'': 2}','2026-05-07 15:34:59');
INSERT INTO audit_logs VALUES(84,1,'update_process','process',195,'{''name'': ''焊接'', ''description'': ''焊接工件'', ''seq_order'': 3}','2026-05-07 15:35:15');
INSERT INTO audit_logs VALUES(85,1,'update_process','process',200,'{''name'': ''铆接'', ''description'': ''组装工件'', ''seq_order'': 2}','2026-05-07 15:35:29');
INSERT INTO audit_logs VALUES(86,1,'create_process','process',201,'抛丸','2026-05-07 15:36:05');
INSERT INTO audit_logs VALUES(87,1,'update_process','process',199,'{''name'': ''入库'', ''description'': ''成品入库'', ''seq_order'': 8}','2026-05-07 15:36:07');
INSERT INTO audit_logs VALUES(88,1,'update_process','process',201,'{''name'': ''抛丸'', ''description'': ''工件除锈'', ''seq_order'': 7}','2026-05-07 15:36:07');
INSERT INTO audit_logs VALUES(89,1,'update_process','process',198,'{''name'': ''质检'', ''description'': ''质量检验'', ''seq_order'': 7}','2026-05-07 15:36:08');
INSERT INTO audit_logs VALUES(90,1,'update_process','process',201,'{''name'': ''抛丸'', ''description'': ''工件除锈'', ''seq_order'': 6}','2026-05-07 15:36:08');
INSERT INTO audit_logs VALUES(91,1,'update_process','process',201,'{''name'': ''抛丸'', ''description'': ''工件除锈'', ''seq_order'': 5}','2026-05-07 15:36:09');
INSERT INTO audit_logs VALUES(92,1,'update_process','process',197,'{''name'': ''喷漆'', ''description'': ''喷涂上色'', ''seq_order'': 6}','2026-05-07 15:36:10');
INSERT INTO audit_logs VALUES(93,1,'update_process','process',201,'{''name'': ''抛丸'', ''description'': ''工件除锈'', ''seq_order'': 4}','2026-05-07 15:36:13');
INSERT INTO audit_logs VALUES(94,1,'update_process','process',196,'{''name'': ''打磨'', ''description'': ''表面打磨'', ''seq_order'': 5}','2026-05-07 15:36:13');
INSERT INTO audit_logs VALUES(95,1,'delete_process','process',202,'','2026-05-09 08:19:39');
INSERT INTO audit_logs VALUES(96,1,'create_process_price','process_price',1,'{''process_id'': 1, ''unit_price'': 5.0, ''effective_date'': ''2026-05-09'', ''remark'': ''测试''}','2026-05-09 14:29:54');
INSERT INTO audit_logs VALUES(97,1,'delete_process','process',999,'','2026-05-11 03:38:27');
INSERT INTO audit_logs VALUES(98,1,'delete_process','process',208,'','2026-05-11 04:48:18');
INSERT INTO audit_logs VALUES(99,1,'delete_process','process',214,'','2026-05-11 04:48:18');
INSERT INTO audit_logs VALUES(100,1,'delete_process','process',220,'','2026-05-11 08:21:18');
INSERT INTO audit_logs VALUES(101,1,'delete_process','process',226,'','2026-05-11 08:21:21');
INSERT INTO audit_logs VALUES(102,1,'delete_process','process',232,'','2026-05-11 08:21:23');
INSERT INTO audit_logs VALUES(103,1,'delete_process','process',238,'','2026-05-11 08:21:25');
INSERT INTO audit_logs VALUES(104,1,'delete_process','process',244,'','2026-05-11 08:21:27');
INSERT INTO audit_logs VALUES(105,1,'delete_process','process',250,'','2026-05-11 08:21:29');
INSERT INTO audit_logs VALUES(106,1,'delete_process','process',256,'','2026-05-11 08:21:30');
INSERT INTO audit_logs VALUES(107,1,'delete_process','process',262,'','2026-05-11 08:21:33');
INSERT INTO audit_logs VALUES(108,1,'delete_process','process',268,'','2026-05-11 08:21:34');
INSERT INTO audit_logs VALUES(109,1,'delete_process','process',274,'','2026-05-11 08:21:36');
INSERT INTO audit_logs VALUES(110,1,'delete_process','process',280,'','2026-05-11 08:21:38');
INSERT INTO audit_logs VALUES(111,1,'delete_process','process',286,'','2026-05-11 08:21:40');
INSERT INTO audit_logs VALUES(112,1,'delete_process','process',292,'','2026-05-11 08:21:42');
INSERT INTO audit_logs VALUES(113,1,'delete_process','process',298,'','2026-05-11 08:21:43');
INSERT INTO audit_logs VALUES(114,1,'delete_process','process',304,'','2026-05-11 08:21:45');
INSERT INTO audit_logs VALUES(115,1,'delete_process','process',310,'','2026-05-11 08:21:47');
INSERT INTO audit_logs VALUES(116,1,'delete_process','process',316,'','2026-05-11 08:21:49');
INSERT INTO audit_logs VALUES(117,1,'delete_process','process',200,'','2026-05-11 08:21:51');
INSERT INTO audit_logs VALUES(118,1,'delete_process','process',203,'','2026-05-11 08:22:04');
INSERT INTO audit_logs VALUES(119,1,'delete_process','process',209,'','2026-05-11 08:22:06');
INSERT INTO audit_logs VALUES(120,1,'delete_process','process',215,'','2026-05-11 08:22:08');
INSERT INTO audit_logs VALUES(121,1,'delete_process','process',221,'','2026-05-11 08:22:09');
INSERT INTO audit_logs VALUES(122,1,'delete_process','process',227,'','2026-05-11 08:22:11');
INSERT INTO audit_logs VALUES(123,1,'delete_process','process',233,'','2026-05-11 08:22:13');
INSERT INTO audit_logs VALUES(124,1,'delete_process','process',239,'','2026-05-11 08:22:14');
INSERT INTO audit_logs VALUES(125,1,'delete_process','process',245,'','2026-05-11 08:22:16');
INSERT INTO audit_logs VALUES(126,1,'delete_process','process',251,'','2026-05-11 08:22:18');
INSERT INTO audit_logs VALUES(127,1,'delete_process','process',257,'','2026-05-11 08:22:19');
INSERT INTO audit_logs VALUES(128,1,'delete_process','process',263,'','2026-05-11 08:22:21');
INSERT INTO audit_logs VALUES(129,1,'delete_process','process',269,'','2026-05-11 08:22:23');
INSERT INTO audit_logs VALUES(130,1,'delete_process','process',275,'','2026-05-11 08:22:24');
INSERT INTO audit_logs VALUES(131,1,'delete_process','process',281,'','2026-05-11 08:22:26');
INSERT INTO audit_logs VALUES(132,1,'delete_process','process',287,'','2026-05-11 08:22:28');
INSERT INTO audit_logs VALUES(133,1,'delete_process','process',293,'','2026-05-11 08:22:30');
INSERT INTO audit_logs VALUES(134,1,'delete_process','process',299,'','2026-05-11 08:22:32');
INSERT INTO audit_logs VALUES(135,1,'delete_process','process',305,'','2026-05-11 08:22:35');
INSERT INTO audit_logs VALUES(136,1,'delete_process','process',311,'','2026-05-11 08:22:37');
INSERT INTO audit_logs VALUES(137,1,'delete_process','process',317,'','2026-05-11 08:22:38');
INSERT INTO audit_logs VALUES(138,1,'delete_process','process',323,'','2026-05-11 08:22:41');
INSERT INTO audit_logs VALUES(139,1,'delete_process','process',204,'','2026-05-11 08:22:43');
INSERT INTO audit_logs VALUES(140,1,'delete_process','process',210,'','2026-05-11 08:22:45');
INSERT INTO audit_logs VALUES(141,1,'delete_process','process',216,'','2026-05-11 08:22:47');
INSERT INTO audit_logs VALUES(142,1,'delete_process','process',222,'','2026-05-11 08:22:50');
INSERT INTO audit_logs VALUES(143,1,'delete_process','process',228,'','2026-05-11 08:22:52');
INSERT INTO audit_logs VALUES(144,1,'delete_process','process',234,'','2026-05-11 08:22:54');
INSERT INTO audit_logs VALUES(145,1,'delete_process','process',240,'','2026-05-11 08:22:57');
INSERT INTO audit_logs VALUES(146,1,'delete_process','process',246,'','2026-05-11 08:22:59');
INSERT INTO audit_logs VALUES(147,1,'delete_process','process',252,'','2026-05-11 08:23:02');
INSERT INTO audit_logs VALUES(148,1,'delete_process','process',258,'','2026-05-11 08:23:04');
INSERT INTO audit_logs VALUES(149,1,'delete_process','process',264,'','2026-05-11 08:23:06');
INSERT INTO audit_logs VALUES(150,1,'delete_process','process',270,'','2026-05-11 08:23:08');
INSERT INTO audit_logs VALUES(151,1,'delete_process','process',276,'','2026-05-11 08:23:10');
INSERT INTO audit_logs VALUES(152,1,'delete_process','process',282,'','2026-05-11 08:23:12');
INSERT INTO audit_logs VALUES(153,1,'delete_process','process',288,'','2026-05-11 08:23:14');
INSERT INTO audit_logs VALUES(154,1,'delete_process','process',294,'','2026-05-11 08:23:16');
INSERT INTO audit_logs VALUES(155,1,'delete_process','process',300,'','2026-05-11 08:23:18');
INSERT INTO audit_logs VALUES(156,1,'delete_process','process',306,'','2026-05-11 08:23:20');
INSERT INTO audit_logs VALUES(157,1,'delete_process','process',312,'','2026-05-11 08:23:22');
INSERT INTO audit_logs VALUES(158,1,'delete_process','process',318,'','2026-05-11 08:23:25');
INSERT INTO audit_logs VALUES(159,1,'delete_process','process',201,'','2026-05-11 08:23:28');
INSERT INTO audit_logs VALUES(160,1,'delete_process','process',205,'','2026-05-11 08:23:32');
INSERT INTO audit_logs VALUES(161,1,'delete_process','process',211,'','2026-05-11 08:23:34');
INSERT INTO audit_logs VALUES(162,1,'delete_process','process',217,'','2026-05-11 08:23:36');
INSERT INTO audit_logs VALUES(163,1,'delete_process','process',229,'','2026-05-11 08:23:38');
INSERT INTO audit_logs VALUES(164,1,'delete_process','process',235,'','2026-05-11 08:23:39');
INSERT INTO audit_logs VALUES(165,1,'delete_process','process',241,'','2026-05-11 08:23:41');
INSERT INTO audit_logs VALUES(166,1,'delete_process','process',247,'','2026-05-11 08:23:43');
INSERT INTO audit_logs VALUES(167,1,'delete_process','process',253,'','2026-05-11 08:23:45');
INSERT INTO audit_logs VALUES(168,1,'delete_process','process',259,'','2026-05-11 08:23:47');
INSERT INTO audit_logs VALUES(169,1,'delete_process','process',265,'','2026-05-11 08:23:49');
INSERT INTO audit_logs VALUES(170,1,'delete_process','process',271,'','2026-05-11 08:23:51');
INSERT INTO audit_logs VALUES(171,1,'delete_process','process',277,'','2026-05-11 08:23:53');
INSERT INTO audit_logs VALUES(172,1,'delete_process','process',283,'','2026-05-11 08:23:54');
INSERT INTO audit_logs VALUES(173,1,'delete_process','process',289,'','2026-05-11 08:23:56');
INSERT INTO audit_logs VALUES(174,1,'delete_process','process',295,'','2026-05-11 08:23:59');
INSERT INTO audit_logs VALUES(175,1,'delete_process','process',301,'','2026-05-11 08:24:01');
INSERT INTO audit_logs VALUES(176,1,'delete_process','process',307,'','2026-05-11 08:24:03');
INSERT INTO audit_logs VALUES(177,1,'delete_process','process',313,'','2026-05-11 08:24:06');
INSERT INTO audit_logs VALUES(178,1,'delete_process','process',319,'','2026-05-11 08:24:08');
INSERT INTO audit_logs VALUES(179,1,'delete_process','process',325,'','2026-05-11 08:24:11');
INSERT INTO audit_logs VALUES(180,1,'delete_process','process',196,'','2026-05-11 08:24:16');
INSERT INTO audit_logs VALUES(181,1,'delete_process','process',206,'','2026-05-11 08:24:19');
INSERT INTO audit_logs VALUES(182,1,'delete_process','process',212,'','2026-05-11 08:24:22');
INSERT INTO audit_logs VALUES(183,1,'delete_process','process',198,'','2026-05-11 08:24:27');
INSERT INTO audit_logs VALUES(184,1,'delete_process','process',199,'','2026-05-11 08:24:30');
INSERT INTO audit_logs VALUES(185,1,'delete_process','process',327,'','2026-05-11 08:24:33');
INSERT INTO audit_logs VALUES(186,1,'delete_process','process',321,'','2026-05-11 08:24:35');
INSERT INTO audit_logs VALUES(187,1,'delete_process','process',315,'','2026-05-11 08:24:38');
INSERT INTO audit_logs VALUES(188,1,'delete_process','process',309,'','2026-05-11 08:24:40');
INSERT INTO audit_logs VALUES(189,1,'delete_process','process',303,'','2026-05-11 08:24:43');
INSERT INTO audit_logs VALUES(190,1,'delete_process','process',297,'','2026-05-11 08:24:45');
INSERT INTO audit_logs VALUES(191,1,'delete_process','process',291,'','2026-05-11 08:24:47');
INSERT INTO audit_logs VALUES(192,1,'delete_process','process',285,'','2026-05-11 08:24:50');
INSERT INTO audit_logs VALUES(193,1,'delete_process','process',279,'','2026-05-11 08:24:52');
INSERT INTO audit_logs VALUES(194,1,'delete_process','process',273,'','2026-05-11 08:24:55');
INSERT INTO audit_logs VALUES(195,1,'delete_process','process',267,'','2026-05-11 08:24:58');
INSERT INTO audit_logs VALUES(196,1,'delete_process','process',261,'','2026-05-11 08:25:00');
INSERT INTO audit_logs VALUES(197,1,'delete_process','process',255,'','2026-05-11 08:25:02');
INSERT INTO audit_logs VALUES(198,1,'delete_process','process',249,'','2026-05-11 08:25:04');
INSERT INTO audit_logs VALUES(199,1,'delete_process','process',243,'','2026-05-11 08:25:07');
INSERT INTO audit_logs VALUES(200,1,'delete_process','process',237,'','2026-05-11 08:25:09');
INSERT INTO audit_logs VALUES(201,1,'delete_process','process',231,'','2026-05-11 08:25:11');
INSERT INTO audit_logs VALUES(202,1,'delete_process','process',225,'','2026-05-11 08:25:14');
INSERT INTO audit_logs VALUES(203,1,'delete_process','process',219,'','2026-05-11 08:25:16');
INSERT INTO audit_logs VALUES(204,1,'delete_process','process',213,'','2026-05-11 08:25:18');
INSERT INTO audit_logs VALUES(205,1,'delete_process','process',197,'','2026-05-11 08:25:22');
INSERT INTO audit_logs VALUES(206,1,'delete_process','process',320,'','2026-05-11 08:25:25');
INSERT INTO audit_logs VALUES(207,1,'delete_process','process',314,'','2026-05-11 08:25:27');
INSERT INTO audit_logs VALUES(208,1,'delete_process','process',296,'','2026-05-11 08:25:29');
INSERT INTO audit_logs VALUES(209,1,'delete_process','process',284,'','2026-05-11 08:25:31');
INSERT INTO audit_logs VALUES(210,1,'delete_process','process',278,'','2026-05-11 08:25:34');
INSERT INTO audit_logs VALUES(211,1,'delete_process','process',272,'','2026-05-11 08:25:36');
INSERT INTO audit_logs VALUES(212,1,'delete_process','process',266,'','2026-05-11 08:25:39');
INSERT INTO audit_logs VALUES(213,1,'delete_process','process',260,'','2026-05-11 08:25:41');
INSERT INTO audit_logs VALUES(214,1,'delete_process','process',290,'','2026-05-11 08:25:43');
INSERT INTO audit_logs VALUES(215,1,'delete_process','process',254,'','2026-05-11 08:25:45');
INSERT INTO audit_logs VALUES(216,1,'delete_process','process',302,'','2026-05-11 08:25:48');
INSERT INTO audit_logs VALUES(217,1,'delete_process','process',248,'','2026-05-11 08:25:50');
INSERT INTO audit_logs VALUES(218,1,'delete_process','process',224,'','2026-05-11 08:25:52');
INSERT INTO audit_logs VALUES(219,1,'delete_process','process',236,'','2026-05-11 08:25:55');
INSERT INTO audit_logs VALUES(220,1,'delete_process','process',230,'','2026-05-11 08:25:57');
INSERT INTO audit_logs VALUES(221,1,'delete_process','process',308,'','2026-05-11 08:25:59');
INSERT INTO audit_logs VALUES(222,1,'delete_process','process',326,'','2026-05-11 08:26:02');
INSERT INTO audit_logs VALUES(223,1,'delete_process','process',242,'','2026-05-11 08:26:05');
INSERT INTO audit_logs VALUES(224,1,'create_process','process',328,'铆接','2026-05-11 08:26:24');
INSERT INTO audit_logs VALUES(225,1,'update_process','process',328,'{''name'': ''铆接'', ''description'': ''工件组装'', ''seq_order'': 6}','2026-05-11 08:26:27');
INSERT INTO audit_logs VALUES(226,1,'update_process','process',207,'{''name'': ''入库'', ''description'': ''成品入库'', ''seq_order'': 7}','2026-05-11 08:26:27');
INSERT INTO audit_logs VALUES(227,1,'update_process','process',328,'{''name'': ''铆接'', ''description'': ''工件组装'', ''seq_order'': 5}','2026-05-11 08:26:29');
INSERT INTO audit_logs VALUES(228,1,'update_process','process',218,'{''name'': ''质检'', ''description'': ''质量检验'', ''seq_order'': 6}','2026-05-11 08:26:29');
INSERT INTO audit_logs VALUES(229,1,'update_process','process',328,'{''name'': ''铆接'', ''description'': ''工件组装'', ''seq_order'': 4}','2026-05-11 08:26:30');
INSERT INTO audit_logs VALUES(230,1,'update_process','process',223,'{''name'': ''喷漆'', ''description'': ''喷涂上色'', ''seq_order'': 5}','2026-05-11 08:26:30');
INSERT INTO audit_logs VALUES(231,1,'update_process','process',328,'{''name'': ''铆接'', ''description'': ''工件组装'', ''seq_order'': 3}','2026-05-11 08:26:31');
INSERT INTO audit_logs VALUES(232,1,'update_process','process',324,'{''name'': ''打磨'', ''description'': ''表面打磨'', ''seq_order'': 4}','2026-05-11 08:26:31');
INSERT INTO audit_logs VALUES(233,1,'update_process','process',328,'{''name'': ''铆接'', ''description'': ''工件组装'', ''seq_order'': 3}','2026-05-11 08:26:32');
INSERT INTO audit_logs VALUES(234,1,'update_process','process',195,'{''name'': ''焊接'', ''description'': ''焊接工件'', ''seq_order'': 3}','2026-05-11 08:26:32');
INSERT INTO audit_logs VALUES(235,1,'create_process','process',329,'抛丸','2026-05-11 08:27:01');
INSERT INTO audit_logs VALUES(236,1,'update_process','process',207,'{''name'': ''入库'', ''description'': ''成品入库'', ''seq_order'': 8}','2026-05-11 08:27:02');
INSERT INTO audit_logs VALUES(237,1,'update_process','process',329,'{''name'': ''抛丸'', ''description'': ''工件除锈'', ''seq_order'': 7}','2026-05-11 08:27:02');
INSERT INTO audit_logs VALUES(238,1,'update_process','process',329,'{''name'': ''抛丸'', ''description'': ''工件除锈'', ''seq_order'': 6}','2026-05-11 08:27:03');
INSERT INTO audit_logs VALUES(239,1,'update_process','process',218,'{''name'': ''质检'', ''description'': ''质量检验'', ''seq_order'': 7}','2026-05-11 08:27:03');
INSERT INTO audit_logs VALUES(240,1,'update_process','process',329,'{''name'': ''抛丸'', ''description'': ''工件除锈'', ''seq_order'': 5}','2026-05-11 08:27:04');
INSERT INTO audit_logs VALUES(241,1,'update_process','process',223,'{''name'': ''喷漆'', ''description'': ''喷涂上色'', ''seq_order'': 6}','2026-05-11 08:27:04');
INSERT INTO audit_logs VALUES(242,1,'update_process','process',324,'{''name'': ''打磨'', ''description'': ''表面打磨'', ''seq_order'': 5}','2026-05-11 08:27:05');
INSERT INTO audit_logs VALUES(243,1,'update_process','process',329,'{''name'': ''抛丸'', ''description'': ''工件除锈'', ''seq_order'': 4}','2026-05-11 08:27:05');
INSERT INTO audit_logs VALUES(244,1,'create_process','process',330,'镗孔','2026-05-11 08:27:26');
INSERT INTO audit_logs VALUES(245,1,'update_process','process',330,'{''name'': ''镗孔'', ''description'': ''工件机加工'', ''seq_order'': 8}','2026-05-11 08:27:28');
INSERT INTO audit_logs VALUES(246,1,'update_process','process',207,'{''name'': ''入库'', ''description'': ''成品入库'', ''seq_order'': 9}','2026-05-11 08:27:28');
INSERT INTO audit_logs VALUES(247,1,'update_process','process',218,'{''name'': ''质检'', ''description'': ''质量检验'', ''seq_order'': 8}','2026-05-11 08:27:30');
INSERT INTO audit_logs VALUES(248,1,'update_process','process',330,'{''name'': ''镗孔'', ''description'': ''工件机加工'', ''seq_order'': 7}','2026-05-11 08:27:30');
INSERT INTO audit_logs VALUES(249,1,'update_user','user',1,'{''process_ids'': ''322''}','2026-05-11 08:43:22');
INSERT INTO audit_logs VALUES(250,1,'update_user','user',2,'{''username'': ''worker1'', ''name'': ''张三'', ''employee_no'': ''0001'', ''phone'': '''', ''role'': ''worker'', ''password'': '''', ''process_ids'': 322}','2026-05-11 09:20:25');
INSERT INTO audit_logs VALUES(251,1,'update_user','user',1,'{''username'': ''admin'', ''name'': ''系统管理员'', ''employee_no'': '''', ''phone'': '''', ''role'': ''admin'', ''password'': '''', ''process_ids'': ''''}','2026-05-11 09:20:55');
INSERT INTO audit_logs VALUES(252,1,'update_user','user',3,'{''username'': ''worker2'', ''name'': ''李四'', ''employee_no'': '''', ''phone'': '''', ''role'': ''worker'', ''password'': '''', ''process_ids'': 328}','2026-05-11 09:21:05');
INSERT INTO audit_logs VALUES(253,1,'update_user','user',4,'{''username'': ''worker3'', ''name'': ''王五'', ''employee_no'': '''', ''phone'': '''', ''role'': ''worker'', ''password'': '''', ''process_ids'': 195}','2026-05-11 09:21:10');
INSERT INTO audit_logs VALUES(254,1,'update_user','user',5,'{''username'': ''worker4'', ''name'': ''赵六'', ''employee_no'': '''', ''phone'': '''', ''role'': ''worker'', ''password'': '''', ''process_ids'': 329}','2026-05-11 09:21:15');
INSERT INTO audit_logs VALUES(255,1,'create_user','user',271,'worker5/朱一','2026-05-11 09:22:06');
INSERT INTO audit_logs VALUES(256,1,'delete_product','product',1,'','2026-05-11 09:32:24');
INSERT INTO audit_logs VALUES(257,1,'create_product','product',10,'破碎锤外壳','2026-05-11 09:59:05');
INSERT INTO audit_logs VALUES(258,1,'create_product','product',11,'破碎锤外壳','2026-05-11 10:20:08');
INSERT INTO audit_logs VALUES(259,1,'update_product','product',11,'{''created_at'': ''2026-05-11 10:20:08'', ''description'': '''', ''id'': 11, ''model'': ''SB81'', ''plate_thickness'': ''16'', ''product_name'': ''破碎锤外壳'', ''spec'': ''360'', ''updated_at'': ''2026-05-11 10:20:08'', ''upper_opening'': ''360'', ''weight'': 0}','2026-05-11 10:20:16');
INSERT INTO audit_logs VALUES(260,1,'update_product','product',5,'{''created_at'': ''2026-04-19 11:18:58'', ''description'': ''双筋。'', ''id'': 5, ''model'': ''SB81'', ''plate_thickness'': ''18'', ''product_name'': ''破碎锤外壳'', ''spec'': ''分体直型'', ''updated_at'': ''2026-04-19 11:18:58'', ''upper_opening'': ''360'', ''weight'': 800}','2026-05-11 10:24:35');
INSERT INTO audit_logs VALUES(261,1,'update_product','product',5,'{''created_at'': ''2026-04-19 11:18:58'', ''description'': ''双筋'', ''id'': 5, ''model'': ''SB81'', ''plate_thickness'': ''18'', ''product_name'': ''破碎锤外壳'', ''spec'': ''分体直型'', ''updated_at'': ''2026-05-11 10:24:35'', ''upper_opening'': ''360'', ''weight'': 800}','2026-05-11 10:24:42');
INSERT INTO audit_logs VALUES(262,1,'create_product','product',12,'Test Product A','2026-05-11 11:50:40');
INSERT INTO audit_logs VALUES(263,1,'create_product','product',13,'Test Code Gen','2026-05-11 11:51:02');
INSERT INTO audit_logs VALUES(264,1,'create_product','product',14,'Test-ASCII','2026-05-11 11:52:05');
INSERT INTO audit_logs VALUES(265,1,'create_product','product',15,'Test-中文','2026-05-11 11:52:05');
INSERT INTO audit_logs VALUES(266,1,'create_product','product',16,'TestFinal','2026-05-11 11:54:02');
INSERT INTO audit_logs VALUES(267,1,'create_product','product',17,'TestCode','2026-05-11 12:01:37');
INSERT INTO audit_logs VALUES(268,1,'update_product','product',3,'{''created_at'': ''2026-04-19 11:16:55'', ''description'': ''常备'', ''id'': 3, ''model'': ''NEWMODEL'', ''plate_thickness'': ''18'', ''product_code'': '''', ''product_name'': ''破碎锤外壳'', ''spec'': ''两档宽口'', ''updated_at'': ''2026-04-19 11:17:28'', ''upper_opening'': ''360'', ''weight'': 480.0}','2026-05-11 12:02:11');
INSERT INTO audit_logs VALUES(269,1,'create_product','product',18,'测试产品中文','2026-05-11 12:02:11');
INSERT INTO audit_logs VALUES(270,1,'update_product','product',3,'{''created_at'': ''2026-04-19 11:16:55'', ''description'': ''常备'', ''id'': 3, ''model'': ''NEWMODEL'', ''plate_thickness'': ''18'', ''product_code'': ''NEWMODEL-LD-360-18'', ''product_name'': ''破碎锤外壳'', ''spec'': ''两档宽口'', ''updated_at'': ''2026-05-11 12:02:11'', ''upper_opening'': ''360'', ''weight'': 480.0}','2026-05-11 12:02:37');
INSERT INTO audit_logs VALUES(271,1,'update_product','product',3,'{''created_at'': ''2026-04-19 11:16:55'', ''description'': ''常备'', ''id'': 3, ''model'': ''TEST123'', ''plate_thickness'': ''18'', ''product_code'': ''NEWMODEL-LD-360-18'', ''product_name'': ''破碎锤外壳'', ''spec'': ''单档'', ''updated_at'': ''2026-05-11 12:02:37'', ''upper_opening'': ''360'', ''weight'': 480.0}','2026-05-11 12:03:43');
INSERT INTO audit_logs VALUES(272,1,'create_product','product',19,'Final Test','2026-05-11 12:05:44');
INSERT INTO audit_logs VALUES(273,1,'create_product','product',20,'破碎锤外壳','2026-05-11 12:08:28');
INSERT INTO audit_logs VALUES(274,1,'delete_product','product',19,'','2026-05-11 12:09:03');
INSERT INTO audit_logs VALUES(275,1,'delete_product','product',18,'','2026-05-11 12:09:06');
INSERT INTO audit_logs VALUES(276,1,'delete_product','product',17,'','2026-05-11 12:09:11');
INSERT INTO audit_logs VALUES(277,1,'delete_product','product',16,'','2026-05-11 12:09:16');
INSERT INTO audit_logs VALUES(278,1,'delete_product','product',15,'','2026-05-11 12:09:19');
INSERT INTO audit_logs VALUES(279,1,'delete_product','product',14,'','2026-05-11 12:09:21');
INSERT INTO audit_logs VALUES(280,1,'delete_product','product',13,'','2026-05-11 12:09:24');
INSERT INTO audit_logs VALUES(281,1,'delete_product','product',12,'','2026-05-11 12:09:26');
INSERT INTO audit_logs VALUES(282,1,'delete_product','product',3,'','2026-05-11 12:09:37');
INSERT INTO audit_logs VALUES(283,1,'update_product','product',11,'{''created_at'': ''2026-05-11 10:20:08'', ''description'': '''', ''id'': 11, ''model'': ''SB81'', ''plate_thickness'': ''16'', ''product_code'': '''', ''product_name'': ''破碎锤外壳'', ''spec'': ''360'', ''updated_at'': ''2026-05-11 10:20:16'', ''upper_opening'': ''360'', ''weight'': 0}','2026-05-11 12:09:41');
INSERT INTO audit_logs VALUES(284,1,'update_product','product',10,'{''created_at'': ''2026-05-11 09:59:05'', ''description'': '''', ''id'': 10, ''model'': ''SB81'', ''plate_thickness'': ''20'', ''product_code'': '''', ''product_name'': ''破碎锤外壳'', ''spec'': ''三角型'', ''updated_at'': ''2026-05-11 09:59:05'', ''upper_opening'': ''360'', ''weight'': 0}','2026-05-11 12:09:49');
INSERT INTO audit_logs VALUES(285,1,'update_product','product',9,'{''created_at'': ''2026-04-19 11:25:32'', ''description'': '''', ''id'': 9, ''model'': ''SB81'', ''plate_thickness'': ''22'', ''product_code'': '''', ''product_name'': ''破碎锤外壳'', ''spec'': ''三角型'', ''updated_at'': ''2026-04-19 11:25:32'', ''upper_opening'': ''360'', ''weight'': 620}','2026-05-11 12:09:52');
INSERT INTO audit_logs VALUES(286,1,'update_product','product',8,'{''created_at'': ''2026-04-19 11:24:43'', ''description'': '''', ''id'': 8, ''model'': ''SB81'', ''plate_thickness'': ''20'', ''product_code'': '''', ''product_name'': ''破碎锤外壳'', ''spec'': ''三角型'', ''updated_at'': ''2026-04-19 11:24:43'', ''upper_opening'': ''360'', ''weight'': 510}','2026-05-11 12:09:55');
INSERT INTO audit_logs VALUES(287,1,'update_product','product',7,'{''created_at'': ''2026-04-19 11:22:13'', ''description'': '''', ''id'': 7, ''model'': ''SB81'', ''plate_thickness'': ''18'', ''product_code'': '''', ''product_name'': ''破碎锤外壳'', ''spec'': ''三角型'', ''updated_at'': ''2026-04-19 11:22:13'', ''upper_opening'': ''440'', ''weight'': 580}','2026-05-11 12:09:58');
INSERT INTO audit_logs VALUES(288,1,'update_product','product',6,'{''created_at'': ''2026-04-19 11:21:36'', ''description'': '''', ''id'': 6, ''model'': ''SB81'', ''plate_thickness'': ''18'', ''product_code'': '''', ''product_name'': ''破碎锤外壳'', ''spec'': ''静音型'', ''updated_at'': ''2026-04-19 11:21:36'', ''upper_opening'': ''360'', ''weight'': 550}','2026-05-11 12:10:01');
INSERT INTO audit_logs VALUES(289,1,'update_product','product',5,'{''created_at'': ''2026-04-19 11:18:58'', ''description'': ''双筋'', ''id'': 5, ''model'': ''SB81'', ''plate_thickness'': ''18'', ''product_code'': '''', ''product_name'': ''破碎锤外壳'', ''spec'': ''分体直型'', ''updated_at'': ''2026-05-11 10:24:42'', ''upper_opening'': ''360'', ''weight'': 800}','2026-05-11 12:10:08');
INSERT INTO audit_logs VALUES(290,1,'update_product','product',4,'{''created_at'': ''2026-04-19 11:18:26'', ''description'': '''', ''id'': 4, ''model'': ''SB81'', ''plate_thickness'': ''18'', ''product_code'': '''', ''product_name'': ''破碎锤外壳'', ''spec'': ''一体直型'', ''updated_at'': ''2026-04-19 11:18:26'', ''upper_opening'': ''360'', ''weight'': 600}','2026-05-11 12:10:11');
INSERT INTO audit_logs VALUES(291,1,'create_product','product',21,'外壳','2026-05-11 12:11:47');
INSERT INTO audit_logs VALUES(292,1,'create_product','product',22,'测试1','2026-05-11 12:15:00');
INSERT INTO audit_logs VALUES(293,1,'create_product','product',23,'测试2','2026-05-11 12:15:00');
INSERT INTO audit_logs VALUES(294,1,'create_product','product',24,'测试3','2026-05-11 12:15:00');
INSERT INTO audit_logs VALUES(295,1,'create_product','product',25,'测试4','2026-05-11 12:15:00');
INSERT INTO audit_logs VALUES(296,1,'create_product','product',26,'测试5','2026-05-11 12:15:00');
INSERT INTO audit_logs VALUES(297,1,'create_product','product',27,'测试6','2026-05-11 12:15:01');
INSERT INTO audit_logs VALUES(298,1,'create_product','product',28,'测试7','2026-05-11 12:15:01');
INSERT INTO audit_logs VALUES(299,1,'create_product','product',29,'测试8','2026-05-11 12:15:01');
INSERT INTO audit_logs VALUES(300,1,'create_product','product',30,'测试9','2026-05-11 12:15:01');
INSERT INTO audit_logs VALUES(301,1,'create_product','product',31,'测试10','2026-05-11 12:15:01');
INSERT INTO audit_logs VALUES(302,1,'create_product','product',32,'测试11','2026-05-11 12:15:01');
INSERT INTO audit_logs VALUES(303,1,'create_product','product',33,'测试12','2026-05-11 12:15:01');
INSERT INTO audit_logs VALUES(304,1,'delete_product','product',33,'','2026-05-11 12:16:37');
INSERT INTO audit_logs VALUES(305,1,'delete_product','product',32,'','2026-05-11 12:16:40');
INSERT INTO audit_logs VALUES(306,1,'delete_product','product',31,'','2026-05-11 12:16:42');
INSERT INTO audit_logs VALUES(307,1,'delete_product','product',30,'','2026-05-11 12:16:44');
INSERT INTO audit_logs VALUES(308,1,'delete_product','product',29,'','2026-05-11 12:16:46');
INSERT INTO audit_logs VALUES(309,1,'delete_product','product',28,'','2026-05-11 12:16:48');
INSERT INTO audit_logs VALUES(310,1,'delete_product','product',27,'','2026-05-11 12:16:50');
INSERT INTO audit_logs VALUES(311,1,'delete_product','product',26,'','2026-05-11 12:16:52');
INSERT INTO audit_logs VALUES(312,1,'delete_product','product',25,'','2026-05-11 12:16:54');
INSERT INTO audit_logs VALUES(313,1,'delete_product','product',24,'','2026-05-11 12:16:56');
INSERT INTO audit_logs VALUES(314,1,'delete_product','product',23,'','2026-05-11 12:16:58');
INSERT INTO audit_logs VALUES(315,1,'delete_product','product',22,'','2026-05-11 12:17:00');
INSERT INTO audit_logs VALUES(316,1,'update_product','product',21,'{''created_at'': ''2026-05-11 12:11:47'', ''description'': '''', ''id'': 21, ''model'': ''SB121'', ''plate_thickness'': ''25'', ''product_code'': ''SB121-440-25'', ''product_name'': ''外壳'', ''spec'': ''静音型'', ''updated_at'': ''2026-05-11 12:11:47'', ''upper_opening'': ''440'', ''weight'': 0}','2026-05-11 12:17:05');
INSERT INTO audit_logs VALUES(317,1,'update_product','product',21,'{''created_at'': ''2026-05-11 12:11:47'', ''description'': '''', ''id'': 21, ''model'': ''SB121'', ''plate_thickness'': ''25'', ''product_code'': ''SB121-440-25'', ''product_name'': ''外壳'', ''spec'': ''静音型'', ''updated_at'': ''2026-05-11 12:17:05'', ''upper_opening'': ''440'', ''weight'': 0}','2026-05-11 12:17:40');
INSERT INTO audit_logs VALUES(318,1,'create_product','product',34,'外壳','2026-05-11 12:18:14');
INSERT INTO audit_logs VALUES(319,1,'update_product','product',34,'{''product_name'': ''外壳'', ''model'': ''SB151'', ''spec'': ''静音型'', ''upper_opening'': ''500'', ''plate_thickness'': ''25'', ''weight'': 0.0, ''description'': ''''}','2026-05-11 12:25:37');
INSERT INTO audit_logs VALUES(320,1,'update_product','product',21,'{''product_name'': ''外壳'', ''model'': ''SB121'', ''spec'': ''静音型'', ''upper_opening'': ''440'', ''plate_thickness'': ''25'', ''weight'': 0.0, ''description'': ''''}','2026-05-11 12:25:37');
INSERT INTO audit_logs VALUES(321,1,'update_product','product',20,'{''product_name'': ''破碎锤外壳'', ''model'': ''SB121'', ''spec'': ''三角型'', ''upper_opening'': ''440'', ''plate_thickness'': ''22'', ''weight'': 0.0, ''description'': ''''}','2026-05-11 12:25:37');
INSERT INTO audit_logs VALUES(322,1,'update_product','product',11,'{''product_name'': ''破碎锤外壳'', ''model'': ''SB81'', ''spec'': ''360'', ''upper_opening'': ''360'', ''plate_thickness'': ''16'', ''weight'': 0.0, ''description'': ''''}','2026-05-11 12:25:37');
INSERT INTO audit_logs VALUES(323,1,'update_product','product',10,'{''product_name'': ''破碎锤外壳'', ''model'': ''SB81'', ''spec'': ''三角型'', ''upper_opening'': ''360'', ''plate_thickness'': ''20'', ''weight'': 0.0, ''description'': ''''}','2026-05-11 12:25:38');
INSERT INTO audit_logs VALUES(324,1,'update_product','product',9,'{''product_name'': ''破碎锤外壳'', ''model'': ''SB81'', ''spec'': ''三角型'', ''upper_opening'': ''360'', ''plate_thickness'': ''22'', ''weight'': 620.0, ''description'': ''''}','2026-05-11 12:25:38');
INSERT INTO audit_logs VALUES(325,1,'update_product','product',8,'{''product_name'': ''破碎锤外壳'', ''model'': ''SB81'', ''spec'': ''三角型'', ''upper_opening'': ''360'', ''plate_thickness'': ''20'', ''weight'': 510.0, ''description'': ''''}','2026-05-11 12:25:38');
INSERT INTO audit_logs VALUES(326,1,'update_product','product',7,'{''product_name'': ''破碎锤外壳'', ''model'': ''SB81'', ''spec'': ''三角型'', ''upper_opening'': ''440'', ''plate_thickness'': ''18'', ''weight'': 580.0, ''description'': ''''}','2026-05-11 12:25:38');
INSERT INTO audit_logs VALUES(327,1,'update_product','product',6,'{''product_name'': ''破碎锤外壳'', ''model'': ''SB81'', ''spec'': ''静音型'', ''upper_opening'': ''360'', ''plate_thickness'': ''18'', ''weight'': 550.0, ''description'': ''''}','2026-05-11 12:25:38');
INSERT INTO audit_logs VALUES(328,1,'update_product','product',5,'{''product_name'': ''破碎锤外壳'', ''model'': ''SB81'', ''spec'': ''分体直型'', ''upper_opening'': ''360'', ''plate_thickness'': ''18'', ''weight'': 800.0, ''description'': ''双筋''}','2026-05-11 12:25:38');
INSERT INTO audit_logs VALUES(329,1,'update_product','product',4,'{''product_name'': ''破碎锤外壳'', ''model'': ''SB81'', ''spec'': ''一体直型'', ''upper_opening'': ''360'', ''plate_thickness'': ''18'', ''weight'': 600.0, ''description'': ''''}','2026-05-11 12:25:38');
INSERT INTO audit_logs VALUES(330,1,'delete_product','product',11,'','2026-05-11 12:26:36');
INSERT INTO audit_logs VALUES(331,1,'create_process_price','process_price',2,'{''product_id'': 34, ''process_id'': 322, ''unit_price'': 10, ''remark'': ''测试-产品特定价''}','2026-05-11 12:42:53');
INSERT INTO audit_logs VALUES(332,1,'create_process_price','process_price',3,'{''process_id'': 322, ''unit_price'': 5, ''remark'': ''默认价格''}','2026-05-11 12:42:53');
INSERT INTO audit_logs VALUES(333,1,'update_process_price','process_price',2,'{''product_id'': '''', ''process_id'': 322, ''unit_price'': 10, ''effective_date'': '''', ''remark'': ''测试-产品特定价''}','2026-05-11 12:59:53');
INSERT INTO audit_logs VALUES(334,1,'create_process_price','process_price',4,'{''product_id'': 10, ''process_id'': 332, ''unit_price'': 90, ''effective_date'': '''', ''remark'': ''''}','2026-05-11 13:01:25');
INSERT INTO audit_logs VALUES(335,1,'create_process_price','process_price',5,'{''product_id'': 34, ''process_id'': 338, ''unit_price'': 120, ''effective_date'': '''', ''remark'': ''''}','2026-05-11 13:05:04');
INSERT INTO audit_logs VALUES(336,1,'update_process','process',322,'{''name'': ''下料'', ''description'': ''原材料切割''}','2026-05-11 13:22:08');
INSERT INTO audit_logs VALUES(337,1,'create_process','process',415,'测试工序','2026-05-11 13:24:58');
INSERT INTO audit_logs VALUES(338,1,'create_process','process',422,'铣削','2026-05-11 13:27:03');
INSERT INTO audit_logs VALUES(339,1,'create_process','process',423,'钻孔','2026-05-11 13:28:04');
INSERT INTO audit_logs VALUES(340,1,'create_process_price','process_price',6,'{''product_id'': 21, ''process_id'': 195, ''unit_price'': 10, ''effective_date'': '''', ''remark'': ''''}','2026-05-11 13:38:37');
INSERT INTO audit_logs VALUES(341,1,'create_process_price','process_price',7,'{''product_id'': 34, ''process_id'': 322, ''unit_price'': 8.8, ''remark'': ''批量测试''}','2026-05-11 13:49:53');
INSERT INTO audit_logs VALUES(342,1,'create_process_price','process_price',8,'{''product_id'': 34, ''process_id'': 195, ''unit_price'': 8.8, ''remark'': ''批量测试''}','2026-05-11 13:49:53');
INSERT INTO audit_logs VALUES(343,1,'create_process_price','process_price',9,'{''product_id'': 9, ''process_id'': 195, ''unit_price'': 10, ''effective_date'': '''', ''status'': ''active'', ''remark'': ''''}','2026-05-11 13:51:30');
INSERT INTO audit_logs VALUES(344,1,'create_process_price','process_price',10,'{''product_id'': 9, ''process_id'': 324, ''unit_price'': 10, ''effective_date'': '''', ''status'': ''active'', ''remark'': ''''}','2026-05-11 13:51:30');
INSERT INTO audit_logs VALUES(345,1,'create_process_price','process_price',11,'{''product_id'': 9, ''process_id'': 329, ''unit_price'': 10, ''effective_date'': '''', ''status'': ''active'', ''remark'': ''''}','2026-05-11 13:51:30');
INSERT INTO audit_logs VALUES(346,1,'create_process_price','process_price',12,'{''product_id'': 9, ''process_id'': 328, ''unit_price'': 10, ''effective_date'': '''', ''status'': ''active'', ''remark'': ''''}','2026-05-11 13:51:30');
INSERT INTO audit_logs VALUES(347,1,'create_process_price','process_price',13,'{''product_id'': 9, ''process_id'': 223, ''unit_price'': 10, ''effective_date'': '''', ''status'': ''active'', ''remark'': ''''}','2026-05-11 13:51:30');
INSERT INTO audit_logs VALUES(348,1,'create_process_price','process_price',14,'{''product_id'': 9, ''process_id'': 330, ''unit_price'': 10, ''effective_date'': '''', ''status'': ''active'', ''remark'': ''''}','2026-05-11 13:51:30');
INSERT INTO audit_logs VALUES(349,1,'create_process_price','process_price',15,'{''product_id'': 8, ''process_id'': 195, ''unit_price'': 50, ''effective_date'': '''', ''status'': ''active'', ''remark'': ''''}','2026-05-11 13:59:43');
INSERT INTO audit_logs VALUES(350,1,'create_process_price','process_price',16,'{''product_id'': 8, ''process_id'': 223, ''unit_price'': 23, ''effective_date'': '''', ''status'': ''active'', ''remark'': ''''}','2026-05-11 13:59:43');
INSERT INTO audit_logs VALUES(351,1,'create_process_price','process_price',17,'{''product_id'': 8, ''process_id'': 324, ''unit_price'': 20, ''effective_date'': '''', ''status'': ''active'', ''remark'': ''''}','2026-05-11 13:59:43');
INSERT INTO audit_logs VALUES(352,1,'create_process_price','process_price',18,'{''product_id'': 8, ''process_id'': 330, ''unit_price'': 18, ''effective_date'': '''', ''status'': ''active'', ''remark'': ''''}','2026-05-11 13:59:43');
INSERT INTO audit_logs VALUES(353,1,'create_process_price','process_price',19,'{''product_id'': 8, ''process_id'': 328, ''unit_price'': 60, ''effective_date'': '''', ''status'': ''active'', ''remark'': ''''}','2026-05-11 13:59:43');
INSERT INTO audit_logs VALUES(354,1,'create_process_price','process_price',20,'{''product_id'': 8, ''process_id'': 329, ''unit_price'': 10, ''effective_date'': '''', ''status'': ''active'', ''remark'': ''''}','2026-05-11 13:59:43');
INSERT INTO audit_logs VALUES(355,1,'update_process','process',328,'{''description'': ''工件组装''}','2026-05-12 12:27:49');
INSERT INTO audit_logs VALUES(356,1,'update_process','process',195,'{''description'': ''焊接工件''}','2026-05-12 12:27:49');
INSERT INTO audit_logs VALUES(357,1,'delete_process','process',415,'','2026-05-12 12:27:57');
INSERT INTO audit_logs VALUES(358,1,'create_process','process',496,'车套','2026-05-12 12:28:39');
INSERT INTO audit_logs VALUES(359,1,'create_process_route','process_route',1,'测试路线','2026-05-12 13:22:04');
INSERT INTO audit_logs VALUES(360,1,'update_process_route','process_route',1,'测试路线','2026-05-12 13:25:10');
INSERT INTO audit_logs VALUES(361,1,'apply_process_route','order',3,'route_id=1','2026-05-12 13:25:26');
INSERT INTO audit_logs VALUES(362,1,'create_customer','customer',3,'中天博运','2026-05-13 09:49:03');
INSERT INTO audit_logs VALUES(363,1,'create_order','order',5,'WK2605130001','2026-05-13 09:49:36');
INSERT INTO audit_logs VALUES(364,1,'update_order','order',5,'{''order_no'': ''WK2605130001'', ''customer'': ''中天博运'', ''customer_id'': 3, ''product_name'': ''200'', ''quantity'': 2, ''plan_start'': ''2026-05-14'', ''plan_end'': ''2026-05-22'', ''remark'': '''', ''route_id'': ''''}','2026-05-14 01:55:52');
INSERT INTO audit_logs VALUES(365,1,'create_order','order',6,'WK2605150001','2026-05-15 02:19:00');
INSERT INTO audit_logs VALUES(366,1,'apply_process_route','order',6,'route_id=1','2026-05-15 02:19:53');
INSERT INTO audit_logs VALUES(367,1,'update_order','order',6,'{''order_no'': ''WK2605150001'', ''customer'': ''正坤机械'', ''customer_id'': 1, ''product_id'': None, ''product_name'': ''外壳'', ''quantity'': 10, ''plan_start'': ''2026-05-15'', ''plan_end'': ''2026-05-28'', ''remark'': '''', ''route_id'': 1}','2026-05-15 02:20:00');
INSERT INTO audit_logs VALUES(368,1,'apply_process_route','order',5,'route_id=1','2026-05-15 02:20:20');
INSERT INTO audit_logs VALUES(369,1,'delete_order','order',5,'','2026-05-15 02:20:45');
INSERT INTO audit_logs VALUES(370,1,'delete_order','order',4,'','2026-05-15 02:20:47');
INSERT INTO audit_logs VALUES(371,1,'delete_order','order',3,'','2026-05-15 02:20:48');
INSERT INTO audit_logs VALUES(372,1,'delete_order','order',2,'','2026-05-15 02:20:49');
INSERT INTO audit_logs VALUES(373,1,'delete_order','order',1,'','2026-05-15 02:20:51');
INSERT INTO audit_logs VALUES(374,1,'create_order','order',7,'WK2605150002','2026-05-15 02:21:30');
INSERT INTO audit_logs VALUES(375,1,'update_order','order',7,'{''order_no'': ''WK2605150002'', ''customer'': ''韩运机械'', ''customer_id'': 2, ''product_id'': None, ''product_name'': ''外壳'', ''quantity'': 10, ''plan_start'': ''2026-05-15'', ''plan_end'': ''2026-05-31'', ''remark'': '''', ''route_id'': ''''}','2026-05-15 02:21:42');
INSERT INTO audit_logs VALUES(376,1,'delete_order','order',6,'','2026-05-15 02:21:47');
INSERT INTO audit_logs VALUES(377,1,'update_order','order',7,'{''order_no'': ''WK2605150002'', ''customer'': ''韩运机械'', ''customer_id'': 2, ''product_id'': 21, ''product_name'': ''外壳'', ''quantity'': 10, ''plan_start'': ''2026-05-15'', ''plan_end'': ''2026-05-31'', ''remark'': '''', ''route_id'': ''''}','2026-05-15 02:22:03');
INSERT INTO audit_logs VALUES(378,1,'create_order','order',8,'WK260515TEST5','2026-05-15 04:45:43');
INSERT INTO audit_logs VALUES(379,1,'create_order','order',9,'WK260515FINAL','2026-05-15 04:50:27');
INSERT INTO audit_logs VALUES(380,1,'create_order','order',10,'WK260515FRONT','2026-05-15 04:50:53');
INSERT INTO audit_logs VALUES(381,1,'update_order','order',9,'{''product_id'': 34, ''quantity'': 20}','2026-05-15 04:50:53');
INSERT INTO audit_logs VALUES(382,1,'mobile_report','order',7,'process=322 serial=None by=系统管理员','2026-05-16 17:19:52');
INSERT INTO audit_logs VALUES(383,1,'report_normal','order',7,'process=322 qty=3 type=normal','2026-05-16 17:20:20');
INSERT INTO audit_logs VALUES(384,1,'update_process_price','process_price',17,'{''product_id'': 8, ''process_id'': 324, ''unit_price'': 20, ''effective_date'': '''', ''status'': ''active'', ''remark'': ''''}','2026-05-18 11:31:36');
INSERT INTO audit_logs VALUES(385,1,'update_process_price','process_price',19,'{''product_id'': 8, ''process_id'': 328, ''unit_price'': 60, ''effective_date'': '''', ''status'': ''active'', ''remark'': ''''}','2026-05-18 11:31:36');
INSERT INTO audit_logs VALUES(386,1,'update_process_price','process_price',16,'{''product_id'': 8, ''process_id'': 223, ''unit_price'': 23, ''effective_date'': '''', ''status'': ''active'', ''remark'': ''''}','2026-05-18 11:31:36');
INSERT INTO audit_logs VALUES(387,1,'create_process_price','process_price',21,'{''product_id'': 8, ''process_id'': 218, ''unit_price'': 5, ''effective_date'': '''', ''status'': ''active'', ''remark'': ''''}','2026-05-18 11:31:36');
INSERT INTO audit_logs VALUES(388,1,'create_process_price','process_price',22,'{''product_id'': 8, ''process_id'': 322, ''unit_price'': 50, ''effective_date'': '''', ''status'': ''active'', ''remark'': ''''}','2026-05-18 11:31:36');
INSERT INTO audit_logs VALUES(389,1,'update_process_price','process_price',20,'{''product_id'': 8, ''process_id'': 329, ''unit_price'': 10, ''effective_date'': '''', ''status'': ''active'', ''remark'': ''''}','2026-05-18 11:31:36');
INSERT INTO audit_logs VALUES(390,1,'update_process_price','process_price',18,'{''product_id'': 8, ''process_id'': 330, ''unit_price'': 18, ''effective_date'': '''', ''status'': ''active'', ''remark'': ''''}','2026-05-18 11:31:37');
INSERT INTO audit_logs VALUES(391,1,'update_process_price','process_price',15,'{''product_id'': 8, ''process_id'': 195, ''unit_price'': 50, ''effective_date'': '''', ''status'': ''active'', ''remark'': ''''}','2026-05-18 11:31:37');
INSERT INTO audit_logs VALUES(392,1,'create_process_price','process_price',23,'{''product_id'': 8, ''process_id'': 207, ''unit_price'': 5, ''effective_date'': '''', ''status'': ''active'', ''remark'': ''''}','2026-05-18 11:31:37');
INSERT INTO audit_logs VALUES(393,1,'create_order','order',8,'WK2605180001','2026-05-18 12:08:31');
INSERT INTO audit_logs VALUES(394,1,'update_user','user',2,'{''username'': ''worker1'', ''name'': ''张三'', ''employee_no'': ''0001'', ''phone'': '''', ''role'': ''worker'', ''password'': '''', ''process_ids'': ''322''}','2026-05-18 12:52:25');
INSERT INTO audit_logs VALUES(395,1,'update_user','user',3,'{''username'': ''worker2'', ''name'': ''李四'', ''employee_no'': '''', ''phone'': '''', ''role'': ''worker'', ''password'': '''', ''process_ids'': ''328''}','2026-05-18 12:52:31');
INSERT INTO audit_logs VALUES(396,1,'update_user','user',3,'{''username'': ''worker2'', ''name'': ''李四'', ''employee_no'': ''0002'', ''phone'': '''', ''role'': ''worker'', ''password'': '''', ''process_ids'': ''328''}','2026-05-18 12:56:12');
INSERT INTO audit_logs VALUES(397,1,'update_user','user',4,'{''username'': ''worker3'', ''name'': ''王五'', ''employee_no'': ''0003'', ''phone'': '''', ''role'': ''worker'', ''password'': '''', ''process_ids'': ''195''}','2026-05-18 13:02:09');
INSERT INTO audit_logs VALUES(398,1,'update_user','user',5,'{''username'': ''worker4'', ''name'': ''赵六'', ''employee_no'': ''0005'', ''phone'': '''', ''role'': ''worker'', ''password'': '''', ''process_ids'': ''329''}','2026-05-18 13:02:19');
INSERT INTO audit_logs VALUES(399,1,'update_user','user',271,'{''username'': ''worker5'', ''name'': ''朱一'', ''employee_no'': ''0004'', ''phone'': '''', ''role'': ''worker'', ''password'': '''', ''process_ids'': ''324''}','2026-05-18 13:03:37');
INSERT INTO audit_logs VALUES(400,1,'mobile_report','order',8,'process=322 serial=WK2605180001-002 by=系统管理员','2026-05-18 13:17:17');
INSERT INTO audit_logs VALUES(401,2,'mobile_report','order',8,'process=322 serial=WK2605180001-003 by=张三','2026-05-18 13:18:57');
INSERT INTO audit_logs VALUES(402,2,'mobile_report','order',8,'process=322 serial=WK2605180001-009 by=张三','2026-05-18 13:19:08');
INSERT INTO audit_logs VALUES(403,2,'mobile_report','order',8,'process=322 serial=WK2605180001-009 by=张三','2026-05-18 13:19:19');
INSERT INTO audit_logs VALUES(404,1,'create_order','order',9,'WK2605180002','2026-05-18 14:21:48');
INSERT INTO audit_logs VALUES(405,1,'create_order','order',10,'WK2605180003','2026-05-18 14:22:14');
INSERT INTO audit_logs VALUES(406,1,'create_order','order',11,'WK2605180004','2026-05-18 14:27:02');
INSERT INTO audit_logs VALUES(407,1,'create_order','order',12,'WK2605180005','2026-05-18 14:27:47');
INSERT INTO audit_logs VALUES(408,1,'create_process','process',983,'加工分体下端面','2026-05-19 06:21:12');
INSERT INTO audit_logs VALUES(409,1,'create_process','process',984,'加工分体上端面','2026-05-19 06:22:39');
INSERT INTO audit_logs VALUES(410,1,'update_process','process',223,'{''name'': ''喷漆'', ''description'': ''喷涂防锈漆'', ''seq_order'': 6}','2026-05-19 06:23:15');
INSERT INTO audit_logs VALUES(411,1,'update_process','process',324,'{''name'': ''打磨'', ''description'': ''清除工件表面焊接飞溅，焊疤'', ''seq_order'': 5}','2026-05-19 06:23:56');
INSERT INTO audit_logs VALUES(412,1,'create_process_route','process_route',2,'三角型外壳标准流程','2026-05-19 06:35:01');
INSERT INTO audit_logs VALUES(413,1,'create_process_route','process_route',3,'静音型外壳标准流程','2026-05-19 06:36:36');
INSERT INTO audit_logs VALUES(414,1,'delete_process_route','process_route',1,'','2026-05-19 06:36:52');
INSERT INTO audit_logs VALUES(415,1,'create_process','process',985,'加工静音下端面','2026-05-19 06:39:06');
INSERT INTO audit_logs VALUES(416,1,'update_process','process',983,'{''name'': ''加工分体下端面'', ''description'': ''使用卧式镗床加工分体型外壳两片外壳的端面'', ''seq_order'': 14}','2026-05-19 06:39:51');
INSERT INTO audit_logs VALUES(417,1,'create_process','process',986,'加工分体吊装孔','2026-05-19 06:42:41');
INSERT INTO audit_logs VALUES(418,1,'delete_order','order',7,'','2026-05-19 13:57:03');
INSERT INTO audit_logs VALUES(419,1,'delete_order','order',8,'','2026-05-19 13:57:05');
INSERT INTO audit_logs VALUES(420,1,'delete_order','order',9,'','2026-05-19 13:57:08');
INSERT INTO audit_logs VALUES(421,1,'delete_order','order',10,'','2026-05-19 13:57:10');
INSERT INTO audit_logs VALUES(422,1,'delete_order','order',11,'','2026-05-19 13:57:12');
INSERT INTO audit_logs VALUES(423,1,'delete_order','order',12,'','2026-05-19 13:57:15');
INSERT INTO audit_logs VALUES(424,1,'create_order','order',13,'WK2605190001','2026-05-19 14:00:27');
INSERT INTO audit_logs VALUES(425,1,'apply_process_route','order',13,'route_id=3','2026-05-19 14:12:52');
INSERT INTO audit_logs VALUES(426,1,'apply_process_route','order',13,'route_id=2','2026-05-19 14:13:04');
INSERT INTO audit_logs VALUES(427,1,'update_order','order',13,'{''order_no'': ''WK2605190001'', ''customer'': ''中天博运'', ''customer_id'': 3, ''product_name'': ''外壳'', ''product_code'': ''SB151-JY-500-25'', ''quantity'': 10, ''plan_start'': ''2026-05-19'', ''plan_end'': ''2026-05-31'', ''remark'': '''', ''route_id'': 2}','2026-05-19 14:13:11');
INSERT INTO audit_logs VALUES(428,1,'create_order','order',14,'WK2605190002','2026-05-19 14:14:24');
INSERT INTO audit_logs VALUES(429,1,'apply_process_route','order',14,'route_id=2','2026-05-19 14:14:32');
INSERT INTO audit_logs VALUES(430,1,'update_order','order',14,'{''order_no'': ''WK2605190002'', ''customer'': ''韩运机械'', ''customer_id'': 2, ''product_name'': ''破碎锤外壳'', ''product_code'': ''SB81-SJ-360-20'', ''quantity'': 10, ''plan_start'': ''2026-05-19'', ''plan_end'': ''2026-05-31'', ''remark'': '''', ''route_id'': 2}','2026-05-19 14:14:38');
INSERT INTO audit_logs VALUES(431,1,'update_process','process',329,'{''description'': ''工件除锈''}','2026-05-19 14:16:48');
INSERT INTO audit_logs VALUES(432,1,'update_process','process',328,'{''description'': ''工件组装''}','2026-05-19 14:16:48');
INSERT INTO audit_logs VALUES(433,1,'update_process','process',329,'{''description'': ''工件除锈''}','2026-05-19 14:16:51');
INSERT INTO audit_logs VALUES(434,1,'update_process','process',328,'{''description'': ''工件组装''}','2026-05-19 14:16:51');
INSERT INTO audit_logs VALUES(435,1,'create_process','process',987,'加工内衬条','2026-05-19 14:24:24');
INSERT INTO audit_logs VALUES(436,1,'create_process','process',988,'加工内衬板','2026-05-19 14:24:37');
INSERT INTO audit_logs VALUES(437,1,'update_process','process',496,'{''name'': ''车边套'', ''description'': '''', ''seq_order'': 13}','2026-05-19 14:29:09');
INSERT INTO audit_logs VALUES(438,1,'create_process','process',989,'车挡圈','2026-05-19 14:29:35');
INSERT INTO audit_logs VALUES(439,1,'update_process','process',423,'{''name'': ''静音外壳钻孔'', ''description'': ''加工折弯静音型外壳圆销孔，氮气室压板螺栓孔'', ''seq_order'': 12}','2026-05-19 14:32:54');
INSERT INTO audit_logs VALUES(440,1,'delete_process','process',422,'','2026-05-19 14:33:09');
INSERT INTO audit_logs VALUES(441,1,'update_process','process',496,'{''description'': ''''}','2026-05-19 14:33:21');
INSERT INTO audit_logs VALUES(442,1,'update_process','process',983,'{''description'': ''使用卧式镗床加工分体型外壳两片外壳的端面''}','2026-05-19 14:33:21');
INSERT INTO audit_logs VALUES(443,1,'update_process','process',496,'{''description'': ''''}','2026-05-19 14:33:23');
INSERT INTO audit_logs VALUES(444,1,'update_process','process',984,'{''description'': ''使用加工中心将分体型外壳连接架的底面加工平整''}','2026-05-19 14:33:23');
INSERT INTO audit_logs VALUES(445,1,'update_process','process',496,'{''description'': ''''}','2026-05-19 14:33:25');
INSERT INTO audit_logs VALUES(446,1,'update_process','process',985,'{''description'': ''使用卧式镗床加工壳体端面''}','2026-05-19 14:33:25');
INSERT INTO audit_logs VALUES(447,1,'update_process','process',496,'{''description'': ''''}','2026-05-19 14:33:27');
INSERT INTO audit_logs VALUES(448,1,'update_process','process',986,'{''description'': ''使用摇臂钻加工分体型外壳上的吊装螺栓孔''}','2026-05-19 14:33:27');
INSERT INTO audit_logs VALUES(449,1,'update_process','process',496,'{''description'': ''''}','2026-05-19 14:33:29');
INSERT INTO audit_logs VALUES(450,1,'update_process','process',987,'{''description'': ''''}','2026-05-19 14:33:29');
INSERT INTO audit_logs VALUES(451,1,'update_process','process',496,'{''description'': ''''}','2026-05-19 14:33:31');
INSERT INTO audit_logs VALUES(452,1,'update_process','process',988,'{''description'': ''''}','2026-05-19 14:33:31');
INSERT INTO audit_logs VALUES(453,1,'create_process','process',990,'火工矫正','2026-05-19 14:35:28');
INSERT INTO audit_logs VALUES(454,1,'create_product','product',35,'内衬条','2026-05-19 15:21:07');
INSERT INTO audit_logs VALUES(455,1,'update_product','product',35,'{''created_at'': ''2026-05-19 15:21:07'', ''description'': '''', ''id'': 35, ''model'': ''SB81'', ''plate_thickness'': ''35'', ''product_code'': ''SB81-360-35'', ''product_name'': ''内衬条'', ''spec'': ''正坤'', ''updated_at'': ''2026-05-19 15:21:07'', ''upper_opening'': ''360'', ''weight'': 7}','2026-05-19 15:22:14');
INSERT INTO audit_logs VALUES(456,1,'create_product','product',36,'外壳','2026-05-19 15:44:31');
INSERT INTO audit_logs VALUES(457,1,'delete_process','process',496,'','2026-05-20 13:38:18');
INSERT INTO audit_logs VALUES(458,1,'delete_process','process',987,'','2026-05-20 13:38:34');
INSERT INTO audit_logs VALUES(459,1,'delete_process','process',988,'','2026-05-20 13:38:38');
INSERT INTO audit_logs VALUES(460,1,'delete_process','process',989,'','2026-05-20 13:38:41');
INSERT INTO audit_logs VALUES(461,1,'create_process','process',1057,'加工内衬条','2026-05-20 13:39:42');
INSERT INTO audit_logs VALUES(462,1,'create_process','process',1058,'加工内衬板','2026-05-20 13:40:01');
INSERT INTO audit_logs VALUES(463,1,'create_process','process',1059,'加工边套','2026-05-20 13:40:20');
INSERT INTO audit_logs VALUES(464,1,'create_process_price','process_price',24,'{''product_id'': 36, ''process_id'': 1057, ''unit_price'': 5, ''effective_date'': ''2026-05-20'', ''status'': ''active'', ''remark'': ''''}','2026-05-20 13:41:34');
INSERT INTO audit_logs VALUES(465,1,'create_process_price','process_price',25,'{''product_id'': 36, ''process_id'': 1058, ''unit_price'': 10, ''effective_date'': ''2026-05-20'', ''status'': ''active'', ''remark'': ''''}','2026-05-20 13:41:34');
INSERT INTO audit_logs VALUES(466,1,'create_process_price','process_price',26,'{''product_id'': 36, ''process_id'': 1059, ''unit_price'': 3, ''effective_date'': ''2026-05-20'', ''status'': ''active'', ''remark'': ''''}','2026-05-20 13:41:34');
INSERT INTO audit_logs VALUES(467,1,'update_product','product',36,'{''created_at'': ''2026-05-19 15:44:30'', ''description'': '''', ''id'': 36, ''model'': ''SB81'', ''plate_thickness'': ''25'', ''product_code'': ''SB81-FT-330-25'', ''product_name'': ''外壳'', ''spec'': ''分体型'', ''style'': ''正坤2-1订单'', ''updated_at'': ''2026-05-19 15:44:30'', ''upper_opening'': ''330'', ''weight'': 900}','2026-05-20 16:03:31');
INSERT INTO audit_logs VALUES(468,1,'save_settings','',0,'{''company_name'': ''郑州韩运工程机械有限公司'', ''contact'': '''', ''phone'': '''', ''address'': '''', ''description'': ''''}','2026-05-21 02:08:36');
INSERT INTO audit_logs VALUES(469,1,'upload_attachment','product',35,'test.txt','2026-05-21 02:18:42');
INSERT INTO audit_logs VALUES(470,1,'create_product','product',37,'外壳','2026-05-21 02:44:45');
INSERT INTO audit_logs VALUES(471,1,'upload_attachment','product',37,'W020111019580182869044.pdf','2026-05-21 02:44:56');
INSERT INTO audit_logs VALUES(472,1,'update_product','product',37,'{''created_at'': ''2026-05-21 02:44:45'', ''description'': '''', ''id'': 37, ''model'': ''SB151'', ''plate_thickness'': ''28'', ''product_code'': ''SB151-SJ-500-28'', ''product_name'': ''外壳'', ''spec'': ''三角型'', ''style'': ''自产'', ''updated_at'': ''2026-05-21 02:44:45'', ''upper_opening'': ''500'', ''weight'': 1005}','2026-05-21 02:45:01');
INSERT INTO audit_logs VALUES(473,1,'upload_attachment','product',37,'微信图片_20260130222701_63_148.jpg','2026-05-21 03:10:58');
INSERT INTO audit_logs VALUES(474,1,'delete_attachment','product',2,'W020111019580182869044.pdf','2026-05-21 03:11:03');
INSERT INTO audit_logs VALUES(475,1,'update_product','product',37,'{''attachment_count'': 1, ''created_at'': ''2026-05-21 02:44:45'', ''description'': '''', ''id'': 37, ''model'': ''SB151'', ''plate_thickness'': ''28'', ''product_code'': ''SB151-SJ-500-28'', ''product_name'': ''外壳'', ''spec'': ''三角型'', ''style'': ''自产'', ''updated_at'': ''2026-05-21 02:45:01'', ''upper_opening'': ''500'', ''weight'': 1005}','2026-05-21 03:11:04');
INSERT INTO audit_logs VALUES(476,1,'upload_attachment','product',36,'IMG_20190829_210551.jpg','2026-05-21 03:11:17');
INSERT INTO audit_logs VALUES(477,1,'update_product','product',36,'{''attachment_count'': 0, ''created_at'': ''2026-05-19 15:44:30'', ''description'': '''', ''id'': 36, ''model'': ''SB81'', ''plate_thickness'': ''25'', ''product_code'': ''SB81-FT-330-25'', ''product_name'': ''外壳'', ''spec'': ''分体型'', ''style'': ''正坤2-1订单'', ''updated_at'': ''2026-05-20 16:03:31'', ''upper_opening'': ''330'', ''weight'': 900}','2026-05-21 03:11:19');
INSERT INTO audit_logs VALUES(478,1,'delete_attachment','product',1,'test.txt','2026-05-21 03:11:24');
INSERT INTO audit_logs VALUES(479,1,'upload_attachment','product',35,'身份证.jpg','2026-05-21 03:11:35');
INSERT INTO audit_logs VALUES(480,1,'update_product','product',35,'{''attachment_count'': 1, ''created_at'': ''2026-05-19 15:21:07'', ''description'': '''', ''id'': 35, ''model'': ''SB81'', ''plate_thickness'': ''35'', ''product_code'': ''SB81-360-35'', ''product_name'': ''内衬条'', ''spec'': ''正坤'', ''style'': '''', ''updated_at'': ''2026-05-19 15:22:14'', ''upper_opening'': ''360'', ''weight'': 7}','2026-05-21 03:11:36');
INSERT INTO audit_logs VALUES(481,1,'create_product','product',38,'边套','2026-05-21 09:38:57');
INSERT INTO audit_logs VALUES(482,1,'create_user','user',1062,'du/杜斌','2026-05-21 13:31:43');
INSERT INTO audit_logs VALUES(483,1,'update_user','user',1062,'{''username'': ''du'', ''name'': ''杜斌'', ''role'': ''admin'', ''employee_no'': '''', ''phone'': '''', ''process_ids'': '''', ''status'': ''active'', ''group_name'': ''普通管理组''}','2026-05-21 13:32:24');
INSERT INTO audit_logs VALUES(484,1,'save_settings','',0,'{''company_name'': ''韩运机械'', ''contact'': '''', ''phone'': '''', ''address'': '''', ''description'': ''''}','2026-05-21 13:34:08');
INSERT INTO audit_logs VALUES(485,1,'update_user','user',1062,'{''username'': ''du'', ''name'': ''杜斌'', ''role'': ''admin'', ''employee_no'': '''', ''phone'': '''', ''process_ids'': '''', ''status'': ''active'', ''group_name'': ''超级管理员''}','2026-05-21 13:52:27');
INSERT INTO audit_logs VALUES(486,1,'update_user','user',1062,'{''username'': ''du'', ''name'': ''杜斌'', ''role'': ''admin'', ''employee_no'': '''', ''phone'': ''13276902993'', ''process_ids'': '''', ''status'': ''active'', ''email'': ''duduanbin1982@gmail.com''}','2026-05-21 13:52:42');
INSERT INTO audit_logs VALUES(487,1,'create_user','user',1078,'testadmin2/测试员2','2026-05-21 13:56:31');
INSERT INTO audit_logs VALUES(488,1,'create_user','user',1084,'testadmin3/测试员3','2026-05-21 13:58:14');
INSERT INTO audit_logs VALUES(489,1,'create_user','user',1090,'admint4/测试员4','2026-05-21 13:59:59');
INSERT INTO audit_logs VALUES(490,1,'create_user','user',1097,'fresh2222/新管','2026-05-21 14:03:42');
INSERT INTO audit_logs VALUES(491,1,'create_user','user',1103,'fresh2304/新管','2026-05-21 14:05:04');
INSERT INTO audit_logs VALUES(492,1,'update_user','user',1062,'{''username'': ''du'', ''name'': ''杜斌'', ''role'': ''admin'', ''employee_no'': '''', ''phone'': ''13276902993'', ''process_ids'': '''', ''status'': ''active'', ''group_name'': ''超级管理员'', ''email'': ''duduanbin1982@gmail.com''}','2026-05-21 14:07:32');
INSERT INTO audit_logs VALUES(493,1,'create_user','user',1109,'sdf/士大夫','2026-05-21 14:09:06');
INSERT INTO audit_logs VALUES(494,1,'update_user','user',1062,'{''username'': ''du'', ''name'': ''杜斌'', ''role'': ''admin'', ''employee_no'': '''', ''phone'': ''13276902993'', ''process_ids'': '''', ''status'': ''active'', ''group_name'': ''超级管理员'', ''email'': ''as@126.com''}','2026-05-21 15:05:30');
INSERT INTO audit_logs VALUES(495,1,'update_user','user',1,'{''username'': ''admin'', ''name'': ''系统管理员'', ''role'': ''admin'', ''employee_no'': '''', ''phone'': '''', ''process_ids'': '''', ''status'': ''active'', ''group_name'': ''系统管理组''}','2026-05-21 15:05:49');
INSERT INTO audit_logs VALUES(496,1,'create_user','user',1110,'xc/现场','2026-05-21 15:07:38');
INSERT INTO audit_logs VALUES(497,1,'create_user','user',1116,'vb/边套','2026-05-21 15:11:00');
INSERT INTO audit_logs VALUES(498,1,'delete_user','user',1116,'','2026-05-21 15:13:06');
INSERT INTO audit_logs VALUES(499,1,'delete_user','user',1110,'','2026-05-21 15:13:09');
INSERT INTO audit_logs VALUES(500,1,'delete_user','user',1109,'','2026-05-21 16:12:53');
INSERT INTO audit_logs VALUES(501,1,'create_product','product',39,'外壳','2026-05-24 02:23:43');
INSERT INTO audit_logs VALUES(502,1,'create_order','order',15,'WK2605240001','2026-05-24 02:25:50');
INSERT INTO audit_logs VALUES(503,1,'create_order','order',16,'WK2605240002','2026-05-24 02:29:54');
INSERT INTO audit_logs VALUES(504,1,'create_product','product',40,'外壳','2026-05-24 13:34:18');
INSERT INTO audit_logs VALUES(505,1,'apply_process_route','order',15,'route_id=3','2026-05-24 15:33:28');
INSERT INTO audit_logs VALUES(506,1,'apply_process_route','order',15,'route_id=2','2026-05-24 15:33:47');
INSERT INTO audit_logs VALUES(507,1,'apply_process_route','order',16,'route_id=3','2026-05-25 02:28:33');
INSERT INTO audit_logs VALUES(508,1,'apply_process_route','order',16,'route_id=3','2026-05-25 02:46:21');
INSERT INTO audit_logs VALUES(509,1,'apply_process_route','order',15,'route_id=2','2026-05-25 02:46:40');
INSERT INTO audit_logs VALUES(510,1,'create_order','order',17,'WK2605250001','2026-05-25 09:35:29');
INSERT INTO audit_logs VALUES(511,1,'create_order','order',18,'WK2605250002','2026-05-25 09:36:06');
INSERT INTO audit_logs VALUES(512,1,'update_order','order',18,'{''order_no'': ''WK2605250002'', ''customer'': ''韩运机械'', ''customer_id'': None, ''product_name'': ''外壳'', ''product_code'': ''外壳-SB81-三角型-10-正坤5-2'', ''quantity'': 4, ''plan_end'': ''2026-05-31'', ''remark'': '''', ''route_id'': 3}','2026-05-25 11:07:42');
INSERT INTO audit_logs VALUES(513,1,'update_order','order',17,'{''order_no'': ''WK2605250001'', ''customer'': ''中天博运'', ''customer_id'': None, ''product_name'': ''外壳'', ''product_code'': ''外壳-SB81-三角型-10-正坤5-2'', ''quantity'': 4, ''plan_end'': ''2026-05-31'', ''remark'': '''', ''route_id'': 2}','2026-05-25 11:08:05');
INSERT INTO audit_logs VALUES(514,1,'update_order','order',15,'{''order_no'': ''WK2605240001'', ''customer'': ''正坤机械'', ''customer_id'': None, ''product_name'': ''外壳'', ''product_code'': ''外壳-SB81-三角型-10-正坤5-2'', ''quantity'': 4, ''plan_end'': ''2026-05-31'', ''remark'': '''', ''route_id'': 2}','2026-05-25 11:08:42');
INSERT INTO audit_logs VALUES(515,1,'update_order','order',16,'{''order_no'': ''WK2605240002'', ''customer'': ''自用'', ''customer_id'': None, ''product_name'': ''破碎锤外壳'', ''product_code'': ''破碎锤外壳-SB121-三角型-440-22'', ''quantity'': 4, ''plan_end'': ''2026-10-01'', ''remark'': '''', ''route_id'': 3}','2026-05-25 11:09:04');
INSERT INTO audit_logs VALUES(516,1,'create_order','order',19,'WK2605250003','2026-05-25 11:31:50');
INSERT INTO audit_logs VALUES(517,1,'create_order','order',20,'WK2605250004','2026-05-25 13:41:14');
INSERT INTO audit_logs VALUES(518,1,'create_order','order',21,'WK2605250005','2026-05-25 13:44:25');
INSERT INTO audit_logs VALUES(519,1,'update_order','order',21,'{''order_no'': ''WK2605250005'', ''customer'': ''韩运机械'', ''customer_id'': 2, ''product_name'': ''破碎锤外壳'', ''product_code'': ''破碎锤外壳-SB121-三角型-440-22'', ''quantity'': 2, ''plan_end'': ''2026-05-29'', ''remark'': '''', ''route_id'': 3}','2026-05-25 14:02:26');
INSERT INTO audit_logs VALUES(520,1,'update_order','order',21,'{''order_no'': ''WK2605250005'', ''customer'': ''韩运机械'', ''customer_id'': 2, ''product_name'': ''破碎锤外壳'', ''product_code'': ''破碎锤外壳-SB121-三角型-440-22'', ''quantity'': 2, ''plan_end'': ''2026-05-26'', ''remark'': '''', ''route_id'': 3}','2026-05-25 14:02:36');
INSERT INTO audit_logs VALUES(521,1,'update_order','order',21,'{''order_no'': ''WK2605250005'', ''customer'': ''韩运机械'', ''customer_id'': 2, ''product_name'': ''破碎锤外壳'', ''product_code'': ''破碎锤外壳-SB121-三角型-440-22'', ''quantity'': 2, ''plan_end'': ''2026-05-29'', ''remark'': '''', ''route_id'': 3}','2026-05-25 14:02:42');
INSERT INTO audit_logs VALUES(522,1,'update_order','order',21,'{''order_no'': ''WK2605250005'', ''customer'': ''韩运机械'', ''customer_id'': 2, ''product_name'': ''破碎锤外壳'', ''product_code'': ''破碎锤外壳-SB121-三角型-440-22'', ''quantity'': 2, ''plan_end'': ''2026-05-29'', ''remark'': '''', ''route_id'': 2}','2026-05-25 14:02:54');
INSERT INTO audit_logs VALUES(523,1,'update_order','order',21,'{''order_no'': ''WK2605250005'', ''customer'': ''韩运机械'', ''customer_id'': 2, ''product_name'': ''破碎锤外壳'', ''product_code'': ''破碎锤外壳-SB121-三角型-440-22'', ''quantity'': 4, ''plan_end'': ''2026-05-29'', ''remark'': '''', ''route_id'': 2}','2026-05-25 14:03:07');
INSERT INTO audit_logs VALUES(524,1,'create_order','order',22,'WK2605260001','2026-05-26 04:24:20');
INSERT INTO audit_logs VALUES(525,1,'create_order','order',23,'WK2605260002','2026-05-26 04:27:36');
INSERT INTO audit_logs VALUES(526,1,'create_order','order',24,'WK2605260003','2026-05-26 04:40:00');
INSERT INTO audit_logs VALUES(527,1,'update_order','order',24,'{''order_no'': ''WK2605260003'', ''customer'': ''中天博运'', ''customer_id'': 3, ''product_name'': ''外壳'', ''product_code'': ''外壳-SB81-三角型-10-正坤5-2'', ''quantity'': 15, ''plan_end'': ''2026-05-31'', ''remark'': '''', ''route_id'': 3}','2026-05-26 05:39:49');
INSERT INTO audit_logs VALUES(528,1,'create_user','user',1227,'18625588632/时文芳','2026-05-26 06:01:50');
INSERT INTO audit_logs VALUES(529,1,'create_user','user',1228,'18239937915/杨冰','2026-05-26 06:49:53');
INSERT INTO audit_logs VALUES(530,1,'delete_user','user',1062,'','2026-05-26 10:09:35');
INSERT INTO audit_logs VALUES(531,1,'create_user','user',1229,'13276902993/杜斌','2026-05-26 10:30:27');
INSERT INTO audit_logs VALUES(532,1,'delete_user','user',1229,'','2026-05-26 10:31:30');
INSERT INTO audit_logs VALUES(533,1,'delete_order','order',24,'','2026-05-26 10:32:58');
INSERT INTO audit_logs VALUES(534,1,'delete_order','order',23,'','2026-05-26 10:33:00');
INSERT INTO audit_logs VALUES(535,1,'delete_order','order',22,'','2026-05-26 10:33:02');
INSERT INTO audit_logs VALUES(536,1,'delete_order','order',21,'','2026-05-26 10:33:04');
INSERT INTO audit_logs VALUES(537,1,'delete_order','order',20,'','2026-05-26 10:33:06');
INSERT INTO audit_logs VALUES(538,1,'delete_order','order',19,'','2026-05-26 10:33:07');
INSERT INTO audit_logs VALUES(539,1,'delete_order','order',16,'','2026-05-26 10:33:09');
INSERT INTO audit_logs VALUES(540,1,'delete_order','order',15,'','2026-05-26 10:33:11');
INSERT INTO audit_logs VALUES(541,1,'delete_order','order',17,'','2026-05-26 10:33:13');
INSERT INTO audit_logs VALUES(542,1,'delete_order','order',18,'','2026-05-26 10:33:14');
INSERT INTO audit_logs VALUES(543,1,'delete_order','order',14,'','2026-05-26 10:33:16');
INSERT INTO audit_logs VALUES(544,1,'create_product','product',41,'外壳','2026-05-26 10:41:04');
INSERT INTO audit_logs VALUES(545,1,'create_product','product',42,'外壳','2026-05-26 10:46:38');
INSERT INTO audit_logs VALUES(546,1,'delete_order','order',13,'','2026-05-26 11:08:41');
INSERT INTO audit_logs VALUES(547,1,'delete_product','product',40,'','2026-05-26 11:08:49');
INSERT INTO audit_logs VALUES(548,1,'delete_product','product',36,'','2026-05-26 11:08:52');
INSERT INTO audit_logs VALUES(549,1,'delete_product','product',35,'','2026-05-26 11:08:55');
INSERT INTO audit_logs VALUES(550,1,'delete_product','product',37,'','2026-05-26 11:08:58');
INSERT INTO audit_logs VALUES(551,1,'create_order','order',14,'WK2605260001','2026-05-26 11:09:27');
INSERT INTO audit_logs VALUES(552,1,'delete_product','product',20,'','2026-05-26 11:09:32');
INSERT INTO audit_logs VALUES(553,1,'delete_product','product',4,'','2026-05-26 11:09:35');
INSERT INTO audit_logs VALUES(554,1,'delete_product','product',5,'','2026-05-26 11:09:38');
INSERT INTO audit_logs VALUES(555,1,'delete_product','product',6,'','2026-05-26 11:09:43');
INSERT INTO audit_logs VALUES(556,1,'delete_product','product',7,'','2026-05-26 11:09:45');
INSERT INTO audit_logs VALUES(557,1,'delete_product','product',8,'','2026-05-26 11:09:47');
INSERT INTO audit_logs VALUES(558,1,'delete_product','product',9,'','2026-05-26 11:09:49');
INSERT INTO audit_logs VALUES(559,1,'delete_product','product',10,'','2026-05-26 11:09:50');
INSERT INTO audit_logs VALUES(560,1,'delete_product','product',21,'','2026-05-26 12:02:30');
INSERT INTO audit_logs VALUES(561,1,'delete_product','product',34,'','2026-05-26 12:02:33');
INSERT INTO audit_logs VALUES(562,1,'delete_product','product',39,'','2026-05-26 12:02:35');
INSERT INTO audit_logs VALUES(563,1,'delete_product','product',41,'','2026-05-26 12:02:40');
INSERT INTO audit_logs VALUES(564,1,'delete_product','product',42,'','2026-05-26 12:02:42');
INSERT INTO audit_logs VALUES(565,1,'create_product','product',43,'外壳','2026-05-26 12:25:36');
INSERT INTO audit_logs VALUES(566,1,'delete_product','product',38,'','2026-05-26 12:26:00');
INSERT INTO audit_logs VALUES(567,1,'create_product','product',44,'内衬板','2026-05-26 12:26:26');
INSERT INTO audit_logs VALUES(568,1,'create_order','order',1,'TEST-1779805811','2026-05-26 14:30:10');
INSERT INTO audit_logs VALUES(569,1,'create_order','order',1,'VERIFY-001','2026-05-26 14:32:23');
INSERT INTO audit_logs VALUES(570,1,'delete_order','order',1,'','2026-05-26 14:32:23');
INSERT INTO audit_logs VALUES(571,1,'create_order','order',1,'VERIFY2-001','2026-05-26 14:47:01');
INSERT INTO audit_logs VALUES(572,1,'delete_order','order',1,'','2026-05-26 14:47:01');
INSERT INTO audit_logs VALUES(573,1,'create_order','order',1,'WK2605260001','2026-05-26 15:43:12');
INSERT INTO audit_logs VALUES(574,1,'create_order','order',2,'WK2605260002','2026-05-26 16:43:21');
INSERT INTO audit_logs VALUES(575,1,'delete_order','order',1,'','2026-05-26 16:43:30');
INSERT INTO audit_logs VALUES(576,1,'create_order','order',3,'TEST-01','2026-05-27 05:50:50');
INSERT INTO audit_logs VALUES(577,1,'create_customer','customer',4,'测试客户','2026-05-27 05:50:51');
INSERT INTO audit_logs VALUES(578,2,'delete_order','order',1,'','2026-05-27 09:10:18');
INSERT INTO audit_logs VALUES(579,2,'create_inventory','inventory',0,'TEST','2026-05-27 09:10:18');
INSERT INTO audit_logs VALUES(580,1,'create_inventory','inventory',0,NULL,'2026-05-27 09:24:10');
INSERT INTO audit_logs VALUES(581,1,'update_process','process',328,'{''description'': ''工件组装''}','2026-05-27 11:59:31');
INSERT INTO audit_logs VALUES(582,1,'update_process','process',195,'{''description'': ''焊接工件''}','2026-05-27 11:59:31');
INSERT INTO audit_logs VALUES(583,1,'create_user','user',1730,'13276902993/杜斌','2026-05-27 12:36:21');
INSERT INTO audit_logs VALUES(584,1,'update_user','user',1227,'{''username'': ''18625588632'', ''name'': ''时文芳'', ''role'': ''admin'', ''employee_no'': '''', ''phone'': ''18625588632'', ''process_ids'': '''', ''status'': ''active'', ''group_name'': ''普通管理组''}','2026-05-27 13:09:11');
INSERT INTO audit_logs VALUES(585,1,'update_user','user',1228,'{''username'': ''18239937915'', ''name'': ''杨冰'', ''role'': ''admin'', ''employee_no'': '''', ''phone'': ''18239937915'', ''process_ids'': '''', ''status'': ''active'', ''group_name'': ''普通管理组''}','2026-05-27 13:09:27');
INSERT INTO audit_logs VALUES(586,2,'mobile_report','order',2,'process=322 serial=WK2605260002-009 by=张三','2026-05-27 13:24:43');
INSERT INTO audit_logs VALUES(587,2,'mobile_report','order',2,'process=322 serial=WK2605260002-005 by=张三','2026-05-27 13:33:09');
INSERT INTO audit_logs VALUES(588,2,'mobile_report','order',2,'process=322 serial=WK2605260002-007 by=张三','2026-05-27 13:37:43');
INSERT INTO audit_logs VALUES(589,2,'mobile_report','order',2,'process=322 serial=WK2605260002-003 by=张三','2026-05-27 13:38:15');
INSERT INTO audit_logs VALUES(590,2,'mobile_report','order',2,'process=322 serial=WK2605260002-008 by=张三','2026-05-27 13:38:58');
INSERT INTO audit_logs VALUES(591,1,'create_order','order',4,'WK2605270001','2026-05-27 14:37:03');
INSERT INTO audit_logs VALUES(592,2,'mobile_report','order',2,'process=322 serial=WK2605260002-001 by=张三','2026-05-27 14:49:51');
INSERT INTO audit_logs VALUES(593,2,'mobile_report','order',2,'process=322 serial=WK2605260002-002 by=张三','2026-05-27 14:50:02');
INSERT INTO audit_logs VALUES(594,2,'mobile_report','order',2,'process=322 serial=WK2605260002-002 by=张三','2026-05-27 14:50:26');
INSERT INTO audit_logs VALUES(595,2,'mobile_report','order',2,'process=322 serial=WK2605260002-002 by=张三','2026-05-27 14:50:35');
INSERT INTO audit_logs VALUES(596,2,'mobile_report','order',2,'process=322 serial=WK2605260002-002 by=张三','2026-05-27 14:50:42');
INSERT INTO audit_logs VALUES(597,2,'mobile_report','order',2,'process=322 serial=WK2605260002-002 by=张三','2026-05-27 14:50:48');
INSERT INTO audit_logs VALUES(598,2,'mobile_report','order',2,'process=328 serial=WK2605260002-002 by=张三','2026-05-27 14:50:54');
INSERT INTO audit_logs VALUES(599,2,'mobile_report','order',2,'process=328 serial=WK2605260002-002 by=张三','2026-05-27 14:51:04');
INSERT INTO audit_logs VALUES(600,2,'mobile_report','order',2,'process=322 serial=WK2605260002-005 by=张三','2026-05-27 14:52:17');
INSERT INTO audit_logs VALUES(601,2,'mobile_report','order',2,'process=328 serial=WK2605260002-005 by=张三','2026-05-27 14:52:25');
INSERT INTO audit_logs VALUES(602,2,'mobile_report','order',2,'process=328 serial=WK2605260002-005 by=张三','2026-05-27 14:52:31');
INSERT INTO audit_logs VALUES(603,2,'mobile_report','order',2,'process=322 serial=WK2605260002-009 by=张三','2026-05-27 15:03:34');
INSERT INTO audit_logs VALUES(604,2,'mobile_report','order',2,'process=328 serial=WK2605260002-009 by=张三','2026-05-27 15:03:42');
INSERT INTO audit_logs VALUES(605,2,'mobile_report','order',2,'process=195 serial=WK2605260002-009 by=张三','2026-05-27 15:03:53');
INSERT INTO audit_logs VALUES(606,2,'mobile_report','order',2,'process=329 serial=WK2605260002-009 by=张三','2026-05-27 15:04:03');
INSERT INTO audit_logs VALUES(607,2,'mobile_report','order',2,'process=324 serial=WK2605260002-009 by=张三','2026-05-27 15:04:11');
INSERT INTO audit_logs VALUES(608,2,'mobile_report','order',2,'process=330 serial=WK2605260002-009 by=张三','2026-05-27 15:04:17');
INSERT INTO audit_logs VALUES(609,2,'mobile_report','order',2,'process=223 serial=WK2605260002-009 by=张三','2026-05-27 15:04:24');
INSERT INTO audit_logs VALUES(610,2,'mobile_report','order',2,'process=322 serial=WK2605260002-001 by=张三','2026-05-27 15:05:09');
INSERT INTO audit_logs VALUES(611,2,'mobile_report','order',2,'process=322 serial=WK2605260002-004 by=张三','2026-05-27 15:05:43');
INSERT INTO audit_logs VALUES(612,2,'mobile_report','order',2,'process=322 serial=WK2605260002-003 by=张三','2026-05-27 15:06:00');
INSERT INTO audit_logs VALUES(613,2,'mobile_report','order',2,'process=322 serial=WK2605260002-006 by=张三','2026-05-27 15:12:12');
INSERT INTO audit_logs VALUES(614,2,'mobile_report','order',2,'process=328 serial=WK2605260002-005 by=张三','2026-05-27 15:12:26');
INSERT INTO audit_logs VALUES(615,2,'mobile_report','order',2,'process=322 serial=WK2605260002-008 by=张三','2026-05-27 15:27:56');
INSERT INTO audit_logs VALUES(616,1,'create_position','position',1,'name=切割工','2026-05-28 05:35:21');
INSERT INTO audit_logs VALUES(617,1,'update_user','user',2,'{''username'': ''worker1'', ''name'': ''张三'', ''role'': ''worker'', ''employee_no'': ''0001'', ''phone'': '''', ''process_ids'': ''322'', ''status'': ''active'', ''position_id'': 1}','2026-05-28 05:35:36');
INSERT INTO audit_logs VALUES(618,1,'create_position','position',2,'name=铆工','2026-05-28 05:36:37');
INSERT INTO audit_logs VALUES(619,1,'create_position','position',3,'name=焊工','2026-05-28 05:36:48');
INSERT INTO audit_logs VALUES(620,1,'create_position','position',4,'name=抛丸工','2026-05-28 05:37:16');
INSERT INTO audit_logs VALUES(621,1,'create_position','position',5,'name=打磨工','2026-05-28 05:37:37');
INSERT INTO audit_logs VALUES(622,1,'create_position','position',6,'name=喷漆工','2026-05-28 05:47:11');
INSERT INTO audit_logs VALUES(623,1,'create_position','position',7,'name=镗工','2026-05-28 05:47:38');
INSERT INTO audit_logs VALUES(624,1,'update_user','user',2,'{''username'': ''worker1'', ''name'': ''张三'', ''role'': ''worker'', ''employee_no'': ''0001'', ''phone'': '''', ''process_ids'': ''322'', ''status'': ''active'', ''position_id'': 1}','2026-05-28 05:48:10');
INSERT INTO audit_logs VALUES(625,1,'update_user','user',2,'{''username'': ''worker1'', ''name'': ''张三'', ''role'': ''worker'', ''employee_no'': ''0001'', ''phone'': '''', ''position_id'': 1, ''status'': ''active''}','2026-05-28 06:00:56');
INSERT INTO audit_logs VALUES(626,1,'update_user','user',2,'{''username'': ''worker1'', ''name'': ''张三'', ''role'': ''worker'', ''employee_no'': ''0001'', ''phone'': '''', ''position_id'': 1, ''status'': ''active''}','2026-05-28 06:12:10');
INSERT INTO audit_logs VALUES(627,1,'update_user','user',2,'{''username'': ''worker1'', ''name'': ''张三'', ''role'': ''worker'', ''employee_no'': ''0001'', ''phone'': '''', ''position_id'': 1, ''status'': ''active''}','2026-05-28 06:17:02');
INSERT INTO audit_logs VALUES(628,1,'update_user','user',3,'{''username'': ''worker2'', ''name'': ''李四'', ''role'': ''worker'', ''employee_no'': ''0002'', ''phone'': '''', ''position_id'': 2, ''status'': ''active''}','2026-05-28 06:19:52');
INSERT INTO audit_logs VALUES(629,1,'update_user','user',4,'{''username'': ''worker3'', ''name'': ''王五'', ''role'': ''worker'', ''employee_no'': ''0003'', ''phone'': '''', ''position_id'': 3, ''status'': ''active''}','2026-05-28 06:19:59');
INSERT INTO audit_logs VALUES(630,1,'update_user','user',4,'{''username'': ''worker3'', ''name'': ''王五'', ''role'': ''worker'', ''employee_no'': ''0003'', ''phone'': '''', ''position_id'': 4, ''status'': ''active''}','2026-05-28 06:20:07');
INSERT INTO audit_logs VALUES(631,1,'update_user','user',4,'{''username'': ''worker3'', ''name'': ''王五'', ''role'': ''worker'', ''employee_no'': ''0003'', ''phone'': '''', ''position_id'': 3, ''status'': ''active''}','2026-05-28 06:20:14');
INSERT INTO audit_logs VALUES(632,1,'update_user','user',5,'{''username'': ''worker4'', ''name'': ''赵六'', ''role'': ''worker'', ''employee_no'': ''0005'', ''phone'': '''', ''position_id'': 4, ''status'': ''active''}','2026-05-28 06:20:20');
INSERT INTO audit_logs VALUES(633,1,'update_user','user',271,'{''username'': ''worker5'', ''name'': ''朱一'', ''role'': ''worker'', ''employee_no'': ''0004'', ''phone'': '''', ''position_id'': 5, ''status'': ''active''}','2026-05-28 06:20:25');
INSERT INTO audit_logs VALUES(634,1,'create_user','user',1791,'worker6/阿达','2026-05-28 06:21:30');
INSERT INTO audit_logs VALUES(635,1,'delete_process_price','process_price',16,'','2026-05-28 06:53:29');
INSERT INTO audit_logs VALUES(636,1,'delete_process_price','process_price',21,'','2026-05-28 06:53:29');
INSERT INTO audit_logs VALUES(637,1,'delete_process_price','process_price',19,'','2026-05-28 06:53:29');
INSERT INTO audit_logs VALUES(638,1,'delete_process_price','process_price',20,'','2026-05-28 06:53:29');
INSERT INTO audit_logs VALUES(639,1,'delete_process_price','process_price',17,'','2026-05-28 06:53:29');
INSERT INTO audit_logs VALUES(640,1,'delete_process_price','process_price',23,'','2026-05-28 06:53:29');
INSERT INTO audit_logs VALUES(641,1,'delete_process_price','process_price',18,'','2026-05-28 06:53:29');
INSERT INTO audit_logs VALUES(642,1,'delete_process_price','process_price',22,'','2026-05-28 06:53:29');
INSERT INTO audit_logs VALUES(643,1,'delete_process_price','process_price',15,'','2026-05-28 06:53:29');
INSERT INTO audit_logs VALUES(644,1,'delete_process_price','process_price',9,'','2026-05-28 06:53:31');
INSERT INTO audit_logs VALUES(645,1,'delete_process_price','process_price',12,'','2026-05-28 06:53:31');
INSERT INTO audit_logs VALUES(646,1,'delete_process_price','process_price',11,'','2026-05-28 06:53:31');
INSERT INTO audit_logs VALUES(647,1,'delete_process_price','process_price',10,'','2026-05-28 06:53:31');
INSERT INTO audit_logs VALUES(648,1,'delete_process_price','process_price',13,'','2026-05-28 06:53:32');
INSERT INTO audit_logs VALUES(649,1,'delete_process_price','process_price',14,'','2026-05-28 06:53:32');
INSERT INTO audit_logs VALUES(650,1,'delete_process_price','process_price',4,'','2026-05-28 06:53:33');
INSERT INTO audit_logs VALUES(651,1,'delete_process_price','process_price',6,'','2026-05-28 06:53:35');
INSERT INTO audit_logs VALUES(652,1,'delete_process_price','process_price',7,'','2026-05-28 06:53:37');
INSERT INTO audit_logs VALUES(653,1,'delete_process_price','process_price',8,'','2026-05-28 06:53:37');
INSERT INTO audit_logs VALUES(654,1,'delete_process_price','process_price',5,'','2026-05-28 06:53:37');
INSERT INTO audit_logs VALUES(655,1,'delete_process_price','process_price',24,'','2026-05-28 06:53:39');
INSERT INTO audit_logs VALUES(656,1,'delete_process_price','process_price',25,'','2026-05-28 06:53:39');
INSERT INTO audit_logs VALUES(657,1,'delete_process_price','process_price',26,'','2026-05-28 06:53:39');
INSERT INTO audit_logs VALUES(658,1,'delete_process_price','process_price',3,'','2026-05-28 06:53:40');
INSERT INTO audit_logs VALUES(659,1,'delete_process_price','process_price',2,'','2026-05-28 06:53:40');
INSERT INTO audit_logs VALUES(660,1,'delete_order','order',3,'','2026-05-28 08:46:02');
INSERT INTO audit_logs VALUES(661,1,'create_product','product',45,'外壳','2026-05-28 08:51:26');
INSERT INTO audit_logs VALUES(662,1,'create_product','product',46,'外壳','2026-05-28 08:52:57');
INSERT INTO audit_logs VALUES(663,1,'create_product','product',47,'外壳','2026-05-28 08:58:35');
INSERT INTO audit_logs VALUES(664,1,'create_product','product',48,'外壳','2026-05-28 09:04:24');
INSERT INTO audit_logs VALUES(665,1,'create_product','product',49,'外壳','2026-05-28 10:02:53');
INSERT INTO audit_logs VALUES(666,1,'create_product','product',50,'外壳','2026-05-28 10:03:53');
INSERT INTO audit_logs VALUES(667,1,'create_product','product',51,'外壳','2026-05-28 10:05:13');
INSERT INTO audit_logs VALUES(668,1,'create_product','product',52,'外壳','2026-05-28 10:06:32');
INSERT INTO audit_logs VALUES(669,1,'create_product','product',53,'外壳','2026-05-28 10:07:53');
INSERT INTO audit_logs VALUES(670,1,'create_product','product',54,'外壳','2026-05-28 10:09:40');
INSERT INTO audit_logs VALUES(671,1,'create_product','product',55,'外壳','2026-05-28 10:10:17');
INSERT INTO audit_logs VALUES(672,1,'create_product','product',56,'外壳','2026-05-28 10:11:02');
INSERT INTO audit_logs VALUES(673,1,'create_product','product',57,'外壳','2026-05-28 10:33:45');
INSERT INTO audit_logs VALUES(674,1,'create_product','product',58,'外壳','2026-05-28 10:36:25');
INSERT INTO audit_logs VALUES(675,1,'create_product','product',59,'外壳','2026-05-28 10:37:09');
INSERT INTO audit_logs VALUES(676,1,'create_product','product',60,'外壳','2026-05-28 10:37:44');
INSERT INTO audit_logs VALUES(677,1,'create_product','product',61,'外壳','2026-05-28 10:38:15');
INSERT INTO audit_logs VALUES(678,1,'create_product','product',62,'外壳','2026-05-28 10:38:36');
INSERT INTO audit_logs VALUES(679,1,'create_product','product',63,'外壳','2026-05-28 10:38:59');
INSERT INTO audit_logs VALUES(680,1,'create_product','product',64,'外壳','2026-05-28 10:39:59');
INSERT INTO audit_logs VALUES(681,1,'create_product','product',65,'外壳','2026-05-28 10:41:03');
INSERT INTO audit_logs VALUES(682,1,'create_product','product',66,'外壳','2026-05-28 10:41:33');
INSERT INTO audit_logs VALUES(683,1,'create_product','product',67,'外壳','2026-05-28 10:42:27');
INSERT INTO audit_logs VALUES(684,1,'delete_product','product',43,'','2026-05-28 10:46:43');
INSERT INTO audit_logs VALUES(685,1,'delete_order','order',4,'','2026-05-28 10:47:05');
INSERT INTO audit_logs VALUES(686,1,'create_product','product',68,'外壳','2026-05-28 10:49:09');
INSERT INTO audit_logs VALUES(687,1,'create_product','product',69,'外壳','2026-05-28 10:49:29');
INSERT INTO audit_logs VALUES(688,1,'create_product','product',70,'外壳','2026-05-28 10:49:54');
INSERT INTO audit_logs VALUES(689,1,'create_product','product',71,'外壳','2026-05-28 10:57:27');
INSERT INTO audit_logs VALUES(690,1,'create_product','product',72,'外壳','2026-05-28 10:57:59');
INSERT INTO audit_logs VALUES(691,1,'create_product','product',73,'外壳','2026-05-28 10:58:37');
INSERT INTO audit_logs VALUES(692,1,'create_product','product',74,'外壳','2026-05-28 10:59:46');
INSERT INTO audit_logs VALUES(693,1,'create_product','product',75,'外壳','2026-05-28 11:00:16');
INSERT INTO audit_logs VALUES(694,1,'create_product','product',76,'外壳','2026-05-28 11:01:06');
INSERT INTO audit_logs VALUES(695,1,'create_product','product',77,'外壳','2026-05-28 11:02:25');
INSERT INTO audit_logs VALUES(696,1,'delete_product','product',76,'','2026-05-28 11:02:30');
INSERT INTO audit_logs VALUES(697,1,'delete_product','product',77,'','2026-05-28 11:03:38');
INSERT INTO audit_logs VALUES(698,1,'create_product','product',78,'外壳','2026-05-28 11:59:25');
INSERT INTO audit_logs VALUES(699,1,'create_product','product',79,'外壳','2026-05-28 12:00:08');
INSERT INTO audit_logs VALUES(700,1,'create_product','product',80,'测试重复','2026-05-28 15:04:53');
INSERT INTO audit_logs VALUES(701,1,'create_product','product',81,'外壳','2026-05-28 15:05:05');
INSERT INTO audit_logs VALUES(702,1,'update_product','product',1,'{''product_name'': ''外壳'', ''model'': ''SB70'', ''spec'': '''', ''upper_opening'': ''18'', ''plate_thickness'': '''', ''style'': ''标准自用'', ''category'': ''结构件''}','2026-05-28 15:07:25');
INSERT INTO audit_logs VALUES(703,1,'create_product','product',82,'验证测试','2026-05-28 15:16:38');
INSERT INTO audit_logs VALUES(704,1,'create_product','product',83,'验证测试2','2026-05-28 15:16:39');
INSERT INTO audit_logs VALUES(705,1,'delete_product','product',80,'','2026-05-28 15:16:45');
INSERT INTO audit_logs VALUES(706,1,'delete_product','product',81,'','2026-05-28 15:16:45');
INSERT INTO audit_logs VALUES(707,1,'delete_product','product',82,'','2026-05-28 15:16:45');
INSERT INTO audit_logs VALUES(708,1,'delete_product','product',83,'','2026-05-28 15:16:45');
INSERT INTO audit_logs VALUES(709,1,'create_product','product',84,'测试','2026-05-28 15:18:31');
INSERT INTO audit_logs VALUES(710,1,'delete_product','product',84,'','2026-05-28 15:18:31');
INSERT INTO audit_logs VALUES(711,1,'create_position','position',8,'焊接工','2026-05-29 05:32:07');
INSERT INTO audit_logs VALUES(712,1,'update_position','position',8,'焊接工','2026-05-29 05:33:54');
INSERT INTO audit_logs VALUES(713,1,'create_process_price','process_price',27,'{''product_id'': 79, ''process_id'': 324, ''unit_price'': 10, ''effective_date'': ''2026-05-29'', ''status'': ''active'', ''remark'': ''''}','2026-05-29 05:44:23');
INSERT INTO audit_logs VALUES(714,1,'create_process_price','process_price',28,'{''product_id'': 79, ''process_id'': 207, ''unit_price'': 1, ''effective_date'': ''2026-05-29'', ''status'': ''active'', ''remark'': ''''}','2026-05-29 05:44:23');
INSERT INTO audit_logs VALUES(715,1,'create_process_price','process_price',29,'{''product_id'': 79, ''process_id'': 218, ''unit_price'': 2, ''effective_date'': ''2026-05-29'', ''status'': ''active'', ''remark'': ''''}','2026-05-29 05:44:23');
INSERT INTO audit_logs VALUES(716,1,'create_process_price','process_price',30,'{''product_id'': 79, ''process_id'': 223, ''unit_price'': 15, ''effective_date'': ''2026-05-29'', ''status'': ''active'', ''remark'': ''''}','2026-05-29 05:44:23');
INSERT INTO audit_logs VALUES(717,1,'create_process_price','process_price',31,'{''product_id'': 79, ''process_id'': 322, ''unit_price'': 10, ''effective_date'': ''2026-05-29'', ''status'': ''active'', ''remark'': ''''}','2026-05-29 05:44:23');
INSERT INTO audit_logs VALUES(718,1,'create_process_price','process_price',32,'{''product_id'': 79, ''process_id'': 330, ''unit_price'': 15, ''effective_date'': ''2026-05-29'', ''status'': ''active'', ''remark'': ''''}','2026-05-29 05:44:23');
INSERT INTO audit_logs VALUES(719,1,'create_process_price','process_price',33,'{''product_id'': 79, ''process_id'': 328, ''unit_price'': 60, ''effective_date'': ''2026-05-29'', ''status'': ''active'', ''remark'': ''''}','2026-05-29 05:44:23');
INSERT INTO audit_logs VALUES(720,1,'create_process_price','process_price',34,'{''product_id'': 79, ''process_id'': 329, ''unit_price'': 10, ''effective_date'': ''2026-05-29'', ''status'': ''active'', ''remark'': ''''}','2026-05-29 05:44:23');
INSERT INTO audit_logs VALUES(721,1,'create_process_price','process_price',35,'{''product_id'': 79, ''process_id'': 195, ''unit_price'': 60, ''effective_date'': ''2026-05-29'', ''status'': ''active'', ''remark'': ''''}','2026-05-29 05:44:23');
INSERT INTO audit_logs VALUES(722,1,'delete_order','order',2,'','2026-05-29 13:20:21');
INSERT INTO audit_logs VALUES(723,1,'create_order','order',1,'26052901','2026-05-29 13:36:41');
INSERT INTO audit_logs VALUES(724,1,'create_order','order',2,'26052902','2026-05-29 14:26:09');
INSERT INTO audit_logs VALUES(725,1,'create_order','order',3,'26052903','2026-05-29 14:59:01');
INSERT INTO audit_logs VALUES(726,1,'create_order','order',4,'26052904','2026-05-29 15:02:28');
INSERT INTO audit_logs VALUES(727,1,'create_order','order',5,'26052905','2026-05-29 15:29:36');
INSERT INTO audit_logs VALUES(728,1,'delete_order','order',3,'','2026-05-29 15:29:42');
INSERT INTO audit_logs VALUES(729,1,'delete_order','order',2,'','2026-05-29 15:29:44');
INSERT INTO audit_logs VALUES(730,1,'delete_order','order',1,'','2026-05-29 15:29:46');
INSERT INTO audit_logs VALUES(731,2,'mobile_report','order',4,'process=322 serial=26052904-003 by=张三','2026-05-30 02:16:07');
INSERT INTO audit_logs VALUES(732,2,'mobile_report','order',4,'process=322 serial=26052904-002 by=张三','2026-05-30 02:17:12');
INSERT INTO audit_logs VALUES(733,2,'mobile_report','order',4,'process=322 serial=26052904-003 by=张三','2026-05-30 02:43:21');
INSERT INTO audit_logs VALUES(734,1,'update_user','user',2,'{''name'': ''张三'', ''nickname'': '''', ''email'': '''', ''role'': ''worker'', ''group_name'': ''超级管理组'', ''status'': ''active'', ''employee_no'': ''0001'', ''phone'': '''', ''process_ids'': ''322'', ''position_id'': None}','2026-05-30 02:45:34');
INSERT INTO audit_logs VALUES(735,1,'update_user','user',2,'{''name'': ''张三'', ''nickname'': '''', ''email'': '''', ''role'': ''worker'', ''group_name'': ''超级管理组'', ''status'': ''active'', ''employee_no'': ''0001'', ''phone'': '''', ''process_ids'': ''322'', ''password'': ''123456'', ''position_id'': None}','2026-05-30 02:46:04');
INSERT INTO audit_logs VALUES(736,2,'mobile_report','order',4,'process=328 serial=26052904-003 by=张三','2026-05-30 02:46:26');
INSERT INTO audit_logs VALUES(737,2,'mobile_report','order',4,'process=328 serial=26052904-003 by=张三','2026-05-30 02:46:32');
INSERT INTO audit_logs VALUES(738,2,'mobile_report','order',4,'process=328 serial=26052904-003 by=张三','2026-05-30 02:46:39');
INSERT INTO audit_logs VALUES(739,2,'mobile_report','order',4,'process=195 serial=26052904-003 by=张三','2026-05-30 02:46:45');
INSERT INTO audit_logs VALUES(740,2,'mobile_report','order',4,'process=322 serial=26052904-001 by=张三','2026-05-30 02:46:51');
INSERT INTO audit_logs VALUES(741,2,'mobile_report','order',4,'process=322 serial=26052904-002 by=张三','2026-05-30 02:46:59');
INSERT INTO audit_logs VALUES(742,2,'mobile_report','order',4,'process=195 serial=26052904-003 by=张三','2026-05-30 03:02:51');
INSERT INTO audit_logs VALUES(743,2,'mobile_report','order',4,'process=195 serial=26052904-003 by=张三','2026-05-30 03:02:58');
INSERT INTO audit_logs VALUES(744,2,'mobile_report','order',4,'process=195 serial=26052904-001 by=张三','2026-05-30 03:03:18');
INSERT INTO audit_logs VALUES(745,2,'mobile_report','order',5,'process=322 serial=26052905-007 by=张三','2026-05-30 03:03:31');
INSERT INTO audit_logs VALUES(746,1,'create_order','order',6,'26053001','2026-05-30 03:23:19');
INSERT INTO audit_logs VALUES(747,2,'mobile_report','order',6,'process=322 serial=26053001-003 by=张三','2026-05-30 03:35:35');
INSERT INTO audit_logs VALUES(748,2,'mobile_report','order',5,'process=322 serial=26052905-002 by=张三','2026-05-30 04:40:47');
INSERT INTO audit_logs VALUES(749,2,'mobile_report','order',5,'process=322 serial=26052905-001 by=张三','2026-05-30 04:40:54');
INSERT INTO audit_logs VALUES(750,2,'mobile_report','order',5,'process=322 serial=26052905-002 by=张三','2026-05-30 05:40:44');
INSERT INTO audit_logs VALUES(751,2,'mobile_report','order',5,'process=322 serial=26052905-001 by=张三','2026-05-30 06:39:52');
INSERT INTO audit_logs VALUES(752,2,'mobile_report','order',5,'process=322 serial=26052905-001 by=张三','2026-05-30 06:41:34');
INSERT INTO audit_logs VALUES(753,2,'mobile_report','order',5,'process=322 serial=26052905-001 by=张三','2026-05-30 06:41:44');
INSERT INTO audit_logs VALUES(754,2,'mobile_report','order',5,'process=322 serial=26052905-001 by=张三','2026-05-30 06:41:51');
INSERT INTO audit_logs VALUES(755,1,'create_order','order',7,'26053002','2026-05-30 06:42:49');
INSERT INTO audit_logs VALUES(756,1,'create_order','order',8,'26053003','2026-05-30 07:14:32');
INSERT INTO audit_logs VALUES(757,2,'mobile_report','order',8,'process=322 serial=26053003-003 by=张三','2026-05-30 07:15:25');
INSERT INTO audit_logs VALUES(758,1,'import_products','product',0,'imported 26, skipped 0','2026-05-30 07:56:58');
INSERT INTO audit_logs VALUES(759,1,'delete_process_route','process_route',4,'test','2026-05-30 08:33:29');
INSERT INTO audit_logs VALUES(760,1,'update_user','user',2,'{''name'': ''张三'', ''nickname'': '''', ''email'': '''', ''role'': ''worker'', ''group_name'': ''超级管理组'', ''status'': ''active'', ''employee_no'': ''0001'', ''phone'': '''', ''process_ids'': ''322'', ''position_id'': 1}','2026-05-30 08:43:06');
INSERT INTO audit_logs VALUES(761,1,'update_user','user',2,'{''name'': ''张三'', ''nickname'': '''', ''email'': '''', ''role'': ''worker'', ''group_name'': ''超级管理组'', ''status'': ''active'', ''employee_no'': ''0001'', ''phone'': '''', ''process_ids'': ''322'', ''position_id'': 1}','2026-05-30 09:23:20');
INSERT INTO audit_logs VALUES(762,1,'update_position','position',2,'铆工','2026-05-30 09:26:26');
INSERT INTO audit_logs VALUES(763,1,'update_user','user',2,'{''name'': ''张三'', ''nickname'': '''', ''email'': '''', ''role'': ''worker'', ''group_name'': ''超级管理组'', ''status'': ''active'', ''employee_no'': ''0001'', ''phone'': '''', ''process_ids'': ''322'', ''position_id'': 1}','2026-05-30 09:52:20');
INSERT INTO audit_logs VALUES(764,1,'update_user','user',2,'{''name'': ''张三'', ''nickname'': '''', ''email'': '''', ''status'': ''active'', ''employee_no'': ''0001'', ''phone'': '''', ''process_ids'': ''322'', ''position_id'': 1}','2026-05-30 10:00:49');
INSERT INTO audit_logs VALUES(765,1,'create_user','user',2112,'worker7/的话会','2026-05-30 10:01:31');
INSERT INTO audit_logs VALUES(766,1,'set_user_roles','user',2112,'roles=[2]','2026-05-30 10:01:32');
INSERT INTO audit_logs VALUES(767,1,'set_user_roles','user',1,'roles=[2]','2026-05-30 10:16:40');
INSERT INTO audit_logs VALUES(768,1,'create_user','user',2118,'test_role_1780136259/角色测试','2026-05-30 10:17:39');
INSERT INTO audit_logs VALUES(769,1,'set_user_roles','user',2118,'roles=[2]','2026-05-30 10:17:39');
INSERT INTO audit_logs VALUES(770,1,'create_user','user',2124,'test_role_v2_1780136369/角色测试V2','2026-05-30 10:19:29');
INSERT INTO audit_logs VALUES(771,1,'set_user_roles','user',2124,'roles=[2]','2026-05-30 10:19:29');
INSERT INTO audit_logs VALUES(772,1,'delete_user','user',2112,'','2026-05-30 10:24:24');
INSERT INTO audit_logs VALUES(773,1,'delete_user','user',2118,'','2026-05-30 10:24:30');
INSERT INTO audit_logs VALUES(774,1,'delete_user','user',2124,'','2026-05-30 10:24:33');
INSERT INTO audit_logs VALUES(775,1,'delete_process_price','process_price',30,'','2026-05-30 10:44:56');
INSERT INTO audit_logs VALUES(776,1,'delete_process_price','process_price',33,'','2026-05-30 10:44:56');
INSERT INTO audit_logs VALUES(777,1,'delete_process_price','process_price',28,'','2026-05-30 10:44:57');
INSERT INTO audit_logs VALUES(778,1,'delete_process_price','process_price',34,'','2026-05-30 10:44:57');
INSERT INTO audit_logs VALUES(779,1,'delete_process_price','process_price',32,'','2026-05-30 10:44:57');
INSERT INTO audit_logs VALUES(780,1,'delete_process_price','process_price',27,'','2026-05-30 10:44:57');
INSERT INTO audit_logs VALUES(781,1,'delete_process_price','process_price',29,'','2026-05-30 10:44:57');
INSERT INTO audit_logs VALUES(782,1,'delete_process_price','process_price',31,'','2026-05-30 10:44:57');
INSERT INTO audit_logs VALUES(783,1,'delete_process_price','process_price',35,'','2026-05-30 10:44:57');
INSERT INTO audit_logs VALUES(784,1,'update_process_route','process_route',3,'静音型外壳标准流程','2026-05-30 11:52:21');
INSERT INTO audit_logs VALUES(785,1,'create_process_route','process_route',5,'经济型分体外壳工序路线','2026-05-30 11:54:51');
INSERT INTO audit_logs VALUES(786,1,'update_process_route','process_route',5,'出口型分体外壳工序路线','2026-05-30 11:55:32');
INSERT INTO audit_logs VALUES(787,1,'create_process_route','process_route',6,'经济型分体外壳工序路线','2026-05-30 11:56:20');
INSERT INTO audit_logs VALUES(788,1,'create_process_price','process_price',36,'{''product_id'': 45, ''process_id'': 329, ''unit_price'': 15, ''effective_date'': '''', ''status'': ''active'', ''remark'': ''''}','2026-05-30 12:13:57');
INSERT INTO audit_logs VALUES(789,1,'create_process_price','process_price',37,'{''product_id'': 45, ''process_id'': 328, ''unit_price'': 60, ''effective_date'': '''', ''status'': ''active'', ''remark'': ''''}','2026-05-30 12:13:57');
INSERT INTO audit_logs VALUES(790,1,'create_process_price','process_price',38,'{''product_id'': 45, ''process_id'': 330, ''unit_price'': 20, ''effective_date'': '''', ''status'': ''active'', ''remark'': ''''}','2026-05-30 12:13:57');
INSERT INTO audit_logs VALUES(791,1,'create_process_price','process_price',39,'{''product_id'': 45, ''process_id'': 195, ''unit_price'': 90, ''effective_date'': '''', ''status'': ''active'', ''remark'': ''''}','2026-05-30 12:13:58');
INSERT INTO audit_logs VALUES(792,1,'create_process_price','process_price',40,'{''product_id'': 45, ''process_id'': 223, ''unit_price'': 25, ''effective_date'': '''', ''status'': ''active'', ''remark'': ''''}','2026-05-30 12:13:58');
INSERT INTO audit_logs VALUES(793,1,'create_process_price','process_price',41,'{''product_id'': 45, ''process_id'': 322, ''unit_price'': 28, ''effective_date'': '''', ''status'': ''active'', ''remark'': ''''}','2026-05-30 12:13:58');
INSERT INTO audit_logs VALUES(794,1,'create_process_price','process_price',42,'{''product_id'': 45, ''process_id'': 324, ''unit_price'': 20, ''effective_date'': '''', ''status'': ''active'', ''remark'': ''''}','2026-05-30 12:13:58');
INSERT INTO audit_logs VALUES(795,1,'create_process_price','process_price',43,'{''product_id'': 46, ''process_id'': 329, ''unit_price'': 15, ''effective_date'': '''', ''status'': ''active'', ''remark'': ''''}','2026-05-30 12:15:28');
INSERT INTO audit_logs VALUES(796,1,'create_process_price','process_price',44,'{''product_id'': 46, ''process_id'': 330, ''unit_price'': 20, ''effective_date'': '''', ''status'': ''active'', ''remark'': ''''}','2026-05-30 12:15:29');
INSERT INTO audit_logs VALUES(797,1,'create_process_price','process_price',45,'{''product_id'': 46, ''process_id'': 328, ''unit_price'': 60, ''effective_date'': '''', ''status'': ''active'', ''remark'': ''''}','2026-05-30 12:15:29');
INSERT INTO audit_logs VALUES(798,1,'create_process_price','process_price',46,'{''product_id'': 46, ''process_id'': 223, ''unit_price'': 25, ''effective_date'': '''', ''status'': ''active'', ''remark'': ''''}','2026-05-30 12:15:29');
INSERT INTO audit_logs VALUES(799,1,'create_process_price','process_price',47,'{''product_id'': 46, ''process_id'': 322, ''unit_price'': 28, ''effective_date'': '''', ''status'': ''active'', ''remark'': ''''}','2026-05-30 12:15:29');
INSERT INTO audit_logs VALUES(800,1,'create_process_price','process_price',48,'{''product_id'': 46, ''process_id'': 324, ''unit_price'': 20, ''effective_date'': '''', ''status'': ''active'', ''remark'': ''''}','2026-05-30 12:15:29');
INSERT INTO audit_logs VALUES(801,1,'create_process_price','process_price',49,'{''product_id'': 46, ''process_id'': 195, ''unit_price'': 90, ''effective_date'': '''', ''status'': ''active'', ''remark'': ''''}','2026-05-30 12:15:29');
INSERT INTO audit_logs VALUES(802,1,'create_process_price','process_price',50,'{''product_id'': 51, ''process_id'': 195, ''unit_price'': 110, ''effective_date'': ''2026-05-30'', ''status'': ''active'', ''remark'': ''''}','2026-05-30 12:17:10');
INSERT INTO audit_logs VALUES(803,1,'create_process_price','process_price',51,'{''product_id'': 51, ''process_id'': 329, ''unit_price'': 15, ''effective_date'': ''2026-05-30'', ''status'': ''active'', ''remark'': ''''}','2026-05-30 12:17:10');
INSERT INTO audit_logs VALUES(804,1,'create_process_price','process_price',52,'{''product_id'': 51, ''process_id'': 330, ''unit_price'': 25, ''effective_date'': ''2026-05-30'', ''status'': ''active'', ''remark'': ''''}','2026-05-30 12:17:10');
INSERT INTO audit_logs VALUES(805,1,'create_process_price','process_price',53,'{''product_id'': 51, ''process_id'': 223, ''unit_price'': 30, ''effective_date'': ''2026-05-30'', ''status'': ''active'', ''remark'': ''''}','2026-05-30 12:17:10');
INSERT INTO audit_logs VALUES(806,1,'create_process_price','process_price',54,'{''product_id'': 51, ''process_id'': 328, ''unit_price'': 80, ''effective_date'': ''2026-05-30'', ''status'': ''active'', ''remark'': ''''}','2026-05-30 12:17:10');
INSERT INTO audit_logs VALUES(807,1,'create_process_price','process_price',55,'{''product_id'': 51, ''process_id'': 322, ''unit_price'': 30, ''effective_date'': ''2026-05-30'', ''status'': ''active'', ''remark'': ''''}','2026-05-30 12:17:10');
INSERT INTO audit_logs VALUES(808,1,'create_process_price','process_price',56,'{''product_id'': 51, ''process_id'': 324, ''unit_price'': 30, ''effective_date'': ''2026-05-30'', ''status'': ''active'', ''remark'': ''''}','2026-05-30 12:17:10');
INSERT INTO audit_logs VALUES(809,1,'create_process_price','process_price',57,'{''product_id'': 53, ''process_id'': 195, ''unit_price'': 110, ''effective_date'': ''2026-05-30'', ''status'': ''active'', ''remark'': ''''}','2026-05-30 12:18:12');
INSERT INTO audit_logs VALUES(810,1,'create_process_price','process_price',59,'{''product_id'': 53, ''process_id'': 330, ''unit_price'': 25, ''effective_date'': ''2026-05-30'', ''status'': ''active'', ''remark'': ''''}','2026-05-30 12:18:12');
INSERT INTO audit_logs VALUES(811,1,'create_process_price','process_price',60,'{''product_id'': 53, ''process_id'': 223, ''unit_price'': 30, ''effective_date'': ''2026-05-30'', ''status'': ''active'', ''remark'': ''''}','2026-05-30 12:18:12');
INSERT INTO audit_logs VALUES(812,1,'create_process_price','process_price',61,'{''product_id'': 53, ''process_id'': 328, ''unit_price'': 80, ''effective_date'': ''2026-05-30'', ''status'': ''active'', ''remark'': ''''}','2026-05-30 12:18:12');
INSERT INTO audit_logs VALUES(813,1,'create_process_price','process_price',58,'{''product_id'': 53, ''process_id'': 329, ''unit_price'': 15, ''effective_date'': ''2026-05-30'', ''status'': ''active'', ''remark'': ''''}','2026-05-30 12:18:12');
INSERT INTO audit_logs VALUES(814,1,'create_process_price','process_price',62,'{''product_id'': 53, ''process_id'': 322, ''unit_price'': 30, ''effective_date'': ''2026-05-30'', ''status'': ''active'', ''remark'': ''''}','2026-05-30 12:18:13');
INSERT INTO audit_logs VALUES(815,1,'create_process_price','process_price',63,'{''product_id'': 53, ''process_id'': 324, ''unit_price'': 30, ''effective_date'': ''2026-05-30'', ''status'': ''active'', ''remark'': ''''}','2026-05-30 12:18:13');
INSERT INTO audit_logs VALUES(816,1,'create_process_price','process_price',64,'{''product_id'': 57, ''process_id'': 329, ''unit_price'': 30, ''effective_date'': ''2026-05-30'', ''status'': ''active'', ''remark'': ''''}','2026-05-30 12:19:31');
INSERT INTO audit_logs VALUES(817,1,'create_process_price','process_price',65,'{''product_id'': 57, ''process_id'': 330, ''unit_price'': 28, ''effective_date'': ''2026-05-30'', ''status'': ''active'', ''remark'': ''''}','2026-05-30 12:19:31');
INSERT INTO audit_logs VALUES(818,1,'create_process_price','process_price',66,'{''product_id'': 57, ''process_id'': 328, ''unit_price'': 150, ''effective_date'': ''2026-05-30'', ''status'': ''active'', ''remark'': ''''}','2026-05-30 12:19:31');
INSERT INTO audit_logs VALUES(819,1,'create_process_price','process_price',67,'{''product_id'': 57, ''process_id'': 223, ''unit_price'': 50, ''effective_date'': ''2026-05-30'', ''status'': ''active'', ''remark'': ''''}','2026-05-30 12:19:31');
INSERT INTO audit_logs VALUES(820,1,'create_process_price','process_price',68,'{''product_id'': 57, ''process_id'': 322, ''unit_price'': 50, ''effective_date'': ''2026-05-30'', ''status'': ''active'', ''remark'': ''''}','2026-05-30 12:19:31');
INSERT INTO audit_logs VALUES(821,1,'create_process_price','process_price',69,'{''product_id'': 57, ''process_id'': 324, ''unit_price'': 40, ''effective_date'': ''2026-05-30'', ''status'': ''active'', ''remark'': ''''}','2026-05-30 12:19:31');
INSERT INTO audit_logs VALUES(822,1,'create_process_price','process_price',70,'{''product_id'': 57, ''process_id'': 195, ''unit_price'': 200, ''effective_date'': ''2026-05-30'', ''status'': ''active'', ''remark'': ''''}','2026-05-30 12:19:31');
INSERT INTO audit_logs VALUES(823,1,'create_product','product',111,'外壳','2026-05-30 12:21:01');
INSERT INTO audit_logs VALUES(824,1,'create_process_price','process_price',71,'{''product_id'': 111, ''process_id'': 195, ''unit_price'': 200, ''effective_date'': ''2026-05-30'', ''status'': ''active'', ''remark'': ''''}','2026-05-30 12:22:20');
INSERT INTO audit_logs VALUES(825,1,'create_process_price','process_price',72,'{''product_id'': 111, ''process_id'': 990, ''unit_price'': 20, ''effective_date'': ''2026-05-30'', ''status'': ''active'', ''remark'': ''''}','2026-05-30 12:22:20');
INSERT INTO audit_logs VALUES(826,1,'create_process_price','process_price',73,'{''product_id'': 111, ''process_id'': 986, ''unit_price'': 12, ''effective_date'': ''2026-05-30'', ''status'': ''active'', ''remark'': ''''}','2026-05-30 12:22:20');
INSERT INTO audit_logs VALUES(827,1,'create_process_price','process_price',74,'{''product_id'': 111, ''process_id'': 223, ''unit_price'': 50, ''effective_date'': ''2026-05-30'', ''status'': ''active'', ''remark'': ''''}','2026-05-30 12:22:20');
INSERT INTO audit_logs VALUES(828,1,'create_process_price','process_price',75,'{''product_id'': 111, ''process_id'': 322, ''unit_price'': 80, ''effective_date'': ''2026-05-30'', ''status'': ''active'', ''remark'': ''''}','2026-05-30 12:22:20');
INSERT INTO audit_logs VALUES(829,1,'create_process_price','process_price',76,'{''product_id'': 111, ''process_id'': 324, ''unit_price'': 40, ''effective_date'': ''2026-05-30'', ''status'': ''active'', ''remark'': ''''}','2026-05-30 12:22:20');
INSERT INTO audit_logs VALUES(830,1,'create_process_price','process_price',77,'{''product_id'': 111, ''process_id'': 328, ''unit_price'': 180, ''effective_date'': ''2026-05-30'', ''status'': ''active'', ''remark'': ''''}','2026-05-30 12:22:20');
INSERT INTO audit_logs VALUES(831,1,'create_process_price','process_price',78,'{''product_id'': 111, ''process_id'': 329, ''unit_price'': 30, ''effective_date'': ''2026-05-30'', ''status'': ''active'', ''remark'': ''''}','2026-05-30 12:22:20');
INSERT INTO audit_logs VALUES(832,1,'create_process_price','process_price',79,'{''product_id'': 111, ''process_id'': 330, ''unit_price'': 28, ''effective_date'': ''2026-05-30'', ''status'': ''active'', ''remark'': ''''}','2026-05-30 12:22:20');
INSERT INTO audit_logs VALUES(833,1,'create_process_price','process_price',80,'{''product_id'': 111, ''process_id'': 983, ''unit_price'': 10, ''effective_date'': ''2026-05-30'', ''status'': ''active'', ''remark'': ''''}','2026-05-30 12:22:20');
INSERT INTO audit_logs VALUES(834,1,'create_process_price','process_price',81,'{''product_id'': 111, ''process_id'': 984, ''unit_price'': 12, ''effective_date'': ''2026-05-30'', ''status'': ''active'', ''remark'': ''''}','2026-05-30 12:22:20');
INSERT INTO audit_logs VALUES(835,1,'save_route_prices','route_price',2,'3 processes','2026-05-30 12:31:55');
INSERT INTO audit_logs VALUES(836,1,'create_process_route','process_route',7,'静音型外壳工序路线','2026-05-30 12:49:58');
INSERT INTO audit_logs VALUES(837,1,'save_route_prices','route_price',2,'2 processes','2026-05-30 13:00:19');
INSERT INTO audit_logs VALUES(838,1,'save_route_prices','route_price',2,'1 processes','2026-05-30 13:00:19');
INSERT INTO audit_logs VALUES(839,1,'save_route_prices','route_price',2,'0 processes','2026-05-30 13:00:19');
INSERT INTO audit_logs VALUES(840,1,'update_process_route','process_route',8,'标准机加工路线','2026-05-30 13:41:12');
INSERT INTO audit_logs VALUES(841,1,'update_customer','customer',1,'{''name'': ''正坤机械''}','2026-05-30 13:46:50');
INSERT INTO audit_logs VALUES(842,1,'stock_in','inventory',2,'+5','2026-05-30 14:03:04');
INSERT INTO audit_logs VALUES(843,1,'stock_out','inventory',2,'-5','2026-05-30 14:03:04');
INSERT INTO audit_logs VALUES(844,1,'update_user','user',2,'{''name'': ''张三'', ''nickname'': '''', ''email'': '''', ''status'': ''active'', ''employee_no'': ''0001'', ''phone'': '''', ''process_ids'': ''322'', ''position_id'': 1}','2026-05-30 15:18:32');
INSERT INTO audit_logs VALUES(845,1,'create_material','materials',1,'45#钢板','2026-05-30 15:18:46');
INSERT INTO audit_logs VALUES(846,1,'material_stock_out','materials',1,'-1.5','2026-05-30 15:18:55');
INSERT INTO audit_logs VALUES(847,1,'delete_material','materials',1,'','2026-05-30 15:19:48');
INSERT INTO audit_logs VALUES(848,1,'create_user','user',2275,'test_audit_x/测试 role_id=1','2026-05-30 17:15:21');
INSERT INTO audit_logs VALUES(849,1,'delete_user','user',2275,'','2026-05-30 17:15:30');
INSERT INTO audit_logs VALUES(850,1,'create_user','user',2276,'temp_del_test/temp role_id=1','2026-05-30 17:15:40');
INSERT INTO audit_logs VALUES(851,1,'delete_user','user',2276,'','2026-05-30 17:16:14');
INSERT INTO audit_logs VALUES(852,1,'create_role_group','role_group',6,'TEST_GROUP_AUDIT','2026-05-30 17:45:46');
INSERT INTO audit_logs VALUES(853,1,'create_role','role',108,'TEST_ROLE_AUDIT/test_role_audit','2026-05-30 17:45:46');
INSERT INTO audit_logs VALUES(854,1,'delete_role_group','role_group',6,'','2026-05-30 17:45:46');
INSERT INTO audit_logs VALUES(855,1,'delete_role_group','role_group',6,'','2026-05-30 17:45:53');
INSERT INTO audit_logs VALUES(856,1,'create_role_group','role_group',7,'CASCADE_TEST','2026-05-30 17:47:22');
INSERT INTO audit_logs VALUES(857,1,'create_role','role',112,'TMP_ROLE/tmp_cascade','2026-05-30 17:47:22');
INSERT INTO audit_logs VALUES(858,1,'set_user_roles','user',2,'roles=[2, 112]','2026-05-30 17:47:22');
INSERT INTO audit_logs VALUES(859,1,'delete_role_group','role_group',7,'','2026-05-30 17:47:22');
INSERT INTO audit_logs VALUES(860,1,'update_position','position',8,'','2026-05-31 00:03:08');
INSERT INTO audit_logs VALUES(861,1,'update_position','position',8,'','2026-05-31 00:03:08');
INSERT INTO audit_logs VALUES(862,1,'create_position','position',9,'焊接工','2026-05-31 00:05:34');
INSERT INTO audit_logs VALUES(863,1,'update_position','position',8,'','2026-05-31 00:05:34');
INSERT INTO audit_logs VALUES(864,1,'delete_position','position',9,'焊接工','2026-05-31 00:05:59');
INSERT INTO audit_logs VALUES(865,1,'update_position','position',8,'焊接工','2026-05-31 00:06:00');
INSERT INTO audit_logs VALUES(866,1,'update_position','position',8,'焊接工','2026-05-31 00:07:20');
INSERT INTO audit_logs VALUES(867,1,'update_position','position',8,'焊接工','2026-05-31 00:07:20');
INSERT INTO audit_logs VALUES(868,1,'save_settings','',0,'{''company_name'': ''韩运机械测试'', ''page_size'': ''25''}','2026-05-31 00:38:47');
INSERT INTO audit_logs VALUES(869,1,'create_user','user',2312,'test_setting_pw/密码测试 role_id=2','2026-05-31 00:38:58');
INSERT INTO audit_logs VALUES(870,1,'save_settings','',0,'{''company_name'': ''韩运机械'', ''page_size'': ''20''}','2026-05-31 00:40:25');
INSERT INTO audit_logs VALUES(871,1,'delete_user','user',2312,'','2026-05-31 00:40:25');
INSERT INTO audit_logs VALUES(872,1,'create_order','order',9,'26053101','2026-05-31 00:58:18');
INSERT INTO audit_logs VALUES(873,1,'update_order','order',9,'{''product_code'': ''TEST-001''}','2026-05-31 00:58:18');
INSERT INTO audit_logs VALUES(874,1,'delete_order','order',9,'26053101','2026-05-31 00:58:18');
INSERT INTO audit_logs VALUES(875,1,'create_process','process',2782,'审计测试','2026-05-31 01:26:45');
INSERT INTO audit_logs VALUES(876,1,'delete_process','process',2782,'','2026-05-31 01:26:45');
INSERT INTO audit_logs VALUES(877,1,'create_process_route','process_route',9,'标准结构件路线','2026-05-31 01:37:39');
INSERT INTO audit_logs VALUES(878,1,'create_process_route','process_route',10,'审计验证路线','2026-05-31 01:38:06');
INSERT INTO audit_logs VALUES(879,1,'create','shipment',1,'创建出库单 SH20260531-001','2026-05-31 02:13:59');
INSERT INTO audit_logs VALUES(880,1,'delete','shipment',1,'删除出库单 SH20260531-001','2026-05-31 02:13:59');
INSERT INTO audit_logs VALUES(881,1,'create','shipment',2,'创建出库单 SH20260531-001','2026-05-31 02:14:37');
INSERT INTO audit_logs VALUES(882,1,'delete','shipment',2,'删除出库单 SH20260531-001','2026-05-31 02:14:37');
INSERT INTO audit_logs VALUES(883,1,'create','shipment',3,'创建出库单 SH20260531-001','2026-05-31 02:14:46');
INSERT INTO audit_logs VALUES(884,1,'delete','shipment',3,'删除出库单 SH20260531-001','2026-05-31 02:14:46');
INSERT INTO audit_logs VALUES(885,1,'copy_prices','product',46,'from 45, 7 rows','2026-05-31 03:40:31');
INSERT INTO audit_logs VALUES(886,1,'batch_save_prices','product',110,'保存成功（新增 0 条，更新 0 条）','2026-05-31 05:21:17');
INSERT INTO audit_logs VALUES(887,1,'update_user','user',2,'{''name'': ''张三'', ''nickname'': '''', ''email'': '''', ''status'': ''active'', ''employee_no'': ''0001'', ''phone'': '''', ''process_ids'': ''322'', ''position_id'': 1}','2026-05-31 05:23:49');
INSERT INTO audit_logs VALUES(888,1,'create_order','order',9,'26060201','2026-06-02 06:06:08');
CREATE TABLE system_settings (
            key TEXT PRIMARY KEY,
            value TEXT DEFAULT ''
        );
INSERT INTO system_settings VALUES('contact','');
INSERT INTO system_settings VALUES('phone','');
INSERT INTO system_settings VALUES('address','');
INSERT INTO system_settings VALUES('description','');
INSERT INTO system_settings VALUES('default_password','123456');
INSERT INTO system_settings VALUES('approval_enabled','1');
INSERT INTO system_settings VALUES('auto_order_no','');
INSERT INTO system_settings VALUES('company_name','韩运机械');
INSERT INTO system_settings VALUES('page_size','20');
CREATE TABLE inventory (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_model TEXT UNIQUE NOT NULL,
            product_name TEXT DEFAULT '',
            specification TEXT DEFAULT '',
            quantity INTEGER DEFAULT 0,
            safe_stock INTEGER DEFAULT 0,
            location TEXT DEFAULT '',
            unit TEXT DEFAULT '件',
            remark TEXT DEFAULT '',
            updated_at TEXT DEFAULT (datetime('now','localtime'))
        );
INSERT INTO inventory VALUES(1,'TEST','','',0,0,'','件','','2026-05-27 09:10:18');
INSERT INTO inventory VALUES(2,'','','',0,0,'','件','','2026-05-30 14:03:04');
CREATE TABLE inventory_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            inventory_id INTEGER NOT NULL,
            type TEXT NOT NULL,
            quantity INTEGER NOT NULL,
            order_id INTEGER,
            order_no TEXT DEFAULT '',
            remark TEXT DEFAULT '',
            operator_id INTEGER,
            operator_name TEXT DEFAULT '',
            created_at TEXT DEFAULT (datetime('now','localtime')),
            FOREIGN KEY (inventory_id) REFERENCES inventory(id)
        );
INSERT INTO inventory_logs VALUES(1,2,'in',5,NULL,'','',1,'系统管理员','2026-05-30 14:03:04');
INSERT INTO inventory_logs VALUES(2,2,'out',5,NULL,'','',1,'系统管理员','2026-05-30 14:03:04');
CREATE TABLE process_routes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT DEFAULT '',
            status TEXT DEFAULT 'active',
            created_at TEXT DEFAULT (datetime('now','localtime')),
            updated_at TEXT DEFAULT (datetime('now','localtime'))
        , category TEXT DEFAULT "结构件");
INSERT INTO process_routes VALUES(2,'三角型外壳标准流程','','active','2026-05-19 06:35:01','2026-05-19 06:35:01','结构件');
INSERT INTO process_routes VALUES(3,'静音型外壳标准流程','','active','2026-05-19 06:36:36','2026-05-30 11:52:21','结构件');
INSERT INTO process_routes VALUES(5,'出口型分体外壳工序路线','','active','2026-05-30 11:54:51','2026-05-30 11:55:32','结构件');
INSERT INTO process_routes VALUES(6,'经济型分体外壳工序路线','','active','2026-05-30 11:56:20','2026-05-30 11:56:20','结构件');
INSERT INTO process_routes VALUES(7,'静音型外壳工序路线','','active','2026-05-30 12:49:58','2026-05-30 12:49:58','结构件');
INSERT INTO process_routes VALUES(8,'标准机加工路线','加工内衬条→内衬板→边套→质检→入库','active','2026-05-30 13:37:51','2026-05-30 13:41:11','机加工');
INSERT INTO process_routes VALUES(9,'标准结构件路线','','active','2026-05-31 01:37:39','2026-05-31 01:37:39','结构件');
INSERT INTO process_routes VALUES(11,'一体直型外壳流程','一体直型外壳标准加工路线：下料→铆接→焊接→抛丸→打磨→镗孔→喷漆','active','2026-05-31 10:56:21','2026-05-31 10:56:21','结构件');
CREATE TABLE process_route_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            route_id INTEGER NOT NULL,
            process_id INTEGER NOT NULL,
            seq_order INTEGER DEFAULT 0,
            required_audit INTEGER DEFAULT 0,
            FOREIGN KEY (route_id) REFERENCES process_routes(id) ON DELETE CASCADE,
            FOREIGN KEY (process_id) REFERENCES processes(id)
        );
INSERT INTO process_route_items VALUES(12,2,322,0,0);
INSERT INTO process_route_items VALUES(13,2,328,1,0);
INSERT INTO process_route_items VALUES(14,2,195,2,0);
INSERT INTO process_route_items VALUES(15,2,329,3,0);
INSERT INTO process_route_items VALUES(16,2,324,4,0);
INSERT INTO process_route_items VALUES(17,2,330,5,0);
INSERT INTO process_route_items VALUES(18,2,223,6,0);
INSERT INTO process_route_items VALUES(25,3,322,0,0);
INSERT INTO process_route_items VALUES(26,3,328,1,0);
INSERT INTO process_route_items VALUES(27,3,195,2,0);
INSERT INTO process_route_items VALUES(28,3,329,3,0);
INSERT INTO process_route_items VALUES(29,3,324,4,0);
INSERT INTO process_route_items VALUES(30,3,330,5,0);
INSERT INTO process_route_items VALUES(31,3,423,6,0);
INSERT INTO process_route_items VALUES(32,3,985,7,0);
INSERT INTO process_route_items VALUES(43,5,322,0,0);
INSERT INTO process_route_items VALUES(44,5,328,1,0);
INSERT INTO process_route_items VALUES(45,5,195,2,0);
INSERT INTO process_route_items VALUES(46,5,329,3,0);
INSERT INTO process_route_items VALUES(47,5,324,4,0);
INSERT INTO process_route_items VALUES(48,5,330,5,0);
INSERT INTO process_route_items VALUES(49,5,983,6,0);
INSERT INTO process_route_items VALUES(50,5,984,7,0);
INSERT INTO process_route_items VALUES(51,5,986,8,0);
INSERT INTO process_route_items VALUES(52,5,990,9,0);
INSERT INTO process_route_items VALUES(53,6,322,0,0);
INSERT INTO process_route_items VALUES(54,6,328,1,0);
INSERT INTO process_route_items VALUES(55,6,195,2,0);
INSERT INTO process_route_items VALUES(56,6,329,3,0);
INSERT INTO process_route_items VALUES(57,6,324,4,0);
INSERT INTO process_route_items VALUES(58,6,330,5,0);
INSERT INTO process_route_items VALUES(59,6,223,6,0);
INSERT INTO process_route_items VALUES(60,7,322,0,0);
INSERT INTO process_route_items VALUES(61,7,328,1,0);
INSERT INTO process_route_items VALUES(62,7,195,2,0);
INSERT INTO process_route_items VALUES(63,7,329,3,0);
INSERT INTO process_route_items VALUES(64,7,324,4,0);
INSERT INTO process_route_items VALUES(65,7,223,5,0);
INSERT INTO process_route_items VALUES(66,7,330,6,0);
INSERT INTO process_route_items VALUES(67,7,423,7,0);
INSERT INTO process_route_items VALUES(78,8,1057,0,0);
INSERT INTO process_route_items VALUES(79,8,207,1,0);
INSERT INTO process_route_items VALUES(80,10,322,0,1);
INSERT INTO process_route_items VALUES(81,11,322,0,0);
INSERT INTO process_route_items VALUES(82,11,328,1,0);
INSERT INTO process_route_items VALUES(83,11,195,2,0);
INSERT INTO process_route_items VALUES(84,11,329,3,0);
INSERT INTO process_route_items VALUES(85,11,324,4,0);
INSERT INTO process_route_items VALUES(86,11,330,5,0);
INSERT INTO process_route_items VALUES(87,11,223,6,0);
CREATE TABLE customers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            contact TEXT DEFAULT '',
            phone TEXT DEFAULT '',
            email TEXT DEFAULT '',
            address TEXT DEFAULT '',
            remark TEXT DEFAULT '',
            created_at TEXT DEFAULT (datetime('now','localtime')),
            updated_at TEXT DEFAULT (datetime('now','localtime'))
        );
INSERT INTO customers VALUES(1,'正坤机械','常总','13312345678','','马鞍山','','2026-04-15 12:23:23','2026-05-30 13:46:50');
INSERT INTO customers VALUES(2,'韩运机械','刘明征','13212345678','','','','2026-04-15 12:23:54','2026-04-15 12:23:54');
INSERT INTO customers VALUES(3,'中天博运','朱','1234567890','','天津','','2026-05-13 09:49:03','2026-05-13 09:49:03');
INSERT INTO customers VALUES(4,'测试客户','张三','13800138000','','','测试','2026-05-27 05:50:51','2026-05-27 05:50:51');
CREATE TABLE operation_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            user_name TEXT DEFAULT '',
            action TEXT NOT NULL,
            target_type TEXT DEFAULT '',
            target_id INTEGER,
            detail TEXT DEFAULT '',
            created_at TEXT DEFAULT (datetime('now','localtime'))
        );
CREATE TABLE products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_name TEXT NOT NULL,
            model TEXT DEFAULT '',
            spec TEXT DEFAULT '',
            upper_opening TEXT DEFAULT '',
            plate_thickness TEXT DEFAULT '',
            weight REAL DEFAULT 0,
            description TEXT DEFAULT '',
            created_at TEXT DEFAULT (datetime('now','localtime')),
            updated_at TEXT DEFAULT (datetime('now','localtime'))
        , product_code TEXT DEFAULT '', style TEXT DEFAULT "", category TEXT DEFAULT 结构件, price REAL DEFAULT 0, route_id INTEGER DEFAULT NULL);
INSERT INTO products VALUES(44,'内衬板','SB81','','','',7.0,'','2026-05-26 12:26:26','2026-05-26 12:26:26','内衬板-SB81','','机加工',60.0,8);
INSERT INTO products VALUES(45,'外壳','SB81','三角型','360','18',0.0,'','2026-05-28 08:51:26','2026-05-28 08:51:26','外壳-SB81-SJ-360-18-标准自用','标准自用','结构件',0.0,2);
INSERT INTO products VALUES(46,'外壳','SB81','三角型','440','18',0.0,'','2026-05-28 08:52:57','2026-05-28 08:52:57','外壳-SB81-SJ-440-18-优化自用','优化自用','结构件',0.0,2);
INSERT INTO products VALUES(47,'外壳','SB81','三角型','360','20',0.0,'','2026-05-28 08:58:35','2026-05-28 08:58:35','外壳-SB81-SJ-360-20-标准自用','标准自用','结构件',0.0,2);
INSERT INTO products VALUES(48,'外壳','SB81','三角型','360','22',0.0,'','2026-05-28 09:04:24','2026-05-28 09:04:24','外壳-SB81-SJ-360-22-标准自用','标准自用','结构件',0.0,2);
INSERT INTO products VALUES(49,'外壳','SB81','三角型','440','20',0.0,'','2026-05-28 10:02:53','2026-05-28 10:02:53','外壳-SB81-SJ-440-20-优化自用','优化自用','结构件',0.0,2);
INSERT INTO products VALUES(50,'外壳','SB81','三角型','440','22',0.0,'','2026-05-28 10:03:53','2026-05-28 10:03:53','外壳-SB81-SJ-440-22-优化自用','优化自用','结构件',0.0,2);
INSERT INTO products VALUES(51,'外壳','SB81','一体直型','360','18',0.0,'','2026-05-28 10:05:13','2026-05-28 10:05:13','外壳-SB81-YT-360-18-标准自用','标准自用','结构件',0.0,11);
INSERT INTO products VALUES(52,'外壳','SB81','一体直型','360','20',0.0,'','2026-05-28 10:06:32','2026-05-28 10:06:32','外壳-SB81-YT-360-20-标准自用','标准自用','结构件',0.0,11);
INSERT INTO products VALUES(53,'外壳','SB81','一体直型','360','22',0.0,'','2026-05-28 10:07:53','2026-05-28 10:07:53','外壳-SB81-YT-360-22-标准自用','标准自用','结构件',0.0,11);
INSERT INTO products VALUES(54,'外壳','SB81','一体直型','440','18',0.0,'','2026-05-28 10:09:40','2026-05-28 10:09:40','外壳-SB81-YT-440-18-标准自用','标准自用','结构件',0.0,11);
INSERT INTO products VALUES(55,'外壳','SB81','一体直型','440','20',0.0,'','2026-05-28 10:10:17','2026-05-28 10:10:17','外壳-SB81-YT-440-20-标准自用','标准自用','结构件',0.0,11);
INSERT INTO products VALUES(56,'外壳','SB81','一体直型','440','22',0.0,'','2026-05-28 10:11:02','2026-05-28 10:11:02','外壳-SB81-YT-440-22-标准自用','标准自用','结构件',0.0,11);
INSERT INTO products VALUES(57,'外壳','SB81','分体直型','360','18',0.0,'','2026-05-28 10:33:45','2026-05-28 10:33:45','外壳-SB81-FT-360-18-标准自用','标准自用','结构件',0.0,6);
INSERT INTO products VALUES(58,'外壳','SB81','分体直型','360','20',0.0,'','2026-05-28 10:36:25','2026-05-28 10:36:25','外壳-SB81-FT-360-20-标准自用','标准自用','结构件',0.0,6);
INSERT INTO products VALUES(59,'外壳','SB81','分体直型','360','22',0.0,'','2026-05-28 10:37:09','2026-05-28 10:37:09','外壳-SB81-FT-360-22-标准自用','标准自用','结构件',0.0,6);
INSERT INTO products VALUES(60,'外壳','SB81','分体直型','360','25',0.0,'','2026-05-28 10:37:44','2026-05-28 10:37:44','外壳-SB81-FT-360-25-标准自用','标准自用','结构件',0.0,6);
INSERT INTO products VALUES(61,'外壳','SB81','分体直型','440','18',0.0,'','2026-05-28 10:38:15','2026-05-28 10:38:15','外壳-SB81-FT-440-18-标准自用','标准自用','结构件',0.0,6);
INSERT INTO products VALUES(62,'外壳','SB81','分体直型','440','20',0.0,'','2026-05-28 10:38:36','2026-05-28 10:38:36','外壳-SB81-FT-440-20-标准自用','标准自用','结构件',0.0,6);
INSERT INTO products VALUES(63,'外壳','SB81','分体直型','440','22',0.0,'','2026-05-28 10:38:59','2026-05-28 10:38:59','外壳-SB81-FT-440-22-标准自用','标准自用','结构件',0.0,6);
INSERT INTO products VALUES(64,'外壳','SB81','分体直型','440','25',0.0,'','2026-05-28 10:39:59','2026-05-28 10:39:59','外壳-SB81-FT-440-25-标准自用','标准自用','结构件',0.0,6);
INSERT INTO products VALUES(65,'外壳','SB81','静音型','360','18',0.0,'','2026-05-28 10:41:03','2026-05-28 10:41:03','外壳-SB81-JY-360-18-标准自用','标准自用','结构件',0.0,3);
INSERT INTO products VALUES(66,'外壳','SB81','静音型','360','20',0.0,'','2026-05-28 10:41:33','2026-05-28 10:41:33','外壳-SB81-JY-360-20-标准自用','标准自用','结构件',0.0,3);
INSERT INTO products VALUES(67,'外壳','SB81','静音型','360','22',0.0,'','2026-05-28 10:42:26','2026-05-28 10:42:26','外壳-SB81-JY-360-22-标准自用','标准自用','结构件',0.0,3);
INSERT INTO products VALUES(68,'外壳','SB70','三角型','360','18',0.0,'','2026-05-28 10:49:09','2026-05-28 10:49:09','外壳-SB70-SJ-360-18-标准自用','标准自用','结构件',0.0,2);
INSERT INTO products VALUES(69,'外壳','SB70','三角型','360','20',0.0,'','2026-05-28 10:49:29','2026-05-28 10:49:29','外壳-SB70-SJ-360-20-标准自用','标准自用','结构件',0.0,2);
INSERT INTO products VALUES(70,'外壳','SB70','三角型','360','22',0.0,'','2026-05-28 10:49:54','2026-05-28 10:49:54','外壳-SB70-SJ-360-22-标准自用','标准自用','结构件',0.0,2);
INSERT INTO products VALUES(71,'外壳','SB70','三角型','360','18',0.0,'','2026-05-28 10:57:27','2026-05-28 10:57:27','外壳-SB70-SJ-360-18-经济自用','经济自用','结构件',0.0,2);
INSERT INTO products VALUES(72,'外壳','SB70','三角型','360','20',0.0,'','2026-05-28 10:57:59','2026-05-28 10:57:59','外壳-SB70-SJ-360-20-经济自用','经济自用','结构件',0.0,2);
INSERT INTO products VALUES(73,'外壳','SB70','静音型','360','18',0.0,'','2026-05-28 10:58:37','2026-05-28 10:58:37','外壳-SB70-JY-360-18-标准自用','标准自用','结构件',0.0,3);
INSERT INTO products VALUES(74,'外壳','SB70','静音型','360','20',0.0,'','2026-05-28 10:59:46','2026-05-28 10:59:46','外壳-SB70-JY-360-20-标准自用','标准自用','结构件',0.0,3);
INSERT INTO products VALUES(75,'外壳','SB70','分体直型','360','18',0.0,'','2026-05-28 11:00:16','2026-05-28 11:00:16','外壳-SB70-FT-360-18-标准自用','标准自用','结构件',0.0,6);
INSERT INTO products VALUES(78,'外壳','SB70','分体直型','360','20',0.0,'','2026-05-28 11:59:25','2026-05-28 11:59:25','外壳-SB70-FT-360-20-标准自用','标准自用','结构件',0.0,6);
INSERT INTO products VALUES(79,'外壳','SB70','一体直型','360','18',0.0,'','2026-05-28 12:00:08','2026-05-28 12:00:08','外壳-SB70-YT-360-18-标准自用','标准自用','结构件',0.0,11);
INSERT INTO products VALUES(85,'外壳','SB50','三角型','290','12',0.0,'','2026-05-30 07:56:58','2026-05-30 07:56:58','外壳-SB50-SJ-290-12-标准自用','标准自用','结构件',0.0,2);
INSERT INTO products VALUES(86,'外壳','SB50','三角型','290','14',0.0,'','2026-05-30 07:56:58','2026-05-30 07:56:58','外壳-SB50-SJ-290-14-标准自用','标准自用','结构件',0.0,2);
INSERT INTO products VALUES(87,'外壳','SB50','三角型','290','16',0.0,'','2026-05-30 07:56:58','2026-05-30 07:56:58','外壳-SB50-SJ-290-16-标准自用','标准自用','结构件',0.0,2);
INSERT INTO products VALUES(88,'外壳','SB50','三角型','290','12',0.0,'','2026-05-30 07:56:58','2026-05-30 07:56:58','外壳-SB50-SJ-290-12-经济自用','经济自用','结构件',0.0,2);
INSERT INTO products VALUES(89,'外壳','SB50','三角型','290','14',0.0,'','2026-05-30 07:56:58','2026-05-30 07:56:58','外壳-SB50-SJ-290-14-经济自用','经济自用','结构件',0.0,2);
INSERT INTO products VALUES(90,'外壳','SB50','三角型','290','16',0.0,'','2026-05-30 07:56:58','2026-05-30 07:56:58','外壳-SB50-SJ-290-16-经济自用','经济自用','结构件',0.0,2);
INSERT INTO products VALUES(91,'外壳','SB50','一体直型','290','12',0.0,'','2026-05-30 07:56:58','2026-05-30 07:56:58','外壳-SB50-YT-290-12-标准自用','标准自用','结构件',0.0,11);
INSERT INTO products VALUES(92,'外壳','SB50','一体直型','290','14',0.0,'','2026-05-30 07:56:58','2026-05-30 07:56:58','外壳-SB50-YT-290-14-标准自用','标准自用','结构件',0.0,11);
INSERT INTO products VALUES(93,'外壳','SB50','一体直型','290','16',0.0,'','2026-05-30 07:56:58','2026-05-30 07:56:58','外壳-SB50-YT-290-16-标准自用','标准自用','结构件',0.0,11);
INSERT INTO products VALUES(94,'外壳','SB50','一体直型','290','12',0.0,'','2026-05-30 07:56:58','2026-05-30 07:56:58','外壳-SB50-YT-290-12-经济自用','经济自用','结构件',0.0,11);
INSERT INTO products VALUES(95,'外壳','SB50','一体直型','290','14',0.0,'','2026-05-30 07:56:58','2026-05-30 07:56:58','外壳-SB50-YT-290-14-经济自用','经济自用','结构件',0.0,11);
INSERT INTO products VALUES(96,'外壳','SB50','一体直型','290','16',0.0,'','2026-05-30 07:56:58','2026-05-30 07:56:58','外壳-SB50-YT-290-16-经济自用','经济自用','结构件',0.0,11);
INSERT INTO products VALUES(97,'外壳','SB50','分体直型','290','12',0.0,'','2026-05-30 07:56:58','2026-05-30 07:56:58','外壳-SB50-FT-290-12-标准自用','标准自用','结构件',0.0,6);
INSERT INTO products VALUES(98,'外壳','SB50','分体直型','290','14',0.0,'','2026-05-30 07:56:58','2026-05-30 07:56:58','外壳-SB50-FT-290-14-标准自用','标准自用','结构件',0.0,6);
INSERT INTO products VALUES(99,'外壳','SB50','分体直型','290','16',0.0,'','2026-05-30 07:56:58','2026-05-30 07:56:58','外壳-SB50-FT-290-16-标准自用','标准自用','结构件',0.0,6);
INSERT INTO products VALUES(100,'外壳','SB50','分体直型','290','12',0.0,'','2026-05-30 07:56:58','2026-05-30 07:56:58','外壳-SB50-FT-290-12-经济自用','经济自用','结构件',0.0,6);
INSERT INTO products VALUES(101,'外壳','SB50','分体直型','290','14',0.0,'','2026-05-30 07:56:58','2026-05-30 07:56:58','外壳-SB50-FT-290-14-经济自用','经济自用','结构件',0.0,6);
INSERT INTO products VALUES(102,'外壳','SB50','分体直型','290','16',0.0,'','2026-05-30 07:56:58','2026-05-30 07:56:58','外壳-SB50-FT-290-16-经济自用','经济自用','结构件',0.0,6);
INSERT INTO products VALUES(103,'外壳','SB50','静音型','290','12',0.0,'','2026-05-30 07:56:58','2026-05-30 07:56:58','外壳-SB50-JY-290-12-标准自用','标准自用','结构件',0.0,3);
INSERT INTO products VALUES(104,'外壳','SB50','静音型','290','14',0.0,'','2026-05-30 07:56:58','2026-05-30 07:56:58','外壳-SB50-JY-290-14-标准自用','标准自用','结构件',0.0,3);
INSERT INTO products VALUES(105,'外壳','SB50','静音型','290','16',0.0,'','2026-05-30 07:56:58','2026-05-30 07:56:58','外壳-SB50-JY-290-16-标准自用','标准自用','结构件',0.0,3);
INSERT INTO products VALUES(106,'外壳','SB121','三角型','450','22',0.0,'','2026-05-30 07:56:58','2026-05-30 07:56:58','外壳-SB121-SJ-450-22-标准自用','标准自用','结构件',0.0,2);
INSERT INTO products VALUES(107,'外壳','SB121','三角型','450','25',0.0,'','2026-05-30 07:56:58','2026-05-30 07:56:58','外壳-SB121-SJ-450-25-标准自用','标准自用','结构件',0.0,2);
INSERT INTO products VALUES(108,'外壳','SB121','三角型','450','22',0.0,'','2026-05-30 07:56:58','2026-05-30 07:56:58','外壳-SB121-SJ-450-22-经济自用','经济自用','结构件',0.0,2);
INSERT INTO products VALUES(109,'外壳','SB121','三角型','450','25',0.0,'','2026-05-30 07:56:58','2026-05-30 07:56:58','外壳-SB121-SJ-450-25-经济自用','经济自用','结构件',0.0,2);
INSERT INTO products VALUES(110,'外壳','SB121','一体直型','450','25',0.0,'','2026-05-30 07:56:58','2026-05-31 05:21:17','外壳-SB121-YT-450-25-标准自用','标准自用','结构件',0.0,11);
INSERT INTO products VALUES(111,'外壳','SB81','分体直型','360','25',0.0,'','2026-05-30 12:21:01','2026-05-30 12:21:01','外壳-SB81-FT-360-25-正坤5-2','正坤5-2','结构件',0.0,5);
CREATE TABLE process_prices (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            process_id INTEGER NOT NULL,
            unit_price REAL NOT NULL DEFAULT 0,
            effective_date TEXT DEFAULT '',
            status TEXT DEFAULT 'active',
            remark TEXT DEFAULT '',
            created_at TEXT DEFAULT (datetime('now','localtime')),
            updated_at TEXT DEFAULT (datetime('now','localtime')), product_id INTEGER,
            FOREIGN KEY (process_id) REFERENCES processes(id)
        );
INSERT INTO process_prices VALUES(36,329,15.0,'','active','','2026-05-30 12:13:57','2026-05-30 12:13:57',45);
INSERT INTO process_prices VALUES(37,328,60.0,'','active','','2026-05-30 12:13:57','2026-05-30 12:13:57',45);
INSERT INTO process_prices VALUES(38,330,20.0,'','active','','2026-05-30 12:13:57','2026-05-30 12:13:57',45);
INSERT INTO process_prices VALUES(39,195,90.0,'','active','','2026-05-30 12:13:57','2026-05-30 12:13:57',45);
INSERT INTO process_prices VALUES(40,223,25.0,'','active','','2026-05-30 12:13:58','2026-05-30 12:13:58',45);
INSERT INTO process_prices VALUES(41,322,28.0,'','active','','2026-05-30 12:13:58','2026-05-30 12:13:58',45);
INSERT INTO process_prices VALUES(42,324,20.0,'','active','','2026-05-30 12:13:58','2026-05-30 12:13:58',45);
INSERT INTO process_prices VALUES(50,195,110.0,'2026-05-30','active','','2026-05-30 12:17:09','2026-05-30 12:17:09',51);
INSERT INTO process_prices VALUES(51,329,15.0,'2026-05-30','active','','2026-05-30 12:17:10','2026-05-30 12:17:10',51);
INSERT INTO process_prices VALUES(52,330,25.0,'2026-05-30','active','','2026-05-30 12:17:10','2026-05-30 12:17:10',51);
INSERT INTO process_prices VALUES(53,223,30.0,'2026-05-30','active','','2026-05-30 12:17:10','2026-05-30 12:17:10',51);
INSERT INTO process_prices VALUES(54,328,80.0,'2026-05-30','active','','2026-05-30 12:17:10','2026-05-30 12:17:10',51);
INSERT INTO process_prices VALUES(55,322,30.0,'2026-05-30','active','','2026-05-30 12:17:10','2026-05-30 12:17:10',51);
INSERT INTO process_prices VALUES(56,324,30.0,'2026-05-30','active','','2026-05-30 12:17:10','2026-05-30 12:17:10',51);
INSERT INTO process_prices VALUES(57,195,110.0,'2026-05-30','active','','2026-05-30 12:18:12','2026-05-30 12:18:12',53);
INSERT INTO process_prices VALUES(58,329,15.0,'2026-05-30','active','','2026-05-30 12:18:12','2026-05-30 12:18:12',53);
INSERT INTO process_prices VALUES(59,330,25.0,'2026-05-30','active','','2026-05-30 12:18:12','2026-05-30 12:18:12',53);
INSERT INTO process_prices VALUES(60,223,30.0,'2026-05-30','active','','2026-05-30 12:18:12','2026-05-30 12:18:12',53);
INSERT INTO process_prices VALUES(61,328,80.0,'2026-05-30','active','','2026-05-30 12:18:12','2026-05-30 12:18:12',53);
INSERT INTO process_prices VALUES(62,322,30.0,'2026-05-30','active','','2026-05-30 12:18:13','2026-05-30 12:18:13',53);
INSERT INTO process_prices VALUES(63,324,30.0,'2026-05-30','active','','2026-05-30 12:18:13','2026-05-30 12:18:13',53);
INSERT INTO process_prices VALUES(64,329,30.0,'2026-05-30','active','','2026-05-30 12:19:31','2026-05-30 12:19:31',57);
INSERT INTO process_prices VALUES(65,330,28.0,'2026-05-30','active','','2026-05-30 12:19:31','2026-05-30 12:19:31',57);
INSERT INTO process_prices VALUES(66,328,150.0,'2026-05-30','active','','2026-05-30 12:19:31','2026-05-30 12:19:31',57);
INSERT INTO process_prices VALUES(67,223,50.0,'2026-05-30','active','','2026-05-30 12:19:31','2026-05-30 12:19:31',57);
INSERT INTO process_prices VALUES(68,322,50.0,'2026-05-30','active','','2026-05-30 12:19:31','2026-05-30 12:19:31',57);
INSERT INTO process_prices VALUES(69,324,40.0,'2026-05-30','active','','2026-05-30 12:19:31','2026-05-30 12:19:31',57);
INSERT INTO process_prices VALUES(70,195,200.0,'2026-05-30','active','','2026-05-30 12:19:31','2026-05-30 12:19:31',57);
INSERT INTO process_prices VALUES(71,195,200.0,'2026-05-30','active','','2026-05-30 12:22:20','2026-05-30 12:22:20',111);
INSERT INTO process_prices VALUES(72,990,20.0,'2026-05-30','active','','2026-05-30 12:22:20','2026-05-30 12:22:20',111);
INSERT INTO process_prices VALUES(73,986,12.0,'2026-05-30','active','','2026-05-30 12:22:20','2026-05-30 12:22:20',111);
INSERT INTO process_prices VALUES(74,223,50.0,'2026-05-30','active','','2026-05-30 12:22:20','2026-05-30 12:22:20',111);
INSERT INTO process_prices VALUES(75,322,80.0,'2026-05-30','active','','2026-05-30 12:22:20','2026-05-30 12:22:20',111);
INSERT INTO process_prices VALUES(76,324,40.0,'2026-05-30','active','','2026-05-30 12:22:20','2026-05-30 12:22:20',111);
INSERT INTO process_prices VALUES(77,328,180.0,'2026-05-30','active','','2026-05-30 12:22:20','2026-05-30 12:22:20',111);
INSERT INTO process_prices VALUES(78,329,30.0,'2026-05-30','active','','2026-05-30 12:22:20','2026-05-30 12:22:20',111);
INSERT INTO process_prices VALUES(79,330,28.0,'2026-05-30','active','','2026-05-30 12:22:20','2026-05-30 12:22:20',111);
INSERT INTO process_prices VALUES(80,983,10.0,'2026-05-30','active','','2026-05-30 12:22:20','2026-05-30 12:22:20',111);
INSERT INTO process_prices VALUES(81,984,12.0,'2026-05-30','active','','2026-05-30 12:22:20','2026-05-30 12:22:20',111);
INSERT INTO process_prices VALUES(82,329,15.0,'','active','','2026-05-31 03:40:31','2026-05-31 03:40:31',46);
INSERT INTO process_prices VALUES(83,328,60.0,'','active','','2026-05-31 03:40:31','2026-05-31 03:40:31',46);
INSERT INTO process_prices VALUES(84,330,20.0,'','active','','2026-05-31 03:40:31','2026-05-31 03:40:31',46);
INSERT INTO process_prices VALUES(85,195,90.0,'','active','','2026-05-31 03:40:31','2026-05-31 03:40:31',46);
INSERT INTO process_prices VALUES(86,223,25.0,'','active','','2026-05-31 03:40:31','2026-05-31 03:40:31',46);
INSERT INTO process_prices VALUES(87,322,28.0,'','active','','2026-05-31 03:40:31','2026-05-31 03:40:31',46);
INSERT INTO process_prices VALUES(88,324,20.0,'','active','','2026-05-31 03:40:31','2026-05-31 03:40:31',46);
CREATE TABLE approval_config (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            process_id INTEGER,  -- NULL means global config
            require_approval BOOLEAN DEFAULT 0,
            approver_role TEXT DEFAULT 'admin',
            approval_level INTEGER DEFAULT 1,
            created_at TEXT DEFAULT (datetime('now','localtime')),
            FOREIGN KEY (process_id) REFERENCES processes(id)
        );
CREATE TABLE approval_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            work_record_id INTEGER NOT NULL,
            status TEXT DEFAULT 'pending',  -- pending/approved/rejected
            approver_id INTEGER,
            approver_name TEXT,
            comment TEXT DEFAULT '',
            created_at TEXT DEFAULT (datetime('now','localtime')), processed_at TEXT DEFAULT "",
            FOREIGN KEY (work_record_id) REFERENCES work_records(id)
        );
CREATE TABLE role_groups (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT DEFAULT '',
            parent_id INTEGER DEFAULT NULL,
            status TEXT DEFAULT 'active',
            created_at TEXT DEFAULT (datetime('now','localtime'))
        , permissions TEXT DEFAULT "");
INSERT INTO role_groups VALUES(1,'系统管理组','系统内置最高权限角色组',NULL,'active','2026-05-20 16:35:12','');
INSERT INTO role_groups VALUES(2,'管理员组','管理员角色组',3,'active','2026-05-20 16:35:12','{"report":true}');
INSERT INTO role_groups VALUES(3,'普通员工组','普通员工角色组',1,'active','2026-05-21 12:42:30','');
CREATE TABLE roles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            code TEXT UNIQUE NOT NULL,
            description TEXT DEFAULT '',
            group_id INTEGER,
            parent_id INTEGER DEFAULT NULL,
            level INTEGER DEFAULT 1,
            permissions TEXT DEFAULT '',
            status TEXT DEFAULT 'active',
            created_at TEXT DEFAULT (datetime('now','localtime'))
        );
INSERT INTO roles VALUES(1,'系统管理员','admin','系统内置管理员，拥有全部权限',1,NULL,1,'["*"]','active','2026-05-20 16:35:12');
INSERT INTO roles VALUES(2,'普通员工','worker','普通工人，可进行报工操作',3,1,4,'["scan:view", "dashboard:view"]','active','2026-05-20 16:35:12');
INSERT INTO roles VALUES(3,'生产主管','production_manager','管理生产订单、工艺和工价',2,NULL,2,'["orders:view", "orders:create", "orders:edit", "orders:delete", "products:view", "customers:view", "processes:view", "routes:view", "routes:create", "routes:edit", "routes:delete", "prices:view", "prices:create", "prices:edit", "prices:delete", "scan:view", "stats:view", "trace:view", "reports:view", "board:view", "approvals:view", "inventory:view", "dashboard:view"]','active','2026-05-30 09:10:31');
INSERT INTO roles VALUES(4,'质检员','qc_inspector','质检岗位，扫码报工+追溯+统计',2,NULL,3,'["scan:view", "trace:view", "stats:view", "products:view", "dashboard:view"]','active','2026-05-30 09:10:31');
INSERT INTO roles VALUES(5,'仓库管理员','warehouse_keeper','管理库存和发货',2,NULL,3,'["inventory:view", "inventory:create", "inventory:edit", "inventory:delete", "shipments:view", "shipments:create", "shipments:edit", "shipments:delete", "products:view", "dashboard:view"]','active','2026-05-30 09:10:31');
CREATE TABLE user_roles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            role_id INTEGER NOT NULL,
            granted_by INTEGER,
            created_at TEXT DEFAULT (datetime('now','localtime')),
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE CASCADE
        );
INSERT INTO user_roles VALUES(3,3,2,NULL,'2026-05-30 09:10:31');
INSERT INTO user_roles VALUES(4,4,2,NULL,'2026-05-30 09:10:31');
INSERT INTO user_roles VALUES(5,5,2,NULL,'2026-05-30 09:10:31');
INSERT INTO user_roles VALUES(6,271,2,NULL,'2026-05-30 09:10:31');
INSERT INTO user_roles VALUES(7,1791,2,NULL,'2026-05-30 09:10:31');
INSERT INTO user_roles VALUES(9,1,2,NULL,'2026-05-30 10:16:40');
INSERT INTO user_roles VALUES(11,1,1,NULL,'2026-05-30 10:19:18');
INSERT INTO user_roles VALUES(13,1227,1,NULL,'2026-05-30 17:12:33');
INSERT INTO user_roles VALUES(14,1228,1,NULL,'2026-05-30 17:12:33');
INSERT INTO user_roles VALUES(15,1730,1,NULL,'2026-05-30 17:12:33');
INSERT INTO user_roles VALUES(18,2,2,NULL,'2026-05-30 17:47:22');
CREATE TABLE product_attachments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id INTEGER NOT NULL,
            file_name TEXT NOT NULL,
            file_type TEXT DEFAULT '',
            file_size INTEGER DEFAULT 0,
            file_data BLOB,
            uploaded_by INTEGER,
            created_at TEXT DEFAULT (datetime('now','localtime')),
            FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
        );
CREATE TABLE order_processes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_id INTEGER NOT NULL,
        process_id INTEGER NOT NULL,
        seq_order INTEGER DEFAULT 0,
        status TEXT DEFAULT 'pending',
        required_audit INTEGER DEFAULT 0,
        completed INTEGER DEFAULT 0,
        scrapped INTEGER DEFAULT 0,
        rework INTEGER DEFAULT 0,
        FOREIGN KEY (order_id) REFERENCES orders(id),
        FOREIGN KEY (process_id) REFERENCES processes(id) ON DELETE CASCADE
    );
INSERT INTO order_processes VALUES(120,4,322,0,'pending',0,5,0,0);
INSERT INTO order_processes VALUES(121,4,328,1,'pending',0,3,0,0);
INSERT INTO order_processes VALUES(122,4,195,2,'pending',0,4,0,0);
INSERT INTO order_processes VALUES(123,4,329,3,'pending',0,0,0,0);
INSERT INTO order_processes VALUES(124,4,324,4,'pending',0,0,0,0);
INSERT INTO order_processes VALUES(125,4,330,5,'pending',0,0,0,0);
INSERT INTO order_processes VALUES(126,4,223,6,'pending',0,0,0,0);
INSERT INTO order_processes VALUES(127,5,322,0,'pending',0,8,0,0);
INSERT INTO order_processes VALUES(128,5,328,1,'pending',0,0,0,0);
INSERT INTO order_processes VALUES(129,5,195,2,'pending',0,0,0,0);
INSERT INTO order_processes VALUES(130,5,329,3,'pending',0,0,0,0);
INSERT INTO order_processes VALUES(131,5,324,4,'pending',0,0,0,0);
INSERT INTO order_processes VALUES(132,5,330,5,'pending',0,0,0,0);
INSERT INTO order_processes VALUES(133,5,223,6,'pending',0,0,0,0);
INSERT INTO order_processes VALUES(134,6,322,0,'pending',0,1,0,0);
INSERT INTO order_processes VALUES(135,6,328,1,'pending',0,0,0,0);
INSERT INTO order_processes VALUES(136,6,195,2,'pending',0,0,0,0);
INSERT INTO order_processes VALUES(137,6,329,3,'pending',0,0,0,0);
INSERT INTO order_processes VALUES(138,6,324,4,'pending',0,0,0,0);
INSERT INTO order_processes VALUES(139,6,330,5,'pending',0,0,0,0);
INSERT INTO order_processes VALUES(140,6,223,6,'pending',0,0,0,0);
INSERT INTO order_processes VALUES(141,7,322,0,'pending',0,0,0,0);
INSERT INTO order_processes VALUES(142,7,328,1,'pending',0,0,0,0);
INSERT INTO order_processes VALUES(143,7,195,2,'pending',0,0,0,0);
INSERT INTO order_processes VALUES(144,7,329,3,'pending',0,0,0,0);
INSERT INTO order_processes VALUES(145,7,324,4,'pending',0,0,0,0);
INSERT INTO order_processes VALUES(146,7,330,5,'pending',0,0,0,0);
INSERT INTO order_processes VALUES(147,7,223,6,'pending',0,0,0,0);
INSERT INTO order_processes VALUES(148,8,322,0,'pending',0,1,0,0);
INSERT INTO order_processes VALUES(149,8,328,1,'pending',0,0,0,0);
INSERT INTO order_processes VALUES(150,8,195,2,'pending',0,0,0,0);
INSERT INTO order_processes VALUES(151,8,329,3,'pending',0,0,0,0);
INSERT INTO order_processes VALUES(152,8,324,4,'pending',0,0,0,0);
INSERT INTO order_processes VALUES(153,8,330,5,'pending',0,0,0,0);
INSERT INTO order_processes VALUES(154,8,223,6,'pending',0,0,0,0);
INSERT INTO order_processes VALUES(173,9,322,0,'pending',0,0,0,0);
INSERT INTO order_processes VALUES(174,9,328,1,'pending',0,0,0,0);
INSERT INTO order_processes VALUES(175,9,195,2,'pending',0,0,0,0);
INSERT INTO order_processes VALUES(176,9,329,3,'pending',0,0,0,0);
INSERT INTO order_processes VALUES(177,9,324,4,'pending',0,0,0,0);
INSERT INTO order_processes VALUES(178,9,330,5,'pending',0,0,0,0);
INSERT INTO order_processes VALUES(179,9,223,6,'pending',0,0,0,0);
CREATE TABLE product_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        serial_no TEXT UNIQUE NOT NULL,
        order_id INTEGER NOT NULL,
        qr_content TEXT NOT NULL,
        status TEXT DEFAULT 'pending',
        position_no INTEGER DEFAULT 1,
        weight REAL DEFAULT 0,
        production_date TEXT DEFAULT '',
        completed_at TEXT DEFAULT '',
        created_at TEXT DEFAULT (datetime('now','localtime')),
        current_process_id INTEGER,
        FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
    );
INSERT INTO product_items VALUES(35,'26052904-001',4,'{"type": "product_item", "serial_no": "26052904-001", "order_id": 4, "order_no": "26052904"}','in_progress',1,0.0,'','','2026-05-29 15:02:31',329);
INSERT INTO product_items VALUES(36,'26052904-002',4,'{"type": "product_item", "serial_no": "26052904-002", "order_id": 4, "order_no": "26052904"}','in_progress',2,0.0,'','','2026-05-29 15:02:31',195);
INSERT INTO product_items VALUES(37,'26052904-003',4,'{"type": "product_item", "serial_no": "26052904-003", "order_id": 4, "order_no": "26052904"}','in_progress',3,0.0,'','','2026-05-29 15:02:31',329);
INSERT INTO product_items VALUES(38,'26052905-001',5,'{"type": "product_item", "serial_no": "26052905-001", "order_id": 5, "order_no": "26052905"}','in_progress',1,0.0,'','','2026-05-29 15:47:37',322);
INSERT INTO product_items VALUES(39,'26052905-002',5,'{"type": "product_item", "serial_no": "26052905-002", "order_id": 5, "order_no": "26052905"}','in_progress',2,0.0,'','','2026-05-29 15:47:37',322);
INSERT INTO product_items VALUES(40,'26052905-003',5,'{"type": "product_item", "serial_no": "26052905-003", "order_id": 5, "order_no": "26052905"}','pending',3,0.0,'','','2026-05-29 15:47:37',NULL);
INSERT INTO product_items VALUES(41,'26052905-004',5,'{"type": "product_item", "serial_no": "26052905-004", "order_id": 5, "order_no": "26052905"}','pending',4,0.0,'','','2026-05-29 15:47:37',NULL);
INSERT INTO product_items VALUES(42,'26052905-005',5,'{"type": "product_item", "serial_no": "26052905-005", "order_id": 5, "order_no": "26052905"}','pending',5,0.0,'','','2026-05-29 15:47:37',NULL);
INSERT INTO product_items VALUES(43,'26052905-006',5,'{"type": "product_item", "serial_no": "26052905-006", "order_id": 5, "order_no": "26052905"}','pending',6,0.0,'','','2026-05-29 15:47:37',NULL);
INSERT INTO product_items VALUES(44,'26052905-007',5,'{"type": "product_item", "serial_no": "26052905-007", "order_id": 5, "order_no": "26052905"}','in_progress',7,0.0,'','','2026-05-29 15:47:37',322);
INSERT INTO product_items VALUES(45,'26052905-008',5,'{"type": "product_item", "serial_no": "26052905-008", "order_id": 5, "order_no": "26052905"}','pending',8,0.0,'','','2026-05-29 15:47:37',NULL);
INSERT INTO product_items VALUES(46,'26052905-009',5,'{"type": "product_item", "serial_no": "26052905-009", "order_id": 5, "order_no": "26052905"}','pending',9,0.0,'','','2026-05-29 15:47:37',NULL);
INSERT INTO product_items VALUES(47,'26052905-010',5,'{"type": "product_item", "serial_no": "26052905-010", "order_id": 5, "order_no": "26052905"}','pending',10,0.0,'','','2026-05-29 15:47:37',NULL);
INSERT INTO product_items VALUES(48,'26053001-001',6,'{"t": "pi", "sn": "26053001-001", "oid": 6, "on": "26053001"}','pending',1,0.0,'','','2026-05-30 03:23:22',NULL);
INSERT INTO product_items VALUES(49,'26053001-002',6,'{"t": "pi", "sn": "26053001-002", "oid": 6, "on": "26053001"}','pending',2,0.0,'','','2026-05-30 03:23:22',NULL);
INSERT INTO product_items VALUES(50,'26053001-003',6,'{"t": "pi", "sn": "26053001-003", "oid": 6, "on": "26053001"}','in_progress',3,0.0,'','','2026-05-30 03:23:22',322);
INSERT INTO product_items VALUES(51,'26053002-001',7,'{"t": "pi", "sn": "26053002-001", "oid": 7, "on": "26053002"}','pending',1,0.0,'','','2026-05-30 07:13:47',NULL);
INSERT INTO product_items VALUES(52,'26053002-002',7,'{"t": "pi", "sn": "26053002-002", "oid": 7, "on": "26053002"}','pending',2,0.0,'','','2026-05-30 07:13:47',NULL);
INSERT INTO product_items VALUES(53,'26053002-003',7,'{"t": "pi", "sn": "26053002-003", "oid": 7, "on": "26053002"}','pending',3,0.0,'','','2026-05-30 07:13:47',NULL);
INSERT INTO product_items VALUES(54,'26053002-004',7,'{"t": "pi", "sn": "26053002-004", "oid": 7, "on": "26053002"}','pending',4,0.0,'','','2026-05-30 07:13:47',NULL);
INSERT INTO product_items VALUES(55,'26053002-005',7,'{"t": "pi", "sn": "26053002-005", "oid": 7, "on": "26053002"}','pending',5,0.0,'','','2026-05-30 07:13:47',NULL);
INSERT INTO product_items VALUES(56,'26053002-006',7,'{"t": "pi", "sn": "26053002-006", "oid": 7, "on": "26053002"}','pending',6,0.0,'','','2026-05-30 07:13:47',NULL);
INSERT INTO product_items VALUES(57,'26053002-007',7,'{"t": "pi", "sn": "26053002-007", "oid": 7, "on": "26053002"}','pending',7,0.0,'','','2026-05-30 07:13:47',NULL);
INSERT INTO product_items VALUES(58,'26053002-008',7,'{"t": "pi", "sn": "26053002-008", "oid": 7, "on": "26053002"}','pending',8,0.0,'','','2026-05-30 07:13:47',NULL);
INSERT INTO product_items VALUES(59,'26053002-009',7,'{"t": "pi", "sn": "26053002-009", "oid": 7, "on": "26053002"}','pending',9,0.0,'','','2026-05-30 07:13:47',NULL);
INSERT INTO product_items VALUES(60,'26053002-010',7,'{"t": "pi", "sn": "26053002-010", "oid": 7, "on": "26053002"}','pending',10,0.0,'','','2026-05-30 07:13:47',NULL);
INSERT INTO product_items VALUES(61,'26053003-001',8,'{"t": "pi", "sn": "26053003-001", "oid": 8, "on": "26053003"}','pending',1,0.0,'','','2026-05-30 07:14:36',NULL);
INSERT INTO product_items VALUES(62,'26053003-002',8,'{"t": "pi", "sn": "26053003-002", "oid": 8, "on": "26053003"}','pending',2,0.0,'','','2026-05-30 07:14:36',NULL);
INSERT INTO product_items VALUES(63,'26053003-003',8,'{"t": "pi", "sn": "26053003-003", "oid": 8, "on": "26053003"}','in_progress',3,0.0,'','','2026-05-30 07:14:36',322);
INSERT INTO product_items VALUES(64,'26060201-001',9,'{"t": "pi", "sn": "26060201-001", "oid": 9, "on": "26060201"}','pending',1,0.0,'','','2026-06-02 11:47:55',NULL);
INSERT INTO product_items VALUES(65,'26060201-002',9,'{"t": "pi", "sn": "26060201-002", "oid": 9, "on": "26060201"}','pending',2,0.0,'','','2026-06-02 11:47:55',NULL);
INSERT INTO product_items VALUES(66,'26060201-003',9,'{"t": "pi", "sn": "26060201-003", "oid": 9, "on": "26060201"}','pending',3,0.0,'','','2026-06-02 11:47:55',NULL);
INSERT INTO product_items VALUES(67,'26060201-004',9,'{"t": "pi", "sn": "26060201-004", "oid": 9, "on": "26060201"}','pending',4,0.0,'','','2026-06-02 11:47:55',NULL);
INSERT INTO product_items VALUES(68,'26060201-005',9,'{"t": "pi", "sn": "26060201-005", "oid": 9, "on": "26060201"}','pending',5,0.0,'','','2026-06-02 11:47:55',NULL);
INSERT INTO product_items VALUES(69,'26060201-006',9,'{"t": "pi", "sn": "26060201-006", "oid": 9, "on": "26060201"}','pending',6,0.0,'','','2026-06-02 11:47:55',NULL);
INSERT INTO product_items VALUES(70,'26060201-007',9,'{"t": "pi", "sn": "26060201-007", "oid": 9, "on": "26060201"}','pending',7,0.0,'','','2026-06-02 11:47:55',NULL);
INSERT INTO product_items VALUES(71,'26060201-008',9,'{"t": "pi", "sn": "26060201-008", "oid": 9, "on": "26060201"}','pending',8,0.0,'','','2026-06-02 11:47:55',NULL);
INSERT INTO product_items VALUES(72,'26060201-009',9,'{"t": "pi", "sn": "26060201-009", "oid": 9, "on": "26060201"}','pending',9,0.0,'','','2026-06-02 11:47:55',NULL);
INSERT INTO product_items VALUES(73,'26060201-010',9,'{"t": "pi", "sn": "26060201-010", "oid": 9, "on": "26060201"}','pending',10,0.0,'','','2026-06-02 11:47:55',NULL);
CREATE TABLE work_records (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_id INTEGER NOT NULL,
        process_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        type TEXT DEFAULT 'normal',
        quantity INTEGER DEFAULT 0,
        remark TEXT DEFAULT '',
        created_at TEXT DEFAULT (datetime('now','localtime')),
        status TEXT DEFAULT 'pending', serial_no TEXT DEFAULT "",
        FOREIGN KEY (order_id) REFERENCES orders(id),
        FOREIGN KEY (process_id) REFERENCES processes(id),
        FOREIGN KEY (user_id) REFERENCES users(id)
    );
INSERT INTO work_records VALUES(30,4,322,2,'mobile',1,'','2026-05-30 02:16:07','approved','');
INSERT INTO work_records VALUES(31,4,322,2,'mobile',1,'','2026-05-30 02:17:12','approved','');
INSERT INTO work_records VALUES(32,4,322,2,'mobile',1,'','2026-05-30 02:43:21','approved','');
INSERT INTO work_records VALUES(33,4,328,2,'mobile',1,'','2026-05-30 02:46:26','approved','');
INSERT INTO work_records VALUES(34,4,328,2,'mobile',1,'','2026-05-30 02:46:32','approved','');
INSERT INTO work_records VALUES(35,4,328,2,'mobile',1,'','2026-05-30 02:46:39','approved','');
INSERT INTO work_records VALUES(36,4,195,2,'mobile',1,'','2026-05-30 02:46:45','approved','');
INSERT INTO work_records VALUES(37,4,322,2,'mobile',1,'','2026-05-30 02:46:51','approved','');
INSERT INTO work_records VALUES(38,4,322,2,'mobile',1,'','2026-05-30 02:46:58','approved','');
INSERT INTO work_records VALUES(39,4,195,2,'mobile',1,'','2026-05-30 03:02:51','approved','');
INSERT INTO work_records VALUES(40,4,195,2,'mobile',1,'','2026-05-30 03:02:58','approved','');
INSERT INTO work_records VALUES(41,4,195,2,'mobile',1,'','2026-05-30 03:03:18','approved','');
INSERT INTO work_records VALUES(42,5,322,2,'mobile',1,'','2026-05-30 03:03:31','approved','');
INSERT INTO work_records VALUES(43,6,322,2,'mobile',1,'','2026-05-30 03:35:35','approved','');
INSERT INTO work_records VALUES(44,5,322,2,'mobile',1,'','2026-05-30 04:40:47','approved','');
INSERT INTO work_records VALUES(45,5,322,2,'mobile',1,'','2026-05-30 04:40:54','approved','');
INSERT INTO work_records VALUES(46,5,322,2,'mobile',1,'','2026-05-30 05:40:44','approved','');
INSERT INTO work_records VALUES(47,5,322,2,'mobile',1,'','2026-05-30 06:39:52','approved','');
INSERT INTO work_records VALUES(48,5,322,2,'mobile',1,'','2026-05-30 06:41:34','approved','');
INSERT INTO work_records VALUES(49,5,322,2,'mobile',1,'','2026-05-30 06:41:44','approved','');
INSERT INTO work_records VALUES(50,5,322,2,'mobile',1,'','2026-05-30 06:41:51','approved','');
INSERT INTO work_records VALUES(51,8,322,2,'mobile',1,'','2026-05-30 07:15:24','approved','26053003-003');
CREATE TABLE scrap_records (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_id INTEGER NOT NULL,
        process_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        quantity INTEGER DEFAULT 0,
        reason TEXT DEFAULT '',
        created_at TEXT DEFAULT (datetime('now','localtime')),
        rework INTEGER DEFAULT 0,
        FOREIGN KEY (order_id) REFERENCES orders(id),
        FOREIGN KEY (process_id) REFERENCES processes(id),
        FOREIGN KEY (user_id) REFERENCES users(id)
    );
CREATE TABLE rework_records (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_id INTEGER NOT NULL,
        process_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        quantity INTEGER DEFAULT 0,
        reason TEXT DEFAULT '',
        created_at TEXT DEFAULT (datetime('now','localtime')),
        FOREIGN KEY (order_id) REFERENCES orders(id),
        FOREIGN KEY (process_id) REFERENCES processes(id),
        FOREIGN KEY (user_id) REFERENCES users(id)
    );
CREATE TABLE order_attachments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_id INTEGER NOT NULL,
        file_name TEXT NOT NULL,
        file_type TEXT DEFAULT '',
        file_size INTEGER DEFAULT 0,
        file_data BLOB,
        file_path TEXT DEFAULT '',
        uploaded_by INTEGER,
        created_at TEXT DEFAULT (datetime('now','localtime')),
        FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
    );
CREATE TABLE shipments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            shipment_no TEXT UNIQUE NOT NULL,
            customer TEXT DEFAULT '',
            contact_person TEXT DEFAULT '',
            contact_phone TEXT DEFAULT '',
            address TEXT DEFAULT '',
            status TEXT DEFAULT 'pending',
            total_quantity INTEGER DEFAULT 0,
            remark TEXT DEFAULT '',
            created_by TEXT DEFAULT '',
            created_at TEXT DEFAULT (datetime('now','localtime')),
            completed_at TEXT DEFAULT ''
        );
CREATE TABLE shipment_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            shipment_id INTEGER NOT NULL,
            inventory_id INTEGER NOT NULL,
            product_model TEXT DEFAULT '',
            product_name TEXT DEFAULT '',
            quantity INTEGER DEFAULT 0,
            unit TEXT DEFAULT '件',
            remark TEXT DEFAULT '',
            FOREIGN KEY (shipment_id) REFERENCES shipments(id) ON DELETE CASCADE,
            FOREIGN KEY (inventory_id) REFERENCES inventory(id)
        );
CREATE TABLE positions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            description TEXT DEFAULT '',
            status TEXT DEFAULT 'active',
            created_at TEXT DEFAULT (datetime('now','localtime'))
        );
INSERT INTO positions VALUES(1,'切割工','','active','2026-05-28 05:35:21');
INSERT INTO positions VALUES(2,'铆工','','active','2026-05-28 05:36:37');
INSERT INTO positions VALUES(3,'焊工','','active','2026-05-28 05:36:47');
INSERT INTO positions VALUES(4,'抛丸工','','active','2026-05-28 05:37:15');
INSERT INTO positions VALUES(5,'打磨工','','active','2026-05-28 05:37:36');
INSERT INTO positions VALUES(6,'喷漆工','','active','2026-05-28 05:47:11');
INSERT INTO positions VALUES(7,'镗工','','active','2026-05-28 05:47:38');
INSERT INTO positions VALUES(8,'焊接工','负责焊接工序','active','2026-05-29 05:32:07');
CREATE TABLE position_processes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            position_id INTEGER NOT NULL,
            process_id INTEGER NOT NULL,
            FOREIGN KEY (position_id) REFERENCES positions(id) ON DELETE CASCADE,
            FOREIGN KEY (process_id) REFERENCES processes(id) ON DELETE CASCADE,
            UNIQUE(position_id, process_id)
        );
INSERT INTO position_processes VALUES(1,1,322);
INSERT INTO position_processes VALUES(3,3,195);
INSERT INTO position_processes VALUES(4,4,329);
INSERT INTO position_processes VALUES(5,5,324);
INSERT INTO position_processes VALUES(6,6,223);
INSERT INTO position_processes VALUES(7,7,330);
INSERT INTO position_processes VALUES(8,8,195);
INSERT INTO position_processes VALUES(9,2,328);
INSERT INTO position_processes VALUES(10,2,423);
INSERT INTO position_processes VALUES(11,2,990);
CREATE TABLE route_prices (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            route_id INTEGER NOT NULL,
            process_id INTEGER NOT NULL,
            unit_price REAL NOT NULL DEFAULT 0,
            effective_date TEXT DEFAULT '',
            status TEXT DEFAULT 'active',
            remark TEXT DEFAULT '',
            created_at TEXT DEFAULT (datetime('now','localtime')),
            updated_at TEXT DEFAULT (datetime('now','localtime')),
            FOREIGN KEY (route_id) REFERENCES process_routes(id) ON DELETE CASCADE,
            FOREIGN KEY (process_id) REFERENCES processes(id) ON DELETE CASCADE,
            UNIQUE(route_id, process_id)
        );
INSERT INTO route_prices VALUES(14,2,195,90.0,'','active','','2026-05-31 10:56:48','2026-05-31 10:56:48');
INSERT INTO route_prices VALUES(15,2,223,25.0,'','active','','2026-05-31 10:56:48','2026-05-31 10:56:48');
INSERT INTO route_prices VALUES(16,2,322,28.0,'','active','','2026-05-31 10:56:48','2026-05-31 10:56:48');
INSERT INTO route_prices VALUES(17,2,324,20.0,'','active','','2026-05-31 10:56:48','2026-05-31 10:56:48');
INSERT INTO route_prices VALUES(18,2,328,60.0,'','active','','2026-05-31 10:56:48','2026-05-31 10:56:48');
INSERT INTO route_prices VALUES(19,2,329,15.0,'','active','','2026-05-31 10:56:48','2026-05-31 10:56:48');
INSERT INTO route_prices VALUES(20,2,330,20.0,'','active','','2026-05-31 10:56:48','2026-05-31 10:56:48');
INSERT INTO route_prices VALUES(21,11,195,110.0,'2026-05-30','active','','2026-05-31 10:56:48','2026-05-31 10:56:48');
INSERT INTO route_prices VALUES(22,11,223,30.0,'2026-05-30','active','','2026-05-31 10:56:48','2026-05-31 10:56:48');
INSERT INTO route_prices VALUES(23,11,322,30.0,'2026-05-30','active','','2026-05-31 10:56:48','2026-05-31 10:56:48');
INSERT INTO route_prices VALUES(24,11,324,30.0,'2026-05-30','active','','2026-05-31 10:56:48','2026-05-31 10:56:48');
INSERT INTO route_prices VALUES(25,11,328,80.0,'2026-05-30','active','','2026-05-31 10:56:48','2026-05-31 10:56:48');
INSERT INTO route_prices VALUES(26,11,329,15.0,'2026-05-30','active','','2026-05-31 10:56:48','2026-05-31 10:56:48');
INSERT INTO route_prices VALUES(27,11,330,25.0,'2026-05-30','active','','2026-05-31 10:56:48','2026-05-31 10:56:48');
INSERT INTO route_prices VALUES(28,6,195,200.0,'2026-05-30','active','','2026-05-31 10:56:48','2026-05-31 10:56:48');
INSERT INTO route_prices VALUES(29,6,223,50.0,'2026-05-30','active','','2026-05-31 10:56:48','2026-05-31 10:56:48');
INSERT INTO route_prices VALUES(30,6,322,50.0,'2026-05-30','active','','2026-05-31 10:56:48','2026-05-31 10:56:48');
INSERT INTO route_prices VALUES(31,6,324,40.0,'2026-05-30','active','','2026-05-31 10:56:48','2026-05-31 10:56:48');
INSERT INTO route_prices VALUES(32,6,328,150.0,'2026-05-30','active','','2026-05-31 10:56:48','2026-05-31 10:56:48');
INSERT INTO route_prices VALUES(33,6,329,30.0,'2026-05-30','active','','2026-05-31 10:56:48','2026-05-31 10:56:48');
INSERT INTO route_prices VALUES(34,6,330,28.0,'2026-05-30','active','','2026-05-31 10:56:48','2026-05-31 10:56:48');
INSERT INTO route_prices VALUES(35,5,195,200.0,'2026-05-30','active','','2026-05-31 10:57:10','2026-05-31 10:57:10');
INSERT INTO route_prices VALUES(36,5,990,20.0,'2026-05-30','active','','2026-05-31 10:57:10','2026-05-31 10:57:10');
INSERT INTO route_prices VALUES(37,5,986,12.0,'2026-05-30','active','','2026-05-31 10:57:10','2026-05-31 10:57:10');
INSERT INTO route_prices VALUES(39,5,322,80.0,'2026-05-30','active','','2026-05-31 10:57:10','2026-05-31 10:57:10');
INSERT INTO route_prices VALUES(40,5,324,40.0,'2026-05-30','active','','2026-05-31 10:57:10','2026-05-31 10:57:10');
INSERT INTO route_prices VALUES(41,5,328,180.0,'2026-05-30','active','','2026-05-31 10:57:10','2026-05-31 10:57:10');
INSERT INTO route_prices VALUES(42,5,329,30.0,'2026-05-30','active','','2026-05-31 10:57:10','2026-05-31 10:57:10');
INSERT INTO route_prices VALUES(43,5,330,28.0,'2026-05-30','active','','2026-05-31 10:57:10','2026-05-31 10:57:10');
INSERT INTO route_prices VALUES(44,5,983,10.0,'2026-05-30','active','','2026-05-31 10:57:10','2026-05-31 10:57:10');
INSERT INTO route_prices VALUES(45,5,984,12.0,'2026-05-30','active','','2026-05-31 10:57:10','2026-05-31 10:57:10');
CREATE TABLE materials (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            spec TEXT DEFAULT '',
            unit TEXT DEFAULT '件',
            quantity REAL DEFAULT 0,
            unit_price REAL DEFAULT 0,
            safe_stock REAL DEFAULT 0,
            location TEXT DEFAULT '',
            remark TEXT DEFAULT '',
            created_at TEXT DEFAULT (datetime('now','localtime')),
            updated_at TEXT DEFAULT (datetime('now','localtime'))
        );
CREATE TABLE material_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            material_id INTEGER NOT NULL,
            type TEXT NOT NULL,
            quantity REAL NOT NULL,
            remark TEXT DEFAULT '',
            operator_id INTEGER,
            operator_name TEXT DEFAULT '',
            created_at TEXT DEFAULT (datetime('now','localtime')),
            FOREIGN KEY (material_id) REFERENCES materials(id)
        );
CREATE TABLE IF NOT EXISTS "orders" (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_no TEXT UNIQUE NOT NULL,
            customer TEXT DEFAULT '',
            customer_id INTEGER DEFAULT NULL,
            product_name TEXT DEFAULT '',
            product_code TEXT DEFAULT '',
            quantity INTEGER DEFAULT 0,
            completed INTEGER DEFAULT 0,
            scrapped INTEGER DEFAULT 0,
            rework INTEGER DEFAULT 0,
            status TEXT DEFAULT 'pending',
            plan_start TEXT DEFAULT '',
            plan_end TEXT DEFAULT '',
            deadline TEXT DEFAULT '',
            extra_fields TEXT DEFAULT '{}',
            remark TEXT DEFAULT '',
            route_id INTEGER DEFAULT NULL,
            created_at TEXT DEFAULT (datetime('now','localtime')),
            updated_at TEXT DEFAULT (datetime('now','localtime')),
            FOREIGN KEY (customer_id) REFERENCES customers(id)
        );
INSERT INTO orders VALUES(4,'26052904','韩运机械',NULL,'外壳',' ',3,12,0,0,'producing','2026-05-29','2026-05-30','2026-05-31','{"product_code": "外壳-SB70-JY-360-20-标准自用", "status": "pending"}','',2,'2026-05-29 15:02:28','2026-05-30 03:03:18');
INSERT INTO orders VALUES(5,'26052905','中天博运',NULL,'外壳',' ',10,8,0,0,'producing','2026-05-29','2026-05-30','2026-05-31','{"product_code": "外壳-SB70-SJ-360-20-经济自用", "status": "pending"}','',2,'2026-05-29 15:29:35','2026-05-30 06:41:51');
INSERT INTO orders VALUES(6,'26053001','韩运机械',NULL,'外壳',' ',3,1,0,0,'producing','2026-05-30','2026-05-31','2026-07-03','{"product_code": "外壳-SB81-JY-360-22-标准自用", "status": "pending"}','',2,'2026-05-30 03:23:19','2026-05-30 03:35:35');
INSERT INTO orders VALUES(7,'26053002','韩运机械',NULL,'外壳',' ',10,0,0,0,'pending','2026-05-30','2026-05-31','2026-06-01','{"product_code": "外壳-SB70-SJ-360-22-标准自用", "status": "pending"}','',2,'2026-05-30 06:42:48','2026-05-30 06:42:48');
INSERT INTO orders VALUES(8,'26053003','韩运机械',NULL,'外壳',' ',3,1,0,0,'producing','2026-05-30','2026-06-03','2026-06-07','{"product_code": "外壳-SB81-FT-440-22-标准自用", "status": "pending"}','',2,'2026-05-30 07:14:31','2026-05-30 07:15:24');
INSERT INTO orders VALUES(9,'26060201','韩运机械',NULL,'外壳',' ',10,0,0,0,'pending','2026-06-02','2026-06-13','2026-06-14','{"product_code": "外壳-SB81-SJ-360-22-标准自用", "status": "pending"}','',2,'2026-06-02 06:06:08','2026-06-02 06:06:08');
DELETE FROM sqlite_sequence;
INSERT INTO sqlite_sequence VALUES('processes',3142);
INSERT INTO sqlite_sequence VALUES('users',2622);
INSERT INTO sqlite_sequence VALUES('audit_logs',888);
INSERT INTO sqlite_sequence VALUES('customers',4);
INSERT INTO sqlite_sequence VALUES('products',111);
INSERT INTO sqlite_sequence VALUES('process_prices',88);
INSERT INTO sqlite_sequence VALUES('process_routes',11);
INSERT INTO sqlite_sequence VALUES('process_route_items',87);
INSERT INTO sqlite_sequence VALUES('role_groups',7);
INSERT INTO sqlite_sequence VALUES('roles',310);
INSERT INTO sqlite_sequence VALUES('product_attachments',5);
INSERT INTO sqlite_sequence VALUES('order_processes',179);
INSERT INTO sqlite_sequence VALUES('product_items',73);
INSERT INTO sqlite_sequence VALUES('inventory',2);
INSERT INTO sqlite_sequence VALUES('work_records',51);
INSERT INTO sqlite_sequence VALUES('positions',9);
INSERT INTO sqlite_sequence VALUES('position_processes',11);
INSERT INTO sqlite_sequence VALUES('user_roles',20);
INSERT INTO sqlite_sequence VALUES('route_prices',45);
INSERT INTO sqlite_sequence VALUES('inventory_logs',2);
INSERT INTO sqlite_sequence VALUES('materials',1);
INSERT INTO sqlite_sequence VALUES('material_logs',2);
INSERT INTO sqlite_sequence VALUES('shipments',3);
INSERT INTO sqlite_sequence VALUES('shipment_items',3);
INSERT INTO sqlite_sequence VALUES('orders',9);
CREATE INDEX idx_inventory_model ON inventory(product_model);
CREATE INDEX idx_inventory_logs_inventory ON inventory_logs(inventory_id);
CREATE INDEX idx_inventory_logs_created ON inventory_logs(created_at);
CREATE INDEX idx_route_items_route ON process_route_items(route_id);
CREATE INDEX idx_customers_name ON customers(name);
CREATE INDEX idx_customers_contact ON customers(contact);
CREATE INDEX idx_customers_phone ON customers(phone);
CREATE INDEX idx_products_name ON products(product_name);
CREATE INDEX idx_process_prices_process ON process_prices(process_id);
CREATE INDEX idx_process_prices_product ON process_prices(product_id);
CREATE UNIQUE INDEX idx_processes_name ON processes(name);
CREATE INDEX idx_product_attachments_product ON product_attachments(product_id);
CREATE INDEX idx_items_serial ON product_items(serial_no);
CREATE INDEX idx_items_order ON product_items(order_id);
CREATE INDEX idx_items_status ON product_items(status);
CREATE INDEX idx_product_items_order ON product_items(order_id);
CREATE INDEX idx_product_items_serial ON product_items(serial_no);
CREATE INDEX idx_attachments_order ON order_attachments(order_id);
CREATE INDEX idx_shipments_no ON shipments(shipment_no);
CREATE INDEX idx_shipments_status ON shipments(status);
CREATE INDEX idx_shipments_created ON shipments(created_at);
CREATE INDEX idx_shipment_items_shipment ON shipment_items(shipment_id);
CREATE INDEX idx_route_prices_route ON route_prices(route_id);
CREATE INDEX idx_materials_name ON materials(name);
CREATE INDEX idx_material_logs_material ON material_logs(material_id);
CREATE INDEX idx_material_logs_created ON material_logs(created_at);
CREATE INDEX idx_audit_logs_created ON audit_logs(created_at DESC);
CREATE INDEX idx_audit_logs_user ON audit_logs(user_id);
CREATE INDEX idx_audit_logs_action ON audit_logs(action);
CREATE INDEX idx_products_route ON products(route_id);
CREATE UNIQUE INDEX idx_process_prices_unique ON process_prices(COALESCE(product_id, -1), process_id);
CREATE INDEX idx_orders_customer_id ON orders(customer_id);
COMMIT;
